# 蛙岛警报 · 震时避险开放世界演练 —— 团队包

打包日期：2026-11-17。线上正式版（公开，免登录）：
https://frog-island-alert-wmqt8ebi2ju.qoder.zone

## 里面有什么

```
playable/site/     可直接运行的完整站点（12 个文件，three.js 依赖已内置，无需 npm install）
source/game/       游戏源码：world.mjs 场景、player.mjs 控制器、score.mjs 评分、main.js 主循环、index.html HUD
source/scripts/    build_site.mjs 打包脚本、serve.mjs 本地静态服、check_game.mjs 23 条评分断言
source/package.json  跑源码/校验用的依赖声明（three ^0.187）
post/              天池作品帖草稿 + 7 张投稿截图（发帖需本人账号，草稿里是【占位符】）
```

角色模型在 `playable/site/assets/mascot.glb`（原创吉祥物"稳稳"，1.45 m，9 骨骼 6 动画，脸朝 +Z、脚底 y=0）。
单独的角色交付包（含可重建源码与测试场景）是之前发过的 `mascot_wenwen.zip`，本包不重复。

## 本地跑起来

```bash
node source/scripts/serve.mjs playable/site 8080
# 浏览器打开 http://127.0.0.1:8080/
```

没有 node 也行：`playable/site/` 是纯静态的，任何静态服务器都可以，但要用 http 打开，
直接双击 index.html 会因为模块跨域被浏览器拦。

跑评分断言（不需要 GPU）：

```bash
cd source && npm i && node scripts/check_game.mjs
```

## 操作

WASD / 方向键移动，空格跳，E 交互，按住鼠标拖动转视角，滚轮拉近拉远。
流程：自由探索 → 地震预警 → 剧烈晃动（躲三角区）→ 撤离到中央避难场所。
五维计分：就近三角区 / 关燃气 / 拉总闸 / 撤离路线 / 没进电梯，各 20 分。

## 已验证到什么程度

- `check_game.mjs` 23 条断言全过（撤离链 100.5 m 在 75 s 内可走完、交互点不埋进实体等）。
- 浏览器真实操作整局：键盘走完全流程结算 90/A，与规则一致。
- 线上页面 console 无报错；canvas 布局已按视口实测核对过（150% 缩放屏幕不裁画面）。

## 三条提醒

1. **原创红线**：比赛要求原创，包内不含任何奶龙相关素材；角色、场景、评分全部是自研代码。改形象时别引入受版权保护的造型。
2. **别动描述符**：`.蛙岛警报….qoder.site` 是 Qoder Sites 的私有恢复记录，不在本包里，也不要手工造一个。
3. **发帖是本人操作**：`post/天池作品帖草稿.md` 里的姓名/学校/专业/Qoder 账号是占位符，填好后由参赛者本人发布。
