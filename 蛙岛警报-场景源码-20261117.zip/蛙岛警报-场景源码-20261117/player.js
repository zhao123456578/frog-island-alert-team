/* ============================================================
 * player.js — 低多边形小人（第三人称角色）
 * 依赖：全局 THREE（传统 <script> 标签）
 * 注册：window.GameModels.Character(options) -> THREE.Group
 * 约定：1 单位 = 1 米；原点 = 脚底中心；Y 轴向上；默认朝向 +Z
 * 说明：只提供模型与可动关节（userData.parts），动画由主程序驱动。
 * ============================================================ */
(function (global) {
  'use strict';

  var NS = global.GameModels = global.GameModels || {};

  var DEFAULTS = {
    height: 1.82,
    colors: {
      jacket: 0xd8623a,
      jacketDark: 0xb14b28,
      pants: 0x34414f,
      shoe: 0x1f262c,
      skin: 0xedc09b,
      hair: 0x2b3a48,
      pack: 0x4a6b7c,
      visor: 0x1a2126
    }
  };

  var UNIT_BOX = null;

  function unitBox() {
    if (!UNIT_BOX) UNIT_BOX = new THREE.BoxGeometry(1, 1, 1);
    return UNIT_BOX;
  }

  function merge(base, patch) {
    var out = {}, k;
    for (k in base) if (Object.prototype.hasOwnProperty.call(base, k)) out[k] = base[k];
    if (patch) for (k in patch) if (Object.prototype.hasOwnProperty.call(patch, k)) out[k] = patch[k];
    return out;
  }

  function solid(color, roughness, metalness) {
    return new THREE.MeshStandardMaterial({
      color: color,
      roughness: roughness === undefined ? 0.85 : roughness,
      metalness: metalness === undefined ? 0.02 : metalness,
      flatShading: true
    });
  }

  function box(w, h, d, mat, x, y, z, name) {
    var m = new THREE.Mesh(unitBox(), mat);
    m.scale.set(w, h, d);
    m.position.set(x || 0, y || 0, z || 0);
    m.castShadow = true;
    m.receiveShadow = true;
    if (name) m.name = name;
    return m;
  }

  /* ---------------- 注册：Character ---------------- */
  NS.Character = function (options) {
    if (!global.THREE) throw new Error('Character model failed: THREE is not loaded');

    try {
      var opt = options || {};
      var C = merge(DEFAULTS.colors, opt.colors);

      var mat = {
        jacket: solid(C.jacket, 0.82),
        jacketDark: solid(C.jacketDark, 0.82),
        pants: solid(C.pants, 0.9),
        shoe: solid(C.shoe, 0.75),
        skin: solid(C.skin, 0.8),
        hair: solid(C.hair, 0.85),
        pack: solid(C.pack, 0.85),
        visor: solid(C.visor, 0.4, 0.25)
      };

      var group = new THREE.Group();
      group.name = 'Character';

      // body：下蹲时整体压低
      var body = new THREE.Group();
      body.name = 'body';
      group.add(body);

      body.add(box(0.36, 0.26, 0.24, mat.pants, 0, 0.99, 0, 'pelvis'));
      body.add(box(0.46, 0.52, 0.28, mat.jacket, 0, 1.31, 0, 'torso'));
      body.add(box(0.48, 0.08, 0.3, mat.jacketDark, 0, 1.54, 0, 'collar'));
      body.add(box(0.28, 0.32, 0.12, mat.pack, 0, 1.3, -0.2, 'backpack'));
      body.add(box(0.1, 0.08, 0.1, mat.skin, 0, 1.59, 0, 'neck'));

      var head = new THREE.Group();
      head.name = 'head';
      head.position.set(0, 1.67, 0);
      head.add(box(0.26, 0.25, 0.25, mat.skin, 0, 0, 0, 'skull'));
      head.add(box(0.275, 0.1, 0.265, mat.hair, 0, 0.095, -0.012, 'hair'));
      head.add(box(0.19, 0.05, 0.03, mat.visor, 0, 0.005, 0.132, 'visor'));
      body.add(head);

      function makeArm(side) {
        var arm = new THREE.Group();
        arm.name = 'arm-' + (side > 0 ? 'r' : 'l');
        arm.position.set(side * 0.3, 1.48, 0);
        arm.add(box(0.12, 0.3, 0.14, mat.jacket, 0, -0.15, 0, 'upper'));

        var elbow = new THREE.Group();
        elbow.name = 'elbow';
        elbow.position.set(0, -0.3, 0);
        elbow.add(box(0.11, 0.28, 0.12, mat.jacketDark, 0, -0.14, 0, 'forearm'));
        elbow.add(box(0.12, 0.1, 0.13, mat.skin, 0, -0.32, 0, 'hand'));
        arm.add(elbow);

        return { arm: arm, elbow: elbow };
      }

      function makeLeg(side) {
        var leg = new THREE.Group();
        leg.name = 'leg-' + (side > 0 ? 'r' : 'l');
        leg.position.set(side * 0.12, 0.92, 0);
        leg.add(box(0.17, 0.44, 0.19, mat.pants, 0, -0.22, 0, 'thigh'));

        var knee = new THREE.Group();
        knee.name = 'knee';
        knee.position.set(0, -0.44, 0);
        knee.add(box(0.15, 0.36, 0.17, mat.pants, 0, -0.19, 0, 'shin'));
        knee.add(box(0.17, 0.08, 0.26, mat.shoe, 0, -0.44, 0.05, 'foot'));
        leg.add(knee);

        return { leg: leg, knee: knee };
      }

      var armL = makeArm(-1), armR = makeArm(1);
      var legL = makeLeg(-1), legR = makeLeg(1);

      body.add(armL.arm, armR.arm, legL.leg, legR.leg);

      // 供主程序驱动的关节
      group.userData.parts = {
        body: body,
        head: head,
        armL: armL.arm,
        armR: armR.arm,
        elbowL: armL.elbow,
        elbowR: armR.elbow,
        legL: legL.leg,
        legR: legR.leg,
        kneeL: legL.knee,
        kneeR: legR.knee
      };
      group.userData.height = 1.8;   // 视觉总高（含发型）
      group.userData.capsuleRadius = 0.34;

      return group;
    } catch (err) {
      throw new Error('Character model failed: ' + (err && err.message ? err.message : String(err)));
    }
  };
})(window);
