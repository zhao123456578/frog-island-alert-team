/* ============================================================
 * interior.js — 大楼内部：一个房间（中间楼层）+ 入户玻璃电梯
 * 依赖：全局 THREE（传统 <script> 标签）
 * 注册：window.GameModels.Interior(options) -> THREE.Group
 * 约定：1 单位 = 1 米；原点与大楼重合（建筑底面中心），坐标与 building.js 同一套
 *
 * 与 building.js 的配合：
 *   本文件导出 GameModels.Interior.OPENINGS，scene-layout.js 把它传给 Building，
 *   两边的开窗 / 门洞位置才严格对齐（改房间尺寸时只需改这里的 ROOM）。
 *   注意：主楼模型必须把塔楼做成空腔 + 对应开洞，否则房间会被外墙遮住。
 * ============================================================ */
(function (global) {
  'use strict';

  var NS = global.GameModels = global.GameModels || {};

  /* ---------------- 关键尺寸（与 building.js 共用） ---------------- */
  // 第 8 层（0 基索引 7）：45m / 14 层 × 7 = 22.5m，正好是中间层
  var ROOM = {
    floorIndex: 7,
    floorY: 22.5,
    height: 2.8,
    x0: -14.4, x1: -4.4,     // 净宽 10
    z0: -9.4, z1: -2.4,      // 净深 7
    t: 0.14
  };
  ROOM.ceilY = ROOM.floorY + ROOM.height;

  // 后立面上的窗洞（绝对坐标，供 building.js 开洞）
  var WINDOW = { x0: -11.6, x1: -5.6, y0: 23.2, y1: 25.0 };
  // 左立面上的电梯门洞（通往室外玻璃电梯）
  var DOOR = { z0: -6.5, z1: -4.5, y0: 22.5, y1: 24.7 };

  // 室外电梯井
  var SHAFT = { x0: -18.6, x1: -16.2, z0: -6.9, z1: -4.1, top: 26.6 };

  NS.Interior = function (options) {
    if (!global.THREE) throw new Error('Interior model failed: THREE is not loaded');

    try {
      var opt = options || {};
      var C = {
        floor: 0xa8815a,
        floorDark: 0x8f6b47,
        wall: 0xe9e3d7,
        ceiling: 0xf4f1ea,
        skirting: 0xd8d0c0,
        wood: 0x8a6642,
        woodLight: 0xb08a5e,
        fabric: 0x6f7d84,
        fabricLight: 0x8c9aa0,
        rug: 0xb8a184,
        metal: 0x8b9299,
        dark: 0x20262a,
        white: 0xdadde0,
        counter: 0x4a4f53,
        leaf: 0x5f8f4e,
        leaf2: 0x6fa057,
        accent: 0xc4562f,
        glass: 0x9fc4d8
      };

      var mat = {
        floor: solid(C.floor, 0.85),
        floorDark: solid(C.floorDark, 0.85),
        wall: solid(C.wall, 0.95),
        ceiling: solid(C.ceiling, 0.96, 0.0, 0xf4f1ea, 0.28),
        skirting: solid(C.skirting, 0.9),
        wood: solid(C.wood, 0.8),
        woodLight: solid(C.woodLight, 0.8),
        fabric: solid(C.fabric, 0.95),
        fabricLight: solid(C.fabricLight, 0.95),
        rug: solid(C.rug, 0.98),
        metal: solid(C.metal, 0.45, 0.55),
        dark: solid(C.dark, 0.5, 0.3),
        white: solid(C.white, 0.6, 0.1),
        counter: solid(C.counter, 0.55, 0.15),
        leaf: solid(C.leaf, 0.9),
        leaf2: solid(C.leaf2, 0.9),
        accent: solid(C.accent, 0.8),
        glass: new THREE.MeshStandardMaterial({
          color: C.glass, roughness: 0.08, metalness: 0.25,
          transparent: true, opacity: 0.24, side: THREE.DoubleSide, depthWrite: false
        }),
        stair: solid(0xbfb9ac, 0.9),
        lobbyFloor: solid(0xbcb6a7, 0.85),
        lobbyCeil: solid(0xd8d5cc, 0.95, 0.0, 0xd8d5cc, 0.22),
        column: solid(0xd2ccc0, 0.9),
        lamp: solid(0xfff1d6, 0.5, 0.0, 0xffe2b0, 1.2),
        screen: solid(0x14191c, 0.25, 0.2, 0x1b3a4a, 0.35)
      };

      var group = new THREE.Group();
      group.name = 'Interior';

      /* ================= 1. 房间外壳 ================= */
      var R = ROOM;
      var roomW = R.x1 - R.x0;          // 10
      var roomD = R.z1 - R.z0;          // 7
      var cx = (R.x0 + R.x1) / 2;       // -9.4
      var cz = (R.z0 + R.z1) / 2;       // -5.9

      // 地面（木地板）+ 板缝
      add(group, mesh(roomW, 0.3, roomD, mat.floor, cx, R.floorY - 0.15, cz, 'room-floor'));
      var planks = [];
      for (var px = R.x0 + 1.1; px < R.x1; px += 1.1) {
        planks.push({ p: [px, R.floorY + 0.004, cz], s: [0.025, 0.006, roomD - 0.2] });
      }
      add(group, instanced(planks, mat.floorDark, 'floor-seams'));

      // 天花
      add(group, mesh(roomW, 0.24, roomD, mat.ceiling, cx, R.ceilY + 0.12, cz, 'room-ceiling'));

      // 墙体：后墙（开窗） / 左墙（开电梯门） / 右墙 / 前墙
      wallXY(group, R.x0, R.x1, R.floorY, R.ceilY, R.z0 + 0.07, R.t, mat.wall, {
        x0: WINDOW.x0, x1: WINDOW.x1, y0: WINDOW.y0, y1: WINDOW.y1
      }, 'room-wall-back');

      wallYZ(group, R.z0, R.z1, R.floorY, R.ceilY, R.x0 + 0.07, R.t, mat.wall, {
        z0: DOOR.z0, z1: DOOR.z1, y0: DOOR.y0, y1: DOOR.y1
      }, 'room-wall-left');

      wallYZ(group, R.z0, R.z1, R.floorY, R.ceilY, R.x1 + R.t / 2, R.t, mat.wall, {
        z0: -8.7, z1: -7.4, y0: ROOM.floorY, y1: 24.4
      }, 'room-wall-right');
      add(group, mesh(roomW + R.t * 2, R.height, R.t, mat.wall, cx, R.floorY + R.height / 2, R.z1 + R.t / 2, 'room-wall-front'));

      // 踢脚线
      add(group, mesh(roomW - 0.04, 0.09, 0.03, mat.skirting, cx, R.floorY + 0.045, R.z0 + 0.16, 'skirting-back'));
      add(group, mesh(roomW - 0.04, 0.09, 0.03, mat.skirting, cx, R.floorY + 0.045, R.z1 - 0.02, 'skirting-front'));
      add(group, mesh(0.03, 0.09, roomD - 0.04, mat.skirting, R.x1 - 0.02, R.floorY + 0.045, cz, 'skirting-right'));

      /* ================= 2. 窗 ================= */
      var winW = WINDOW.x1 - WINDOW.x0;
      var winH = WINDOW.y1 - WINDOW.y0;
      var winCX = (WINDOW.x0 + WINDOW.x1) / 2;
      var winCY = (WINDOW.y0 + WINDOW.y1) / 2;
      var winZ = R.z0 + 0.07;

      // 玻璃
      add(group, mesh(winW - 0.12, winH - 0.12, 0.04, mat.glass, winCX, winCY, winZ + 0.02, 'window-glass'));
      // 窗框
      add(group, mesh(winW, 0.09, 0.16, mat.metal, winCX, WINDOW.y0, winZ + 0.02, 'win-frame-b'));
      add(group, mesh(winW, 0.09, 0.16, mat.metal, winCX, WINDOW.y1, winZ + 0.02, 'win-frame-t'));
      add(group, mesh(0.09, winH, 0.16, mat.metal, WINDOW.x0, winCY, winZ + 0.02, 'win-frame-l'));
      add(group, mesh(0.09, winH, 0.16, mat.metal, WINDOW.x1, winCY, winZ + 0.02, 'win-frame-r'));
      add(group, mesh(0.07, winH - 0.1, 0.12, mat.metal, winCX, winCY, winZ + 0.02, 'win-mullion'));
      // 窗台
      add(group, mesh(winW + 0.3, 0.07, 0.32, mat.woodLight, winCX, WINDOW.y0 - 0.04, winZ + 0.14, 'window-sill'));

      // 窗帘杆 + 两侧窗帘
      add(group, cylinder(0.03, 0.03, winW + 1.2, 8, mat.metal, winCX, WINDOW.y1 + 0.22, winZ + 0.3, 'curtain-rod'));
      add(group, mesh(0.55, WINDOW.y1 - R.floorY + 0.1, 0.07, mat.fabricLight,
        WINDOW.x0 - 0.32, (R.floorY + WINDOW.y1) / 2 + 0.05, winZ + 0.32, 'curtain-l'));
      add(group, mesh(0.55, WINDOW.y1 - R.floorY + 0.1, 0.07, mat.fabricLight,
        WINDOW.x1 + 0.32, (R.floorY + WINDOW.y1) / 2 + 0.05, winZ + 0.32, 'curtain-r'));

      /* ================= 3. 家具 ================= */
      var F = R.floorY;

      // --- 地毯 ---
      add(group, mesh(3.4, 0.03, 2.6, mat.rug, -6.8, F + 0.015, -6.0, 'rug'));

      // --- 沙发（靠右墙，面向 -X / 电视）---
      var sofaX = R.x1 - 0.55;
      add(group, mesh(0.85, 0.34, 2.3, mat.fabric, sofaX, F + 0.17, -6.0, 'sofa-base'));
      add(group, mesh(0.9, 0.22, 2.2, mat.fabricLight, sofaX - 0.03, F + 0.42, -6.0, 'sofa-seat'));
      add(group, mesh(0.28, 0.62, 2.3, mat.fabric, sofaX + 0.32, F + 0.62, -6.0, 'sofa-back'));
      add(group, mesh(0.6, 0.5, 0.22, mat.fabric, sofaX - 0.05, F + 0.35, -7.05, 'sofa-arm-l'));
      add(group, mesh(0.6, 0.5, 0.22, mat.fabric, sofaX - 0.05, F + 0.35, -4.95, 'sofa-arm-r'));
      add(group, mesh(0.16, 0.34, 0.42, mat.accent, sofaX + 0.16, F + 0.62, -6.6, 'cushion-1'));
      add(group, mesh(0.16, 0.34, 0.42, mat.fabricLight, sofaX + 0.16, F + 0.62, -5.45, 'cushion-2'));

      // --- 茶几 ---
      var tableX = -6.9, tableZ = -6.0;
      add(group, mesh(1.5, 0.08, 0.72, mat.woodLight, tableX, F + 0.42, tableZ, 'coffee-top'));
      [[-1, -1], [1, -1], [-1, 1], [1, 1]].forEach(function (s, i) {
        add(group, mesh(0.07, 0.4, 0.07, mat.wood, tableX + s[0] * 0.64, F + 0.2, tableZ + s[1] * 0.26, 'coffee-leg-' + i));
      });
      add(group, mesh(0.3, 0.06, 0.22, mat.white, tableX - 0.3, F + 0.49, tableZ, 'book-1'));
      add(group, mesh(0.26, 0.05, 0.19, mat.accent, tableX - 0.28, F + 0.55, tableZ, 'book-2'));
      add(group, cylinder(0.07, 0.06, 0.12, 8, mat.white, tableX + 0.32, F + 0.53, tableZ + 0.1, 'mug'));

      // --- 电视柜 + 电视（靠左墙，屏幕朝 +X）---
      var tvX = R.x0 + 0.45;
      add(group, mesh(0.48, 0.52, 2.2, mat.wood, tvX, F + 0.26, -7.6, 'tv-cabinet'));
      add(group, mesh(0.02, 0.86, 1.52, mat.screen, tvX + 0.26, F + 1.02, -7.6, 'tv-screen'));
      add(group, mesh(0.04, 1.02, 1.7, mat.dark, tvX + 0.22, F + 1.02, -7.6, 'tv-panel'));
      add(group, mesh(0.16, 0.06, 0.5, mat.dark, tvX + 0.12, F + 0.56, -7.6, 'tv-stand'));

      // --- 书架（前墙左段）---
      add(group, mesh(1.5, 1.9, 0.36, mat.wood, -13.4, F + 0.95, R.z1 - 0.2, 'shelf-box'));
      for (var sh = 0; sh < 4; sh++) {
        add(group, mesh(1.4, 0.03, 0.32, mat.woodLight, -13.4, F + 0.42 + sh * 0.42, R.z1 - 0.2, 'shelf-' + sh));
      }
      [[0.42, -0.5, 0.2], [0.3, -0.2, 0.22], [0.38, 0.12, 0.2], [0.34, 0.42, 0.19]].forEach(function (b, i) {
        add(group, mesh(0.14, b[0], b[2], i === 1 ? mat.accent : mat.fabricLight,
          -13.4 + b[1], F + 0.44 + b[0] / 2, R.z1 - 0.38, 'books-' + i));
      });

      // --- 厨房（前墙右段）---
      var kx0 = R.x1 - 3.8, kx1 = R.x1 - 0.5;
      add(group, mesh(kx1 - kx0, 0.9, 0.6, mat.woodLight, (kx0 + kx1) / 2, F + 0.45, R.z1 - 0.34, 'kitchen-base'));
      add(group, mesh(kx1 - kx0 + 0.06, 0.06, 0.66, mat.counter, (kx0 + kx1) / 2, F + 0.93, R.z1 - 0.34, 'kitchen-top'));
      add(group, mesh(0.5, 0.06, 0.4, mat.metal, kx0 + 0.55, F + 0.97, R.z1 - 0.36, 'sink'));
      add(group, cylinder(0.025, 0.025, 0.28, 6, mat.metal, kx0 + 0.55, F + 1.1, R.z1 - 0.16, 'tap'));
      add(group, mesh(0.55, 0.03, 0.42, mat.dark, kx0 + 1.5, F + 0.97, R.z1 - 0.36, 'stove'));
      add(group, mesh(kx1 - kx0, 0.7, 0.34, mat.white, (kx0 + kx1) / 2, F + 1.95, R.z1 - 0.2, 'kitchen-upper'));
      add(group, mesh(0.72, 1.86, 0.68, mat.white, kx0 - 0.55, F + 0.93, R.z1 - 0.4, 'fridge'));
      add(group, mesh(0.02, 1.6, 0.04, mat.metal, kx0 - 0.92, F + 0.95, R.z1 - 0.4, 'fridge-handle'));

      // --- 餐桌 + 四把椅子 ---
      var dx = -11.3, dz = -3.6;
      add(group, mesh(1.5, 0.07, 0.9, mat.woodLight, dx, F + 0.74, dz, 'dining-top'));
      [[-1, -1], [1, -1], [-1, 1], [1, 1]].forEach(function (s, i) {
        add(group, mesh(0.08, 0.72, 0.08, mat.wood, dx + s[0] * 0.64, F + 0.36, dz + s[1] * 0.34, 'dining-leg-' + i));
      });
      [[-0.95, 0, 0], [0.95, 0, 0], [0, 0.78, 1], [0, -0.78, 1]].forEach(function (c, i) {
        var cxp = dx + c[0], czp = dz + c[1];
        add(group, mesh(0.42, 0.06, 0.42, mat.wood, cxp, F + 0.45, czp, 'chair-seat-' + i));
        var bx = c[2] ? cxp : cxp + (c[0] > 0 ? 0.18 : -0.18);
        var bz = c[2] ? czp + (c[1] > 0 ? 0.18 : -0.18) : czp;
        add(group, mesh(c[2] ? 0.42 : 0.06, 0.44, c[2] ? 0.06 : 0.42, mat.wood, bx, F + 0.67, bz, 'chair-back-' + i));
        [[-0.15, -0.15], [0.15, -0.15], [-0.15, 0.15], [0.15, 0.15]].forEach(function (l, j) {
          add(group, mesh(0.05, 0.42, 0.05, mat.wood, cxp + l[0], F + 0.21, czp + l[1], 'chair-leg-' + i + '-' + j));
        });
      });
      add(group, cylinder(0.012, 0.012, 0.62, 6, mat.dark, dx, F + 2.49, dz, 'pendant-cord'));
      add(group, cylinder(0.26, 0.3, 0.22, 12, mat.lamp, dx, F + 2.12, dz, 'pendant-shade'));

      // --- 落地灯（沙发扶手旁）---
      add(group, cylinder(0.16, 0.18, 0.04, 12, mat.dark, -5.05, F + 0.02, -4.75, 'lamp-base'));
      add(group, cylinder(0.022, 0.022, 1.55, 6, mat.metal, -5.05, F + 0.8, -4.75, 'lamp-pole'));
      add(group, cylinder(0.2, 0.24, 0.26, 12, mat.lamp, -5.05, F + 1.62, -4.75, 'lamp-shade'));

      // --- 绿植（窗边）---
      add(group, cylinder(0.24, 0.19, 0.4, 8, mat.white, -12.7, F + 0.2, -8.95, 'pot'));
      add(group, mesh(0.06, 0.5, 0.06, mat.wood, -12.7, F + 0.62, -8.95, 'stem'));
      [[0, 0.95, 0, 0.34], [0.2, 1.1, 0.12, 0.26], [-0.2, 1.02, -0.08, 0.24]].forEach(function (l, i) {
        var leaf = new THREE.Mesh(new THREE.IcosahedronGeometry(l[3], 0), i === 1 ? mat.leaf2 : mat.leaf);
        leaf.position.set(-12.7 + l[0], F + l[1], -8.95 + l[2]);
        leaf.castShadow = true; leaf.receiveShadow = true;
        leaf.name = 'plant-leaf-' + i;
        group.add(leaf);
      });

      // --- 墙面装饰（沙发上方）---
      add(group, mesh(0.05, 0.62, 0.9, mat.accent, R.x1 - 0.06, F + 1.75, -7.35, 'art-1'));
      add(group, mesh(0.05, 0.5, 0.62, mat.fabricLight, R.x1 - 0.06, F + 1.7, -6.25, 'art-2'));

      // --- 顶灯 ---
      add(group, mesh(1.2, 0.06, 0.7, mat.lamp, cx, R.ceilY - 0.05, cz, 'ceiling-light'));
      add(group, mesh(6.0, 0.04, 0.12, mat.lamp, R.x0 + 3.6, R.ceilY - 0.04, R.z0 + 0.5, 'light-strip'));

      /* ================= 4. 入户玻璃电梯 ================= */
      var S = SHAFT;
      var shaftW = S.x1 - S.x0;   // 2.4
      var shaftD = S.z1 - S.z0;   // 2.8
      var scx = (S.x0 + S.x1) / 2;
      var scz = (S.z0 + S.z1) / 2;

      // 井道四角立柱
      [[S.x0, S.z0], [S.x1, S.z0], [S.x0, S.z1], [S.x1, S.z1]].forEach(function (p, i) {
        add(group, mesh(0.12, S.top, 0.12, mat.metal, p[0], S.top / 2, p[1], 'shaft-post-' + i));
      });
      // 井道顶
      add(group, mesh(shaftW + 0.2, 0.18, shaftD + 0.2, mat.metal, scx, S.top, scz, 'shaft-top'));
      // 井道玻璃（两侧 + 外侧），地面层留门洞
      // 外侧玻璃从 2.5m 起，底部留出入口门洞
      add(group, mesh(0.05, S.top - 2.5, shaftD, mat.glass, S.x0, (S.top + 2.5) / 2, scz, 'shaft-glass-out'));
      add(group, mesh(0.14, 0.2, shaftD + 0.1, mat.metal, S.x0, 2.55, scz, 'shaft-door-head'));
      add(group, mesh(shaftW, S.top - 0.2, 0.05, mat.glass, scx, (S.top - 0.2) / 2, S.z0, 'shaft-glass-z0'));
      add(group, mesh(shaftW, S.top - 0.2, 0.05, mat.glass, scx, (S.top - 0.2) / 2, S.z1, 'shaft-glass-z1'));
      // 横向框
      var frames = [];
      for (var fy = 0.2; fy < S.top - 0.2; fy += 1.6) {
        frames.push({ p: [S.x0, fy, scz], s: [0.07, 0.07, shaftD] });
        frames.push({ p: [scx, fy, S.z0], s: [shaftW, 0.07, 0.07] });
        frames.push({ p: [scx, fy, S.z1], s: [shaftW, 0.07, 0.07] });
      }
      add(group, instanced(frames, mat.metal, 'shaft-frames'));

      // 轿厢（X 向 2.2，Z 向 2.6；两侧推拉门）
      var cabin = new THREE.Group();
      cabin.name = 'elevator-cabin';
      cabin.position.set(scx, 0, scz);

      add(cabin, mesh(2.2, 0.12, 2.6, mat.metal, 0, -0.06, 0, 'cabin-floor'));
      add(cabin, mesh(2.2, 0.1, 2.6, mat.white, 0, 2.34, 0, 'cabin-ceil'));
      add(cabin, mesh(2.2, 0.06, 0.06, mat.lamp, 0, 2.28, 0, 'cabin-light'));
      // 侧壁（玻璃 + 框）
      [-1, 1].forEach(function (s, i) {
        add(cabin, mesh(2.2, 2.3, 0.05, mat.glass, 0, 1.17, s * 1.28, 'cabin-glass-' + i));
        add(cabin, mesh(2.2, 0.06, 0.08, mat.metal, 0, 0.16, s * 1.28, 'cabin-rail-' + i));
        add(cabin, mesh(0.08, 2.3, 0.08, mat.metal, -1.06, 1.17, s * 1.28, 'cabin-post-a-' + i));
        add(cabin, mesh(0.08, 2.3, 0.08, mat.metal, 1.06, 1.17, s * 1.28, 'cabin-post-b-' + i));
      });
      // 门框
      [-1, 1].forEach(function (s, i) {
        add(cabin, mesh(0.08, 2.3, 0.08, mat.metal, s * 1.06, 1.17, 0, 'cabin-door-frame-' + i));
      });

      // 四扇门板：外侧一对（-X，临街） + 内侧一对（+X，通向房间）
      var doorPanels = { outer: [], inner: [] };
      [-1, 1].forEach(function (s, i) {
        var outer = mesh(0.05, 2.16, 1.0, mat.metal, -1.06, 1.13, s * 0.5, 'door-outer-' + i);
        var inner = mesh(0.05, 2.16, 1.0, mat.metal, 1.06, 1.13, s * 0.5, 'door-inner-' + i);
        doorPanels.outer.push(outer);
        doorPanels.inner.push(inner);
        cabin.add(outer, inner);
      });

      group.add(cabin);

      // 7 层连接桥（井道 → 立面门洞）
      var bridgeX0 = S.x1, bridgeX1 = -15.0;
      add(group, mesh(bridgeX1 - bridgeX0, 0.22, 2.0, mat.metal, (bridgeX0 + bridgeX1) / 2, ROOM.floorY - 0.11, -5.5, 'bridge-floor'));
      add(group, mesh(bridgeX1 - bridgeX0, 0.12, 2.0, mat.white, (bridgeX0 + bridgeX1) / 2, DOOR.y1 + 0.06, -5.5, 'bridge-ceil'));
      [-1, 1].forEach(function (s, i) {
        add(group, mesh(bridgeX1 - bridgeX0, DOOR.y1 - ROOM.floorY, 0.05, mat.glass,
          (bridgeX0 + bridgeX1) / 2, (ROOM.floorY + DOOR.y1) / 2, -5.5 + s * 1.0, 'bridge-glass-' + i));
      });

      // 门外雨棚 + 入口踏步
      add(group, mesh(0.9, 0.1, 2.4, mat.metal, S.x0 - 0.45, 2.5, scz, 'lift-canopy'));
      add(group, mesh(0.5, 0.08, 2.2, mat.metal, S.x0 - 0.25, 0.04, scz, 'lift-step'));

      /* ================= 5. 普通楼梯（一层直通 8F）+ 门厅 ================= */
      var FH = 45 / 14;
      var ST = { x0: -4.12, x1: 0.40, z0: -9.40, z1: -6.60, top: 25.3 };
      var rise = FH / 16;
      var tread = 0.275;
      var run0 = ST.x0 + 1.08;
      var run1 = run0 + 8 * tread;
      var laneA = [ST.z0, -8.06];
      var laneB = [-7.94, ST.z1];
      var flights = 7;

      var stepList = [], landList = [];
      for (var lf = 0; lf < flights; lf++) {
        var lbase = lf * FH;
        for (var si = 1; si <= 8; si++) {
          stepList.push({
            p: [run0 + (si - 0.5) * tread, lbase + si * rise / 2, (laneA[0] + laneA[1]) / 2],
            s: [tread, si * rise, laneA[1] - laneA[0]]
          });
        }
        for (si = 1; si <= 8; si++) {
          stepList.push({
            p: [run1 - (si - 0.5) * tread, lbase + 8 * rise + si * rise / 2, (laneB[0] + laneB[1]) / 2],
            s: [tread, si * rise, laneB[1] - laneB[0]]
          });
        }
        landList.push({
          p: [(run1 + ST.x1) / 2, lbase + 8 * rise - 0.1, (ST.z0 + ST.z1) / 2],
          s: [ST.x1 - run1, 0.2, ST.z1 - ST.z0]
        });
      }
      for (lf = 0; lf <= flights; lf++) {
        landList.push({
          p: [(ST.x0 + run0) / 2, lf * FH - 0.1, (ST.z0 + ST.z1) / 2],
          s: [run0 - ST.x0, 0.2, ST.z1 - ST.z0]
        });
      }

      var stepsMesh = instanced(stepList, mat.stair, 'stair-steps');
      if (stepsMesh) { stepsMesh.userData.walk = true; group.add(stepsMesh); }
      var landsMesh = instanced(landList, mat.stair, 'stair-landings');
      if (landsMesh) { landsMesh.userData.walk = true; group.add(landsMesh); }

      add(group, mesh(0.14, ST.top, ST.z1 - ST.z0, mat.wall, ST.x1 + 0.07, ST.top / 2, (ST.z0 + ST.z1) / 2, 'stair-wall-right'));
      add(group, mesh(ST.x1 - ST.x0 + 0.28, ST.top - 6.43, 0.14, mat.wall, (ST.x0 + ST.x1) / 2, (6.43 + ST.top) / 2, ST.z1 + 0.07, 'stair-wall-front'));
      add(group, mesh(ST.x1 - ST.x0 + 0.28, 6.43, 0.14, mat.wall, (ST.x0 + ST.x1) / 2, 3.215, ST.z0 - 0.07, 'stair-wall-back'));
      add(group, mesh(ST.x1 - ST.x0 + 0.28, 0.2, ST.z1 - ST.z0 + 0.28, mat.wall, (ST.x0 + ST.x1) / 2, ST.top + 0.1, (ST.z0 + ST.z1) / 2, 'stair-ceil'));
      add(group, mesh(run1 - run0, ST.top, 0.12, mat.wall, (run0 + run1) / 2, ST.top / 2, -8.0, 'stair-spine'));

      wallYZ(group, ST.z0, ST.z1, 0, ST.top, ST.x0 - 0.07, 0.14, mat.wall, {
        z0: -8.7, z1: -7.4, y0: ROOM.floorY, y1: 24.4
      }, 'stair-wall-left');

      var threshold = mesh(0.44, 0.2, 1.42, mat.stair, -4.27, ROOM.floorY - 0.1, -8.05, 'stair-threshold');
      threshold.userData.walk = true;
      add(group, threshold);
      add(group, mesh(0.18, 0.12, 1.42, mat.metal, -4.26, 24.42, -8.05, 'stair-door-head'));
      add(group, mesh(0.18, 1.9, 0.09, mat.metal, -4.26, 23.45, -8.71, 'stair-door-jamb-l'));
      add(group, mesh(0.18, 1.9, 0.09, mat.metal, -4.26, 23.45, -7.39, 'stair-door-jamb-r'));

      // 门厅：地砖、入口踏步、地垫、柱子
      add(group, mesh(31.2, 0.04, 21.2, mat.lobbyFloor, 0, 0.02, 0, 'lobby-floor'));
      add(group, mesh(7.0, 0.3, 0.6, mat.stair, 0, 0.15, 10.3, 'lobby-step-1'));
      add(group, mesh(6.4, 0.15, 0.6, mat.stair, 0, 0.075, 9.7, 'lobby-step-2'));
      add(group, mesh(3.6, 0.02, 1.4, mat.rug, 0, 0.06, 8.6, 'lobby-mat'));

      [[-7, -3], [7, -3], [-7, 5], [7, 5]].forEach(function (p, i) {
        add(group, mesh(0.7, 6.13, 0.7, mat.column, p[0], 3.065, p[1], 'lobby-column-' + i));
      });

      [4.2, 11, 17.8].forEach(function (ly, i) {
        add(group, mesh(0.1, 0.06, 2.0, mat.lamp, -1.9, ly + 1.9, -8.0, 'stair-strip-' + i));
      });

      /* ================= 6. 碰撞 / 可站立面 / 灯光 / 电梯句柄 ================= */
      // 可站立面（地面射线用）
      group.traverse(function (n) {
        if (n.isMesh && (n.name === 'room-floor' || n.name === 'bridge-floor' || n.name === 'cabin-floor' ||
            n.name === 'lobby-floor' || n.name === 'lobby-step-1' || n.name === 'lobby-step-2' || n.name === 'stair-threshold')) {
          n.userData.walk = true;
        }
      });

      // 碰撞盒（局部坐标，主程序按物件位置偏移）
      var colliders = [];
      function box(size, at) { colliders.push({ size: size, offset: at }); }

      // 房间四壁
      box([roomW, R.height, 0.24], [cx, R.floorY + R.height / 2, R.z0 + 0.12]);
      box([roomW + 0.2, R.height, 0.24], [cx, R.floorY + R.height / 2, R.z1 + 0.12]);
      // 右墙（8F 楼梯门洞处断开）
      box([0.24, 0.9, roomD], [R.x1 + 0.12, 24.85, cz]);
      box([0.24, 1.9, 0.7], [R.x1 + 0.12, 23.45, -9.05]);
      box([0.24, 1.9, 5.0], [R.x1 + 0.12, 23.45, -4.9]);
      // 楼梯核心筒
      box([0.16, ST.top, ST.z1 - ST.z0], [ST.x1 + 0.07, ST.top / 2, (ST.z0 + ST.z1) / 2]);
      box([ST.x1 - ST.x0 + 0.28, ST.top - 6.43, 0.16], [(ST.x0 + ST.x1) / 2, (6.43 + ST.top) / 2, ST.z1 + 0.07]);
      box([ST.x1 - ST.x0 + 0.28, 6.43, 0.16], [(ST.x0 + ST.x1) / 2, 3.215, ST.z0 - 0.07]);
      box([run1 - run0, ST.top, 0.14], [(run0 + run1) / 2, ST.top / 2, -8.0]);
      box([0.16, ROOM.floorY, ST.z1 - ST.z0], [ST.x0 - 0.07, ROOM.floorY / 2, (ST.z0 + ST.z1) / 2]);
      box([0.16, ST.top - 24.4, ST.z1 - ST.z0], [ST.x0 - 0.07, (24.4 + ST.top) / 2, (ST.z0 + ST.z1) / 2]);
      box([0.16, 1.9, 0.7], [ST.x0 - 0.07, 23.45, -9.05]);
      box([0.16, 1.9, 0.8], [ST.x0 - 0.07, 23.45, -7.0]);
      // 门厅柱子
      [[-7, -3], [7, -3], [-7, 5], [7, 5]].forEach(function (p) {
        box([0.75, 6.13, 0.75], [p[0], 3.065, p[1]]);
      });
      // 左墙（门洞上下 + 两侧）
      box([0.24, 0.62, roomD], [R.x0 + 0.12, R.ceilY - 0.31, cz]);
      box([0.24, DOOR.y1 - ROOM.floorY, (DOOR.z0 - R.z0)], [R.x0 + 0.12, (ROOM.floorY + DOOR.y1) / 2, (R.z0 + DOOR.z0) / 2]);
      box([0.24, DOOR.y1 - ROOM.floorY, (R.z1 - DOOR.z1)], [R.x0 + 0.12, (ROOM.floorY + DOOR.y1) / 2, (DOOR.z1 + R.z1) / 2]);
      // 家具
      box([0.9, 0.9, 2.4], [sofaX, F + 0.45, -6.0]);
      box([1.55, 0.45, 0.78], [tableX, F + 0.22, tableZ]);
      box([0.55, 0.6, 2.3], [tvX, F + 0.3, -7.6]);
      box([1.55, 1.95, 0.4], [-13.4, F + 0.97, R.z1 - 0.2]);
      box([3.4, 0.95, 0.7], [(kx0 + kx1) / 2, F + 0.47, R.z1 - 0.34]);
      box([0.75, 1.9, 0.72], [kx0 - 0.55, F + 0.95, R.z1 - 0.4]);
      box([2.4, 0.78, 2.0], [dx, F + 0.39, dz]);
      box([0.5, 0.45, 0.5], [-12.7, F + 0.22, -8.95]);
      box([0.35, 1.7, 0.35], [-5.05, F + 0.85, -4.75]);
      // 连接桥护栏
      box([bridgeX1 - bridgeX0, 2.2, 0.12], [(bridgeX0 + bridgeX1) / 2, ROOM.floorY + 1.1, -6.5]);
      box([bridgeX1 - bridgeX0, 2.2, 0.12], [(bridgeX0 + bridgeX1) / 2, ROOM.floorY + 1.1, -4.5]);
      // 电梯井两侧（防止从轿厢侧向走出）
      box([shaftW, S.top, 0.16], [scx, S.top / 2, S.z0]);
      box([shaftW, S.top, 0.16], [scx, S.top / 2, S.z1]);

      group.userData.colliders = colliders;

      // 房间内的点光源（主程序负责实例化）
      group.userData.lights = [
        { offset: [0, 4.3, 4], color: 0xfff6ea, intensity: 0.55, distance: 30, shadow: true },
        { offset: [-6, 4.3, 7], color: 0xfff6ea, intensity: 0.38, distance: 26 },
        { offset: [-1.9, 5.2, -8.0], color: 0xfff4e6, intensity: 0.9, distance: 14 },
        { offset: [-1.9, 13.2, -8.0], color: 0xfff4e6, intensity: 0.9, distance: 14 },
        { offset: [-1.9, 21.2, -8.0], color: 0xfff4e6, intensity: 0.9, distance: 14 },
        { offset: [cx, R.ceilY - 0.85, cz], color: 0xfff7ee, intensity: 1.5, distance: 20, shadow: true },
        { offset: [winCX, R.ceilY - 0.9, winZ + 1.4], color: 0xeaf3ff, intensity: 0.75, distance: 14 },
        { offset: [scx, 2.2, scz], color: 0xfff4e6, intensity: 1.0, distance: 6 }
      ];

      // 电梯句柄（主程序驱动）
      group.userData.elevator = {
        cabin: cabin,
        doorsOuter: doorPanels.outer,
        doorsInner: doorPanels.inner,
        floors: [0, ROOM.floorY],
        cabinHalf: { x: 1.1, z: 1.3 },
        center: { x: scx, z: scz },
        doorClosedZ: 0.5,
        doorOpenZ: 1.42
      };

      group.userData.room = {
        floorY: ROOM.floorY,
        center: [cx, R.floorY + R.height / 2, cz],
        bounds: [R.x0, R.x1, R.z0, R.z1]
      };

      return group;
    } catch (err) {
      throw new Error('Interior model failed: ' + (err && err.message ? err.message : String(err)));
    }
  };

  // 供 building.js 开洞、scene-layout.js 传参
  NS.Interior.OPENINGS = {
    window: { x0: WINDOW.x0, x1: WINDOW.x1, y0: WINDOW.y0, y1: WINDOW.y1 },
    door: { z0: DOOR.z0, z1: DOOR.z1, y0: DOOR.y0, y1: DOOR.y1 }
  };
  NS.Interior.ROOM = ROOM;
  NS.Interior.STAIR_VOID = { x0: -4.40, x1: 0.54, z0: -9.54, z1: -6.46 };

  /* ---------------- 本文件私有工具 ---------------- */
  var UNIT_BOX = null;
  var HELPER = null;

  function unitBox() {
    if (!UNIT_BOX) UNIT_BOX = new THREE.BoxGeometry(1, 1, 1);
    return UNIT_BOX;
  }

  function helper() {
    if (!HELPER) HELPER = new THREE.Object3D();
    return HELPER;
  }

  function solid(color, roughness, metalness, emissive, emissiveIntensity) {
    var m = new THREE.MeshStandardMaterial({
      color: color,
      roughness: roughness === undefined ? 0.9 : roughness,
      metalness: metalness === undefined ? 0.02 : metalness,
      flatShading: true
    });
    if (emissive !== undefined && emissive !== null) {
      m.emissive = new THREE.Color(emissive);
      m.emissiveIntensity = emissiveIntensity === undefined ? 1 : emissiveIntensity;
    }
    return m;
  }

  function mesh(w, h, d, mat, x, y, z, name) {
    var m = new THREE.Mesh(unitBox(), mat);
    m.scale.set(w, h, d);
    m.position.set(x || 0, y || 0, z || 0);
    m.castShadow = true;
    m.receiveShadow = true;
    if (name) m.name = name;
    return m;
  }

  function cylinder(rTop, rBottom, h, seg, mat, x, y, z, name) {
    var m = new THREE.Mesh(new THREE.CylinderGeometry(rTop, rBottom, h, seg), mat);
    m.position.set(x || 0, y || 0, z || 0);
    m.castShadow = true;
    m.receiveShadow = true;
    if (name) m.name = name;
    return m;
  }

  function instanced(list, mat, name) {
    if (!list.length) return null;
    var m = new THREE.InstancedMesh(unitBox(), mat, list.length);
    var d = helper();
    for (var i = 0; i < list.length; i++) {
      var t = list[i];
      d.position.set(t.p[0], t.p[1], t.p[2]);
      d.rotation.set(0, 0, 0);
      d.scale.set(t.s[0], t.s[1], t.s[2]);
      d.updateMatrix();
      m.setMatrixAt(i, d.matrix);
    }
    m.instanceMatrix.needsUpdate = true;
    m.castShadow = true;
    m.receiveShadow = true;
    if (name) m.name = name;
    return m;
  }

  function add(parent, child) {
    if (child) parent.add(child);
  }

  // 法线朝 Z 的墙（X-Y 面），带矩形洞
  function wallXY(parent, x0, x1, y0, y1, z, t, mat, hole, tag) {
    if (!hole) { add(parent, mesh(x1 - x0, y1 - y0, t, mat, (x0 + x1) / 2, (y0 + y1) / 2, z, tag)); return; }
    if (hole.y0 > y0 + 0.001) add(parent, mesh(x1 - x0, hole.y0 - y0, t, mat, (x0 + x1) / 2, (y0 + hole.y0) / 2, z, tag + '-bottom'));
    if (hole.y1 < y1 - 0.001) add(parent, mesh(x1 - x0, y1 - hole.y1, t, mat, (x0 + x1) / 2, (y1 + hole.y1) / 2, z, tag + '-top'));
    if (hole.x0 > x0 + 0.001) add(parent, mesh(hole.x0 - x0, hole.y1 - hole.y0, t, mat, (x0 + hole.x0) / 2, (hole.y0 + hole.y1) / 2, z, tag + '-left'));
    if (hole.x1 < x1 - 0.001) add(parent, mesh(x1 - hole.x1, hole.y1 - hole.y0, t, mat, (hole.x1 + x1) / 2, (hole.y0 + hole.y1) / 2, z, tag + '-right'));
  }

  // 法线朝 X 的墙（Z-Y 面），带矩形洞
  function wallYZ(parent, z0, z1, y0, y1, x, t, mat, hole, tag) {
    if (!hole) { add(parent, mesh(t, y1 - y0, z1 - z0, mat, x, (y0 + y1) / 2, (z0 + z1) / 2, tag)); return; }
    if (hole.y0 > y0 + 0.001) add(parent, mesh(t, hole.y0 - y0, z1 - z0, mat, x, (y0 + hole.y0) / 2, (z0 + z1) / 2, tag + '-bottom'));
    if (hole.y1 < y1 - 0.001) add(parent, mesh(t, y1 - hole.y1, z1 - z0, mat, x, (y1 + hole.y1) / 2, (z0 + z1) / 2, tag + '-top'));
    if (hole.z0 > z0 + 0.001) add(parent, mesh(t, hole.y1 - hole.y0, hole.z0 - z0, mat, x, (hole.y0 + hole.y1) / 2, (z0 + hole.z0) / 2, tag + '-back'));
    if (hole.z1 < z1 - 0.001) add(parent, mesh(t, hole.y1 - hole.y0, z1 - hole.z1, mat, x, (hole.y0 + hole.y1) / 2, (hole.z1 + z1) / 2, tag + '-front'));
  }
})(window);
