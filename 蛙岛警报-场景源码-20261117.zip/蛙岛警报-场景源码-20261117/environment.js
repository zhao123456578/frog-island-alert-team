/* ============================================================
 * environment.js — 街区环境物件（低多边形 / 纯几何体 / 无外部资源）
 * 依赖：全局 THREE（传统 <script> 标签）
 * 注册：window.GameModels.Environment / Road / Sidewalk / Crosswalk
 *       / AssemblyPoint / StreetLamp / Tree / Bench / TrashBin
 *       / Railing / Signboard / Billboard / PowerPole
 * 约定：1 单位 = 1 米；每个物件原点在自己脚下（Y = 0）；Y 轴向上
 * 说明：只负责生成并返回 Group，位置/旋转/缩放一律写在 scene-layout.js。
 * ============================================================ */
(function (global) {
  'use strict';

  var NS = global.GameModels = global.GameModels || {};

  /* ---------------- 本文件私有工具 ---------------- */
  var UNIT_BOX = null;
  var HELPER = null;

  function unitBox() {
    if (!UNIT_BOX) UNIT_BOX = new THREE.BoxGeometry(1, 1, 1);
    return UNIT_BOX;
  }

  function helper() {
    if (!HELPER) HELPER = new THREE.Object3D();
    return HELPER;
  }

  function solid(color, roughness, metalness, emissive, emissiveIntensity) {
    var m = new THREE.MeshStandardMaterial({
      color: color,
      roughness: roughness === undefined ? 0.94 : roughness,
      metalness: metalness === undefined ? 0.02 : metalness,
      flatShading: true
    });
    if (emissive !== undefined && emissive !== null) {
      m.emissive = new THREE.Color(emissive);
      m.emissiveIntensity = emissiveIntensity === undefined ? 1 : emissiveIntensity;
    }
    return m;
  }

  function mesh(w, h, d, mat, x, y, z, name) {
    var m = new THREE.Mesh(unitBox(), mat);
    m.scale.set(w, h, d);
    m.position.set(x || 0, y || 0, z || 0);
    m.castShadow = true;
    m.receiveShadow = true;
    if (name) m.name = name;
    return m;
  }

  function plate(w, d, mat, x, z, top, thick, name) {
    return mesh(w, thick, d, mat, x, top - thick / 2, z, name);
  }

  function cylinder(rTop, rBottom, h, seg, mat, x, y, z, name) {
    var m = new THREE.Mesh(new THREE.CylinderGeometry(rTop, rBottom, h, seg), mat);
    m.position.set(x || 0, y || 0, z || 0);
    m.castShadow = true;
    m.receiveShadow = true;
    if (name) m.name = name;
    return m;
  }

  function instanced(list, mat, name) {
    if (!list.length) return null;
    var m = new THREE.InstancedMesh(unitBox(), mat, list.length);
    var dummy = helper();
    for (var i = 0; i < list.length; i++) {
      var t = list[i];
      dummy.position.set(t.p[0], t.p[1], t.p[2]);
      dummy.rotation.set(t.r ? t.r[0] : 0, t.r ? t.r[1] : 0, t.r ? t.r[2] : 0);
      dummy.scale.set(t.s[0], t.s[1], t.s[2]);
      dummy.updateMatrix();
      m.setMatrixAt(i, dummy.matrix);
    }
    m.instanceMatrix.needsUpdate = true;
    m.castShadow = true;
    m.receiveShadow = true;
    if (name) m.name = name;
    return m;
  }

  function add(parent, child) {
    if (child) parent.add(child);
  }

  // 标记可站立面（主程序用向下射线取地面高度）
  function walk(m) {
    if (m) m.userData.walk = true;
    return m;
  }

  // 统一注册：保证返回值一定是 Group，失败时抛出带物件名的错误
  function define(name, build) {
    NS[name] = function (options) {
      if (!global.THREE) throw new Error(name + ' model failed: THREE is not loaded');
      try {
        var g = build(options || {});
        if (!g || !g.isObject3D) throw new Error('builder did not return a THREE.Group');
        g.name = g.name || name;
        return g;
      } catch (err) {
        throw new Error(name + ' model failed: ' + (err && err.message ? err.message : String(err)));
      }
    };
  }

  /* ============================================================
   * 1. 街区底板（地面 + 前广场 + 后院 + 绿地）
   * ============================================================ */
  define('Environment', function (o) {
    var W = o.width || 140;
    var D = o.depth || 140;
    var g = new THREE.Group();
    g.name = 'Environment';

    var matBase = solid(0xa4a698, 0.98, 0.0);
    var matPlaza = solid(0xbdb6a3, 0.95, 0.0);
    var matAsphalt = solid(0x8e9089, 0.98, 0.0);
    var matLawn = solid(0x7d9a67, 0.98, 0.0);

    // 底板顶面正好在 Y = 0，建筑可直接坐在上面
    add(g, walk(mesh(W, 0.6, D, matBase, 0, -0.3, 0, 'ground-slab')));

    // 建筑前广场（铺装）
    add(g, walk(plate(96, 5.8, matPlaza, 0, 12.1, 0.03, 0.06, 'plaza-front')));

    // 后院服务场地
    add(g, walk(plate(40, 16, matAsphalt, 0, -16, 0.04, 0.08, 'service-yard')));

    // 绿地
    add(g, walk(plate(24, 14, matLawn, -38, -22, 0.05, 0.1, 'lawn-left')));
    add(g, walk(plate(20, 16, matLawn, 36, -20, 0.05, 0.1, 'lawn-right')));

    return g;
  });

  /* ============================================================
   * 2. 道路（沥青 + 中心虚线 + 两侧边线）
   * ============================================================ */
  define('Road', function (o) {
    var L = o.length || 120;
    var W = o.width || 8;
    var g = new THREE.Group();
    g.name = 'Road';

    var matAsphalt = solid(0x53565a, 0.97, 0.0);
    var matLine = solid(0xe4dfcd, 0.9, 0.0);

    // 路面顶面 Y = 0.04
    add(g, walk(mesh(L, 0.12, W, matAsphalt, 0, -0.02, 0, 'asphalt')));

    // 中心虚线
    var dashes = [];
    var dashLen = 2.4, dashGap = 2.4;
    for (var x = -L / 2 + dashLen / 2; x < L / 2; x += dashLen + dashGap) {
      dashes.push({ p: [x, 0.05, 0], s: [dashLen, 0.02, 0.16] });
    }
    add(g, instanced(dashes, matLine, 'lane-dashes'));

    // 两侧边线
    add(g, mesh(L, 0.02, 0.12, matLine, 0, 0.05, W / 2 - 0.4, 'edge-line-r'));
    add(g, mesh(L, 0.02, 0.12, matLine, 0, 0.05, -W / 2 + 0.4, 'edge-line-l'));

    return g;
  });

  /* ============================================================
   * 3. 人行道（铺装 + 靠 +Z 侧路缘石 + 分缝）
   * ============================================================ */
  define('Sidewalk', function (o) {
    var L = o.length || 120;
    var W = o.width || 6;
    var H = o.height || 0.18;
    var g = new THREE.Group();
    g.name = 'Sidewalk';

    var matPaving = solid(0xc4beae, 0.95, 0.0);
    var matCurb = solid(0x8f9597, 0.85, 0.02);
    var matJoint = solid(0xb9b3a5, 0.96, 0.0);

    // 铺装顶面 Y = H
    add(g, walk(mesh(L, H, W, matPaving, 0, H / 2, 0, 'paving')));

    // 路缘石：位于 +Z 侧（摆到马路一侧时靠旋转调整）
    add(g, walk(mesh(L, H + 0.07, 0.3, matCurb, 0, (H + 0.07) / 2, W / 2 - 0.15, 'curb')));

    // 分缝
    var joints = [];
    for (var x = -L / 2 + 3; x < L / 2; x += 3) {
      joints.push({ p: [x, H + 0.004, 0], s: [0.05, 0.008, W - 0.5] });
    }
    add(g, instanced(joints, matJoint, 'paving-joints'));

    return g;
  });

  /* ============================================================
   * 4. 斑马线（沿 Z 方向过街，条纹沿 X 铺开）
   * ============================================================ */
  define('Crosswalk', function (o) {
    var W = o.width || 6;     // 过街宽度（X）
    var D = o.depth || 8;     // 跨路长度（Z）
    var g = new THREE.Group();
    g.name = 'Crosswalk';

    var matPaint = solid(0xece7d8, 0.9, 0.0);
    var stripe = 0.55, gap = 0.55;
    var list = [];
    var count = Math.max(1, Math.floor(D / (stripe + gap)));
    var start = -D / 2 + (D - (count * (stripe + gap) - gap)) / 2 + stripe / 2;
    for (var i = 0; i < count; i++) {
      list.push({ p: [0, 0.055, start + i * (stripe + gap)], s: [W, 0.02, stripe] });
    }
    add(g, instanced(list, matPaint, 'stripes'));

    return g;
  });

  /* ============================================================
   * 5. 集合点（黄色地坪 + 白边 + 圆环标识）
   * ============================================================ */
  define('AssemblyPoint', function (o) {
    var W = o.width || 12;
    var D = o.depth || 9;
    var g = new THREE.Group();
    g.name = 'AssemblyPoint';

    var matArea = solid(0xd9b34a, 0.9, 0.02);
    var matMark = solid(0xf2efe4, 0.85, 0.0);

    // 地坪顶面 Y = 0.06
    add(g, walk(plate(W, D, matArea, 0, 0, 0.06, 0.12, 'area')));

    // 白色边框
    var t = 0.24, e = 0.06;
    add(g, mesh(W, 0.02, t, matMark, 0, 0.07, D / 2 - t / 2 - 0.1, 'border-f'));
    add(g, mesh(W, 0.02, t, matMark, 0, 0.07, -D / 2 + t / 2 + 0.1, 'border-b'));
    add(g, mesh(t, 0.02, D, matMark, W / 2 - t / 2 - 0.1, 0.07, 0, 'border-r'));
    add(g, mesh(t, 0.02, D, matMark, -W / 2 + t / 2 + 0.1, 0.07, 0, 'border-l'));

    // 中心圆环
    var ring = new THREE.Mesh(new THREE.RingGeometry(1.5, 1.86, 24), matMark);
    ring.rotation.x = -Math.PI / 2;
    ring.position.y = 0.075;
    ring.receiveShadow = true;
    ring.name = 'ring';
    add(g, ring);

    // 四角标识块
    [[1, 1], [1, -1], [-1, 1], [-1, -1]].forEach(function (s, i) {
      add(g, mesh(0.9, 0.02, 0.18, matMark,
        s[0] * (W / 2 - 1.2), 0.075, s[1] * (D / 2 - 1.2), 'corner-mark-' + i));
    });

    return g;
  });

  /* ============================================================
   * 6. 路灯（灯臂朝 +Z）
   * ============================================================ */
  define('StreetLamp', function (o) {
    var H = o.height || 7;
    var g = new THREE.Group();
    g.name = 'StreetLamp';

    var matPole = solid(0x6e7a80, 0.6, 0.35);
    var matHead = solid(0x545f66, 0.55, 0.4);
    var matBulb = solid(0xfff0c8, 0.4, 0.0, 0xffe7ad, 1.1);

    add(g, cylinder(0.26, 0.32, 0.5, 8, matPole, 0, 0.25, 0, 'base'));
    add(g, cylinder(0.09, 0.13, H - 0.4, 8, matPole, 0, (H + 0.4) / 2, 0, 'pole'));
    add(g, mesh(0.14, 0.14, 1.9, matPole, 0, H - 0.3, 0.95, 'arm'));
    add(g, mesh(0.46, 0.18, 0.95, matHead, 0, H - 0.42, 1.9, 'head'));
    add(g, mesh(0.38, 0.06, 0.78, matBulb, 0, H - 0.53, 1.9, 'bulb'));

    return g;
  });

  /* ============================================================
   * 7. 行道树（树池 + 树干 + 三团树冠）
   * ============================================================ */
  define('Tree', function (o) {
    var g = new THREE.Group();
    g.name = 'Tree';

    var matGrate = solid(0x6f6b60, 0.95, 0.0);
    var matTrunk = solid(0x6b4f3a, 0.95, 0.0);
    var matLeafA = solid(0x5f8f4e, 0.92, 0.0);
    var matLeafB = solid(0x6fa057, 0.92, 0.0);

    add(g, plate(1.7, 1.7, matGrate, 0, 0, 0.06, 0.12, 'tree-grate'));
    add(g, cylinder(0.13, 0.2, 2.5, 6, matTrunk, 0, 1.31, 0, 'trunk'));

    var crown = [
      { r: 1.4, p: [0, 3.25, 0], m: matLeafA },
      { r: 1.05, p: [0.58, 4.05, 0.24], m: matLeafB },
      { r: 0.92, p: [-0.6, 3.75, -0.3], m: matLeafB }
    ];
    crown.forEach(function (c, i) {
      var leaf = new THREE.Mesh(new THREE.IcosahedronGeometry(c.r, 0), c.m);
      leaf.position.set(c.p[0], c.p[1], c.p[2]);
      leaf.castShadow = true;
      leaf.receiveShadow = true;
      leaf.name = 'crown-' + i;
      add(g, leaf);
    });

    return g;
  });

  /* ============================================================
   * 8. 长椅（面朝 +Z）
   * ============================================================ */
  define('Bench', function (o) {
    var W = o.width || 2.1;
    var g = new THREE.Group();
    g.name = 'Bench';

    var matWood = solid(0xb07a45, 0.85, 0.02);
    var matSteel = solid(0x5b646b, 0.6, 0.4);

    add(g, mesh(W, 0.1, 0.55, matWood, 0, 0.46, 0, 'seat'));

    var back = mesh(W, 0.44, 0.09, matWood, 0, 0.72, -0.26, 'back');
    back.rotation.x = -0.14;
    add(g, back);

    [-0.82, 0.82].forEach(function (x, i) {
      add(g, mesh(0.09, 0.46, 0.5, matSteel, x * (W / 2.1), 0.23, 0, 'leg-' + i));
      add(g, mesh(0.08, 0.34, 0.08, matSteel, x * (W / 2.1), 0.62, -0.24, 'back-post-' + i));
    });

    return g;
  });

  /* ============================================================
   * 9. 垃圾桶
   * ============================================================ */
  define('TrashBin', function (o) {
    var g = new THREE.Group();
    g.name = 'TrashBin';

    var matBody = solid(0x4c6b5a, 0.85, 0.05);
    var matLid = solid(0x35443c, 0.7, 0.15);

    add(g, cylinder(0.26, 0.3, 0.85, 8, matBody, 0, 0.43, 0, 'body'));
    add(g, cylinder(0.33, 0.33, 0.09, 8, matLid, 0, 0.9, 0, 'lid'));
    add(g, mesh(0.3, 0.06, 0.1, matLid, 0, 0.86, 0.24, 'slot'));

    return g;
  });

  /* ============================================================
   * 10. 护栏（默认 8 米一段，立柱每 2 米）
   * ============================================================ */
  define('Railing', function (o) {
    var L = o.length || 8;
    var H = o.height || 1.05;
    var g = new THREE.Group();
    g.name = 'Railing';

    var matSteel = solid(0x8a949b, 0.55, 0.45);

    add(g, mesh(L, 0.07, 0.07, matSteel, 0, H, 0, 'rail-top'));
    add(g, mesh(L, 0.06, 0.06, matSteel, 0, H * 0.55, 0, 'rail-mid'));

    var posts = [];
    var n = Math.max(2, Math.round(L / 2) + 1);
    for (var i = 0; i < n; i++) {
      posts.push({ p: [-L / 2 + (L / (n - 1)) * i, H / 2, 0], s: [0.08, H, 0.08] });
    }
    add(g, instanced(posts, matSteel, 'posts'));

    return g;
  });

  /* ============================================================
   * 11. 指示牌（立柱 + 牌面 + 抽象文字条）
   * ============================================================ */
  define('Signboard', function (o) {
    var W = o.width || 2.4;
    var g = new THREE.Group();
    g.name = 'Signboard';

    var matPost = solid(0x6f7a80, 0.6, 0.35);
    var matPanel = solid(0x2f5d8a, 0.75, 0.05, 0x2f5d8a, 0.22);
    var matMark = solid(0xf1f3ee, 0.8, 0.0);
    var matAccent = solid(0xd9b34a, 0.8, 0.02);

    [-1, 1].forEach(function (s, i) {
      add(g, mesh(0.1, 2.2, 0.1, matPost, s * (W / 2 - 0.4), 1.1, 0, 'post-' + i));
    });

    add(g, mesh(W, 0.92, 0.09, matPanel, 0, 1.9, 0, 'panel'));
    add(g, mesh(W + 0.12, 0.14, 0.12, matAccent, 0, 2.4, 0, 'panel-top'));

    // 三条抽象文字（不用字体/贴图）
    add(g, mesh(W * 0.62, 0.07, 0.02, matMark, 0, 2.08, 0.055, 'text-1'));
    add(g, mesh(W * 0.44, 0.07, 0.02, matMark, 0, 1.9, 0.055, 'text-2'));
    add(g, mesh(W * 0.3, 0.07, 0.02, matMark, 0, 1.72, 0.055, 'text-3'));

    return g;
  });

  /* ============================================================
   * 12. 广告牌（大面板，只做色块，不使用贴图）
   * ============================================================ */
  define('Billboard', function (o) {
    var W = o.width || 8;
    var H = o.height || 4;
    var baseH = 1.1;
    var g = new THREE.Group();
    g.name = 'Billboard';

    var matPost = solid(0x616b71, 0.6, 0.4);
    var matPanel = solid(0xdcd8cc, 0.85, 0.0, 0xf6f2e6, 0.18);
    var matBlue = solid(0x33628f, 0.8, 0.02);
    var matOrange = solid(0xc4562f, 0.8, 0.02);
    var matAccent = solid(0x2b333a, 0.7, 0.2);

    [-1, 1].forEach(function (s, i) {
      add(g, mesh(0.26, baseH + H * 0.3, 0.26, matPost, s * (W / 2 - 0.9), (baseH + H * 0.3) / 2, -0.24, 'post-' + i));
    });

    add(g, mesh(W, H, 0.3, matPanel, 0, baseH + H / 2, 0, 'panel'));
    add(g, mesh(W + 0.3, 0.32, 0.42, matAccent, 0, baseH + H + 0.16, 0, 'frame-top'));
    add(g, mesh(W + 0.16, 0.18, 0.36, matAccent, 0, baseH - 0.09, 0, 'frame-bottom'));
    // 底部横撑，让面板与立柱关系更明确
    add(g, mesh(W - 1.6, 0.12, 0.12, matPost, 0, baseH + 0.12, -0.24, 'cross-bar'));

    // 面板上的抽象画面（色块，无文字）
    add(g, mesh(W * 0.34, H * 0.62, 0.04, matBlue, -W * 0.26, baseH + H * 0.56, 0.17, 'art-block'));
    add(g, mesh(W * 0.56, 0.16, 0.04, matOrange, W * 0.14, baseH + H * 0.44, 0.17, 'art-line-1'));
    add(g, mesh(W * 0.4, 0.12, 0.04, matAccent, W * 0.2, baseH + H * 0.3, 0.17, 'art-line-2'));

    return g;
  });

  /* ============================================================
   * 13. 电线杆（杆体 + 横担 + 绝缘子）
   * ============================================================ */
  define('PowerPole', function (o) {
    var H = o.height || 9;
    var g = new THREE.Group();
    g.name = 'PowerPole';

    var matConcrete = solid(0xa9a79c, 0.95, 0.0);
    var matArm = solid(0x6f6555, 0.9, 0.0);
    var matInsulator = solid(0x7d8a90, 0.4, 0.1);

    add(g, cylinder(0.13, 0.2, H, 8, matConcrete, 0, H / 2, 0, 'pole'));
    add(g, mesh(2.4, 0.14, 0.14, matArm, 0, H - 0.75, 0, 'crossarm'));
    add(g, mesh(1.0, 0.1, 0.1, matArm, 0, H - 1.45, 0, 'brace'));

    [-0.9, 0, 0.9].forEach(function (x, i) {
      add(g, cylinder(0.06, 0.07, 0.22, 6, matInsulator, x, H - 0.58, 0, 'insulator-' + i));
    });

    return g;
  });
})(window);
