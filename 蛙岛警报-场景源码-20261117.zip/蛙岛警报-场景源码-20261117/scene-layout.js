/* ============================================================
 * scene-layout.js — 场景布局数据（坐标 / 旋转 / 缩放 / 碰撞）
 * 加载顺序：three.js -> building.js -> environment.js -> scene-layout.js -> 主程序
 * 约定：1 单位 = 1 米；Y 轴向上；position 为物件原点（多数在脚下）
 * 说明：本文件只有数据，不含任何模型或逻辑代码。
 *       主程序遍历 SCENE_LAYOUT.objects 时，按 model 取 window.GameModels[model] 实例化。
 * ============================================================ */
(function (global) {
  'use strict';

  global.SCENE_LAYOUT = {
    units: 'meter',
    up: 'y',

    // 街区底板范围（玩家活动边界，防止走出地面）
    bounds: { size: [140, 140] },

    // 角色出生点（脚底坐标）：站在对面人行道上，正对大楼
    spawn: { position: [0, 0.18, 33.2], rotation: [0, Math.PI, 0] },

    objects: [

      /* ============ 地面 / 道路系统 ============ */
      // 街区底板：顶面 Y = 0，建筑与所有物件都坐落在它上面
      { id: 'ground', model: 'Environment', position: [0, 0, 0], rotation: [0, 0, 0], scale: [1, 1, 1], collision: { type: 'none' } },

      // 车行道（长 120 × 宽 8），中心线 Z = 25，路缘范围 21 ~ 29
      { id: 'road-main', model: 'Road', position: [0, 0, 25], rotation: [0, 0, 0], scale: [1, 1, 1], collision: { type: 'none' } },

      // 近侧人行道：Z 15 ~ 21，铺装顶面 Y = 0.18，路缘石在 +Z（靠马路）一侧
      { id: 'sidewalk-front', model: 'Sidewalk', position: [0, 0, 18], rotation: [0, 0, 0], scale: [1, 1, 1], collision: { type: 'none' } },
      // 远侧人行道：Z 29 ~ 35，旋转 180° 让路缘石朝向马路
      { id: 'sidewalk-far', model: 'Sidewalk', position: [0, 0, 32], rotation: [0, Math.PI, 0], scale: [1, 1, 1], collision: { type: 'none' } },

      // 斑马线：横跨 Z 21 ~ 29
      { id: 'crosswalk-main', model: 'Crosswalk', position: [26, 0, 25], rotation: [0, 0, 0], scale: [1, 1, 1], collision: { type: 'none' } },

      // 集合点（空旷区，位于建筑左侧空地）
      { id: 'assembly-point', model: 'AssemblyPoint', position: [-30, 0, 2], rotation: [0, 0, 0], scale: [1, 1, 1], collision: { type: 'none' } },

      /* ============ 主楼 ============ */
      // 30m 宽 × 20m 深 × 45m 高，原点在底面中心。
      // 塔楼是空腔，碰撞按「裙楼 + 四片外墙」分块，左墙在 8F 留出电梯门洞，
      // 这样玩家从室外电梯进到楼内时不会被整块 AABB 弹出去。
      // options.openings 与 interior.js 共用同一组开洞尺寸。
      {
        id: 'mainBuilding', model: 'Building',
        position: [0, 0, 0], rotation: [0, 0, 0], scale: [1, 1, 1],
        options: { openings: GameModels.Interior.OPENINGS, lobbyVoid: GameModels.Interior.STAIR_VOID },
        collision: {
          type: 'aabbs',
          boxes: [
            // 裙楼：门厅（正面留出入口门洞 5.2 × 3.75）
            { size: [13.6, 6.43, 0.6], offset: [-9.4, 3.215, 10.9] },
            { size: [13.6, 6.43, 0.6], offset: [9.4, 3.215, 10.9] },
            { size: [5.2, 2.68, 0.6], offset: [0, 5.09, 10.9] },
            { size: [32.4, 6.43, 0.6], offset: [0, 3.215, -10.9] },
            { size: [0.6, 6.43, 21.2], offset: [-15.9, 3.215, 0] },
            { size: [0.6, 6.43, 21.2], offset: [15.9, 3.215, 0] },
            // 塔楼墙体从裙楼顶（6.43）起算，别把门厅挡死
            { size: [30, 38.57, 0.6], offset: [0, 25.715, 9.7] },     // 前墙
            { size: [30, 38.57, 0.6], offset: [0, 25.715, -9.7] },    // 后墙
            { size: [0.6, 38.57, 18.8], offset: [14.7, 25.715, 0] },  // 右墙
            { size: [0.6, 16.07, 18.8], offset: [-14.7, 14.465, 0] }, // 左墙：门洞以下
            { size: [0.6, 20.3, 18.8], offset: [-14.7, 34.85, 0] },   // 左墙：门洞以上
            { size: [0.6, 2.2, 2.9], offset: [-14.7, 23.6, -7.95] },  // 左墙：门洞后段
            { size: [0.6, 2.2, 13.9], offset: [-14.7, 23.6, 2.45] },  // 左墙：门洞前段
            { size: [30, 0.8, 20], offset: [0, 45.2, 0] }             // 屋面
          ]
        }
      },

      // 楼内房间 + 入户玻璃电梯（模型自带墙体/家具碰撞与室内灯光）
      { id: 'interior', model: 'Interior', position: [0, 0, 0], rotation: [0, 0, 0], scale: [1, 1, 1], collision: { type: 'none' } },

      /* ============ 街道设施（近侧人行道，Y = 0.18 为人行道面） ============ */
      { id: 'lamp-front-01', model: 'StreetLamp', position: [-56, 0.18, 20.3], rotation: [0, 0, 0], scale: [1, 1, 1], collision: { type: 'aabb', size: [0.5, 7, 0.5], offset: [0, 3.5, 0] } },
      { id: 'lamp-front-02', model: 'StreetLamp', position: [-40, 0.18, 20.3], rotation: [0, 0, 0], scale: [1, 1, 1], collision: { type: 'aabb', size: [0.5, 7, 0.5], offset: [0, 3.5, 0] } },
      { id: 'lamp-front-03', model: 'StreetLamp', position: [-24, 0.18, 20.3], rotation: [0, 0, 0], scale: [1, 1, 1], collision: { type: 'aabb', size: [0.5, 7, 0.5], offset: [0, 3.5, 0] } },
      { id: 'lamp-front-04', model: 'StreetLamp', position: [-8, 0.18, 20.3], rotation: [0, 0, 0], scale: [1, 1, 1], collision: { type: 'aabb', size: [0.5, 7, 0.5], offset: [0, 3.5, 0] } },
      { id: 'lamp-front-05', model: 'StreetLamp', position: [8, 0.18, 20.3], rotation: [0, 0, 0], scale: [1, 1, 1], collision: { type: 'aabb', size: [0.5, 7, 0.5], offset: [0, 3.5, 0] } },
      { id: 'lamp-front-06', model: 'StreetLamp', position: [20, 0.18, 20.3], rotation: [0, 0, 0], scale: [1, 1, 1], collision: { type: 'aabb', size: [0.5, 7, 0.5], offset: [0, 3.5, 0] } },
      { id: 'lamp-front-07', model: 'StreetLamp', position: [38, 0.18, 20.3], rotation: [0, 0, 0], scale: [1, 1, 1], collision: { type: 'aabb', size: [0.5, 7, 0.5], offset: [0, 3.5, 0] } },
      { id: 'lamp-front-08', model: 'StreetLamp', position: [54, 0.18, 20.3], rotation: [0, 0, 0], scale: [1, 1, 1], collision: { type: 'aabb', size: [0.5, 7, 0.5], offset: [0, 3.5, 0] } },

      { id: 'tree-front-01', model: 'Tree', position: [-52, 0.18, 16.8], rotation: [0, 0.4, 0], scale: [1.05, 1, 1.05], collision: { type: 'aabb', size: [1.2, 2.6, 1.2], offset: [0, 1.3, 0] } },
      { id: 'tree-front-02', model: 'Tree', position: [-36, 0.18, 16.8], rotation: [0, 2.1, 0], scale: [1, 1.1, 1], collision: { type: 'aabb', size: [1.2, 2.6, 1.2], offset: [0, 1.3, 0] } },
      { id: 'tree-front-03', model: 'Tree', position: [-20, 0.18, 16.8], rotation: [0, 4.0, 0], scale: [1.1, 0.95, 1.1], collision: { type: 'aabb', size: [1.2, 2.6, 1.2], offset: [0, 1.3, 0] } },
      { id: 'tree-front-04', model: 'Tree', position: [12, 0.18, 16.8], rotation: [0, 1.2, 0], scale: [1.15, 1.05, 1.15], collision: { type: 'aabb', size: [1.2, 2.6, 1.2], offset: [0, 1.3, 0] } },
      { id: 'tree-front-05', model: 'Tree', position: [34, 0.18, 16.8], rotation: [0, 3.3, 0], scale: [1, 1, 1], collision: { type: 'aabb', size: [1.2, 2.6, 1.2], offset: [0, 1.3, 0] } },
      { id: 'tree-front-06', model: 'Tree', position: [52, 0.18, 16.8], rotation: [0, 5.1, 0], scale: [1.1, 1.12, 1.1], collision: { type: 'aabb', size: [1.2, 2.6, 1.2], offset: [0, 1.3, 0] } },

      // 护栏：沿路缘排列，入口正前方（X -8 ~ 8）与斑马线（X 23 ~ 29）留出通行口
      { id: 'railing-01', model: 'Railing', position: [-52, 0.18, 20.5], rotation: [0, 0, 0], scale: [1, 1, 1], collision: { type: 'aabb', size: [8, 1.05, 0.24], offset: [0, 0.525, 0] } },
      { id: 'railing-02', model: 'Railing', position: [-44, 0.18, 20.5], rotation: [0, 0, 0], scale: [1, 1, 1], collision: { type: 'aabb', size: [8, 1.05, 0.24], offset: [0, 0.525, 0] } },
      { id: 'railing-03', model: 'Railing', position: [-36, 0.18, 20.5], rotation: [0, 0, 0], scale: [1, 1, 1], collision: { type: 'aabb', size: [8, 1.05, 0.24], offset: [0, 0.525, 0] } },
      { id: 'railing-04', model: 'Railing', position: [-28, 0.18, 20.5], rotation: [0, 0, 0], scale: [1, 1, 1], collision: { type: 'aabb', size: [8, 1.05, 0.24], offset: [0, 0.525, 0] } },
      { id: 'railing-05', model: 'Railing', position: [-20, 0.18, 20.5], rotation: [0, 0, 0], scale: [1, 1, 1], collision: { type: 'aabb', size: [8, 1.05, 0.24], offset: [0, 0.525, 0] } },
      { id: 'railing-06', model: 'Railing', position: [-12, 0.18, 20.5], rotation: [0, 0, 0], scale: [1, 1, 1], collision: { type: 'aabb', size: [8, 1.05, 0.24], offset: [0, 0.525, 0] } },
      { id: 'railing-09', model: 'Railing', position: [12, 0.18, 20.5], rotation: [0, 0, 0], scale: [1, 1, 1], collision: { type: 'aabb', size: [8, 1.05, 0.24], offset: [0, 0.525, 0] } },
      { id: 'railing-10', model: 'Railing', position: [36, 0.18, 20.5], rotation: [0, 0, 0], scale: [1, 1, 1], collision: { type: 'aabb', size: [8, 1.05, 0.24], offset: [0, 0.525, 0] } },
      { id: 'railing-11', model: 'Railing', position: [44, 0.18, 20.5], rotation: [0, 0, 0], scale: [1, 1, 1], collision: { type: 'aabb', size: [8, 1.05, 0.24], offset: [0, 0.525, 0] } },
      { id: 'railing-12', model: 'Railing', position: [52, 0.18, 20.5], rotation: [0, 0, 0], scale: [1, 1, 1], collision: { type: 'aabb', size: [8, 1.05, 0.24], offset: [0, 0.525, 0] } },

      /* ============ 远侧人行道 ============ */
      { id: 'lamp-far-01', model: 'StreetLamp', position: [-32, 0.18, 29.7], rotation: [0, Math.PI, 0], scale: [1, 1, 1], collision: { type: 'aabb', size: [0.5, 7, 0.5], offset: [0, 3.5, 0] } },
      { id: 'lamp-far-02', model: 'StreetLamp', position: [12, 0.18, 29.7], rotation: [0, Math.PI, 0], scale: [1, 1, 1], collision: { type: 'aabb', size: [0.5, 7, 0.5], offset: [0, 3.5, 0] } },
      { id: 'lamp-far-03', model: 'StreetLamp', position: [40, 0.18, 29.7], rotation: [0, Math.PI, 0], scale: [1, 1, 1], collision: { type: 'aabb', size: [0.5, 7, 0.5], offset: [0, 3.5, 0] } },

      { id: 'tree-far-01', model: 'Tree', position: [-44, 0.18, 33.2], rotation: [0, 2.6, 0], scale: [1.1, 1, 1.1], collision: { type: 'aabb', size: [1.2, 2.6, 1.2], offset: [0, 1.3, 0] } },
      { id: 'tree-far-02', model: 'Tree', position: [-12, 0.18, 33.2], rotation: [0, 0.9, 0], scale: [1, 1.08, 1], collision: { type: 'aabb', size: [1.2, 2.6, 1.2], offset: [0, 1.3, 0] } },
      { id: 'tree-far-03', model: 'Tree', position: [20, 0.18, 33.2], rotation: [0, 4.4, 0], scale: [1.12, 0.96, 1.12], collision: { type: 'aabb', size: [1.2, 2.6, 1.2], offset: [0, 1.3, 0] } },
      { id: 'tree-far-04', model: 'Tree', position: [48, 0.18, 33.2], rotation: [0, 1.7, 0], scale: [1, 1.05, 1], collision: { type: 'aabb', size: [1.2, 2.6, 1.2], offset: [0, 1.3, 0] } },

      { id: 'pole-01', model: 'PowerPole', position: [44, 0.18, 30.6], rotation: [0, 0.2, 0], scale: [1, 1, 1], collision: { type: 'aabb', size: [0.6, 9, 0.6], offset: [0, 4.5, 0] } },
      { id: 'pole-02', model: 'PowerPole', position: [-44, 0.18, 30.6], rotation: [0, -0.15, 0], scale: [1, 1, 1], collision: { type: 'aabb', size: [0.6, 9, 0.6], offset: [0, 4.5, 0] } },

      /* ============ 前广场（Y = 0.03 为广场铺装面） ============ */
      { id: 'bench-01', model: 'Bench', position: [-11, 0.03, 12.8], rotation: [0, Math.PI, 0], scale: [1, 1, 1], collision: { type: 'aabb', size: [2.1, 0.95, 0.6], offset: [0, 0.475, 0] } },
      { id: 'bench-02', model: 'Bench', position: [13, 0.03, 12.8], rotation: [0, Math.PI, 0], scale: [1, 1, 1], collision: { type: 'aabb', size: [2.1, 0.95, 0.6], offset: [0, 0.475, 0] } },

      { id: 'bin-01', model: 'TrashBin', position: [-7.6, 0.03, 12.6], rotation: [0, 0.3, 0], scale: [1, 1, 1], collision: { type: 'none' } },
      { id: 'bin-02', model: 'TrashBin', position: [16.4, 0.03, 12.6], rotation: [0, -0.2, 0], scale: [1, 1, 1], collision: { type: 'none' } },

      // 入口导视牌（门厅右侧）
      { id: 'sign-main', model: 'Signboard', position: [7.6, 0.03, 12.6], rotation: [0, -0.28, 0], scale: [1, 1, 1], collision: { type: 'none' } },
      // 集合点标识牌
      { id: 'sign-assembly', model: 'Signboard', position: [-23.2, 0, 7.4], rotation: [0, 0.35, 0], scale: [0.9, 0.9, 0.9], collision: { type: 'none' } },

      // 广告牌（空地左侧、朝向街口）
      { id: 'billboard-01', model: 'Billboard', position: [-44, 0.03, 10], rotation: [0, 0.9, 0], scale: [1, 1, 1], collision: { type: 'aabb', size: [8.4, 5.5, 0.6], offset: [0, 2.75, 0] } },

      /* ============ 后场绿化（Y = 0.05 为草地表面） ============ */
      { id: 'tree-back-01', model: 'Tree', position: [-34, 0.05, -18], rotation: [0, 1.9, 0], scale: [1.15, 1.15, 1.15], collision: { type: 'aabb', size: [1.2, 2.6, 1.2], offset: [0, 1.3, 0] } },
      { id: 'tree-back-02', model: 'Tree', position: [30, 0.05, -16], rotation: [0, 3.8, 0], scale: [1, 1.2, 1], collision: { type: 'aabb', size: [1.2, 2.6, 1.2], offset: [0, 1.3, 0] } },
      { id: 'tree-back-03', model: 'Tree', position: [44, 0.05, -4], rotation: [0, 0.7, 0], scale: [1.1, 1, 1.1], collision: { type: 'aabb', size: [1.2, 2.6, 1.2], offset: [0, 1.3, 0] } }
    ]
  };
})(window);
