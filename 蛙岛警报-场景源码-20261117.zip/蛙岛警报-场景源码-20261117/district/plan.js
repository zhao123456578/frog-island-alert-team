/* ============================================================
 * plan.js — 云栖里住区 · 总平面图（Canvas 2D 制图）
 * 数据来源：window.SCENE_LAYOUT（district-layout.js）
 * 版式：左侧指标/图例栏 + 右侧总平面 + 右下角标题栏
 * ============================================================ */
(function () {
  'use strict';

  var LAYOUT = window.SCENE_LAYOUT;
  var canvas = document.getElementById('plan');
  var ctx = canvas.getContext('2d');
  var W = canvas.width, H = canvas.height;

  /* ---------------- 坐标映射 ---------------- */
  var S = 6.8;                    // 像素 / 米
  var MINX = -108, MINZ = -108;   // 图纸左上角对应世界坐标
  var OX = 493, OZ = 186;

  function X(x) { return OX + (x - MINX) * S; }
  function Z(z) { return OZ + (z - MINZ) * S; }
  function L(m) { return m * S; }

  /* ---------------- 配色 ---------------- */
  var C = {
    paper: '#f8f4e9',
    ink: '#2b363b',
    inkSoft: '#5c686d',
    site: '#edf0e0',
    siteEdge: '#b7b7a1',
    lawn: '#cfe3b4',
    lawnEdge: '#a3bf84',
    pave: '#dcd8c9',
    paveLine: '#c8c3b2',
    road: '#a9ada9',
    roadEdge: '#8d918d',
    walk: '#e7e2d2',
    walkEdge: '#c7c1af',
    water: '#a6cfdc',
    waterEdge: '#79a6b6',
    sand: '#e6d8b4',
    slab: '#f4e8d9',
    slabLine: '#715d4c',
    slabRoof: 'rgba(160, 110, 80, 0.14)',
    tower: '#dbe3e6',
    towerLine: '#2f4149',
    tree: '#a9cb85',
    treeEdge: '#7ea262',
    hedge: '#9dc47c',
    accent: '#c4562f'
  };

  var OBJ = {};
  LAYOUT.objects.forEach(function (o) { OBJ[o.id] = o; });

  function foot(o, w, d) {
    var r = (o && o.rotation && o.rotation[1]) || 0;
    return Math.abs(Math.sin(r)) > 0.5 ? [d, w] : [w, d];
  }

  function rect(x0, z0, x1, z1, fill, stroke, lw) {
    ctx.beginPath();
    ctx.rect(X(x0), Z(z0), L(x1 - x0), L(z1 - z0));
    if (fill) { ctx.fillStyle = fill; ctx.fill(); }
    if (stroke) { ctx.strokeStyle = stroke; ctx.lineWidth = lw || 1; ctx.stroke(); }
  }

  function rectPx(x, y, w, h, fill, stroke, lw) {
    ctx.beginPath();
    ctx.rect(x, y, w, h);
    if (fill) { ctx.fillStyle = fill; ctx.fill(); }
    if (stroke) { ctx.strokeStyle = stroke; ctx.lineWidth = lw || 1; ctx.stroke(); }
  }

  // 带旋转的矩形（铺装 / 绿篱等）
  function objRect(o, w, d, fill, stroke, lw) {
    var rot = (o.rotation && o.rotation[1]) || 0;
    if (Math.abs(rot) < 1e-4) {
      rect(o.position[0] - w / 2, o.position[2] - d / 2, o.position[0] + w / 2, o.position[2] + d / 2, fill, stroke, lw);
      return;
    }
    ctx.save();
    ctx.translate(X(o.position[0]), Z(o.position[2]));
    ctx.rotate(-rot);
    ctx.beginPath();
    ctx.rect(-L(w) / 2, -L(d) / 2, L(w), L(d));
    if (fill) { ctx.fillStyle = fill; ctx.fill(); }
    if (stroke) { ctx.strokeStyle = stroke; ctx.lineWidth = lw || 1; ctx.stroke(); }
    ctx.restore();
  }

  function circleW(cx, cz, r, fill, stroke, lw) {
    ctx.beginPath();
    ctx.arc(X(cx), Z(cz), L(r), 0, Math.PI * 2);
    if (fill) { ctx.fillStyle = fill; ctx.fill(); }
    if (stroke) { ctx.strokeStyle = stroke; ctx.lineWidth = lw || 1; ctx.stroke(); }
  }

  function text(str, x, z, size, color, weight, align, baseline) {
    ctx.font = (weight || '400') + ' ' + size + 'px "Microsoft YaHei", "PingFang SC", sans-serif';
    ctx.textAlign = align || 'center';
    ctx.textBaseline = baseline || 'middle';
    ctx.lineJoin = 'round';
    ctx.lineWidth = Math.max(3, size * 0.34);
    ctx.strokeStyle = 'rgba(250, 248, 240, 0.94)';
    ctx.strokeText(str, X(x), Z(z));
    ctx.fillStyle = color || C.ink;
    ctx.fillText(str, X(x), Z(z));
  }

  function pxText(str, x, y, size, color, weight, align, baseline) {
    ctx.font = (weight || '400') + ' ' + size + 'px "Microsoft YaHei", "PingFang SC", sans-serif';
    ctx.textAlign = align || 'left';
    ctx.textBaseline = baseline || 'alphabetic';
    ctx.fillStyle = color || C.ink;
    ctx.fillText(str, x, y);
  }

  /* ---------------- 光滑闭合曲线（Catmull-Rom → Bezier） ---------------- */
  function closedCurve(pts) {
    var n = pts.length;
    for (var i = 0; i < n; i++) {
      var p0 = pts[(i - 1 + n) % n], p1 = pts[i], p2 = pts[(i + 1) % n], p3 = pts[(i + 2) % n];
      var c1x = p1[0] + (p2[0] - p0[0]) / 6, c1y = p1[1] + (p2[1] - p0[1]) / 6;
      var c2x = p2[0] - (p3[0] - p1[0]) / 6, c2y = p2[1] - (p3[1] - p1[1]) / 6;
      ctx.bezierCurveTo(c1x, c1y, c2x, c2y, p2[0], p2[1]);
    }
    ctx.closePath();
  }

  function lagoonPoints() {
    var o = OBJ['lagoon'];
    var pts = [
      [-59, 4], [-54, -9], [-42, -21], [-25, -29], [-5, -30], [11, -23],
      [16, -11], [6, -1], [17, 8], [14, 21], [-2, 29], [-22, 31], [-42, 25], [-56, 15]
    ];
    return pts.map(function (p) {
      return [X(o.position[0] + p[0]), Z(o.position[2] + p[1])];
    });
  }

  /* ---------------- 1. 图纸底 + 场地边界 ---------------- */
  function drawSheet() {
    ctx.fillStyle = C.paper;
    ctx.fillRect(0, 0, W, H);

    ctx.save();
    ctx.strokeStyle = 'rgba(120, 118, 100, 0.05)';
    ctx.lineWidth = 1;
    for (var x = 0; x < W; x += 44) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke(); }
    for (var y = 0; y < H; y += 44) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke(); }
    ctx.restore();

    // 场地多边形
    var poly = [[-95, -25], [-25, -95], [90, -95], [90, 96], [-95, 96]];
    ctx.beginPath();
    ctx.moveTo(X(poly[0][0]), Z(poly[0][1]));
    for (var i = 1; i < poly.length; i++) ctx.lineTo(X(poly[i][0]), Z(poly[i][1]));
    ctx.closePath();
    ctx.fillStyle = C.site;
    ctx.fill();

    ctx.save();
    ctx.setLineDash([9, 6]);
    ctx.strokeStyle = C.siteEdge;
    ctx.lineWidth = 1.6;
    ctx.stroke();
    ctx.restore();
  }

  /* ---------------- 2. 道路 / 人行道 / 铺装 / 绿地 ---------------- */
  function drawGround() {
    // 铺装
    LAYOUT.objects.filter(function (o) { return o.model === 'Plaza'; }).forEach(function (o) {
      var w = o.options.width, d = o.options.depth;
      var rot = (o.rotation && o.rotation[1]) || 0;
      objRect(o, w, d, C.pave, null, 1);
      ctx.save();
      ctx.translate(X(o.position[0]), Z(o.position[2]));
      ctx.rotate(-rot);
      ctx.strokeStyle = C.paveLine;
      ctx.globalAlpha = 0.55;
      ctx.lineWidth = 0.8;
      for (var x = -w / 2 + 3; x < w / 2 - 0.2; x += 3) {
        ctx.beginPath(); ctx.moveTo(L(x), L(-d / 2)); ctx.lineTo(L(x), L(d / 2)); ctx.stroke();
      }
      for (var z = -d / 2 + 3; z < d / 2 - 0.2; z += 3) {
        ctx.beginPath(); ctx.moveTo(L(-w / 2), L(z)); ctx.lineTo(L(w / 2), L(z)); ctx.stroke();
      }
      ctx.restore();
    });

    // 草坪
    LAYOUT.objects.filter(function (o) { return o.model === 'Lawn'; }).forEach(function (o) {
      var f = foot(o, o.options.width, o.options.depth);
      var x0 = o.position[0] - f[0] / 2, z0 = o.position[2] - f[1] / 2;
      rect(x0, z0, x0 + f[0], z0 + f[1], C.lawn, null);
      ctx.save();
      ctx.strokeStyle = 'rgba(150, 178, 122, 0.25)';
      ctx.lineWidth = 0.9;
      for (var x = x0 + 2; x < x0 + f[0]; x += 2.4) {
        ctx.beginPath(); ctx.moveTo(X(x), Z(z0 + 0.3)); ctx.lineTo(X(x), Z(z0 + f[1] - 0.3)); ctx.stroke();
      }
      ctx.restore();
      rect(x0, z0, x0 + f[0], z0 + f[1], null, C.lawnEdge, 0.9);
    });

    // 绿篱
    LAYOUT.objects.filter(function (o) { return o.model === 'Hedge'; }).forEach(function (o) {
      objRect(o, o.options.length, o.options.thickness, C.hedge, '#8aad6c', 0.8);
    });

    // 道路
    LAYOUT.objects.filter(function (o) { return o.model === 'Road'; }).forEach(function (o) {
      var f = foot(o, o.options.length, o.options.width);
      var x0 = o.position[0] - f[0] / 2, z0 = o.position[2] - f[1] / 2;
      rect(x0 - 0.4, z0 - 0.4, x0 + f[0] + 0.4, z0 + f[1] + 0.4, C.roadEdge, null);
      rect(x0, z0, x0 + f[0], z0 + f[1], C.road, null);

      ctx.save();
      ctx.strokeStyle = 'rgba(250, 248, 238, 0.9)';
      ctx.lineWidth = 2;
      ctx.setLineDash([L(2.4), L(2.4)]);
      ctx.beginPath();
      if (f[0] > f[1]) {
        ctx.moveTo(X(x0 + 1), Z(o.position[2]));
        ctx.lineTo(X(x0 + f[0] - 1), Z(o.position[2]));
      } else {
        ctx.moveTo(X(o.position[0]), Z(z0 + 1));
        ctx.lineTo(X(o.position[0]), Z(z0 + f[1] - 1));
      }
      ctx.stroke();
      ctx.restore();
    });

    // 人行道
    LAYOUT.objects.filter(function (o) { return o.model === 'Sidewalk'; }).forEach(function (o) {
      var f = foot(o, o.options.length, o.options.width);
      var x0 = o.position[0] - f[0] / 2, z0 = o.position[2] - f[1] / 2;
      rect(x0, z0, x0 + f[0], z0 + f[1], C.walk, C.walkEdge, 0.9);
    });

    // 斑马线
    LAYOUT.objects.filter(function (o) { return o.model === 'Crosswalk'; }).forEach(function (o) {
      var f = foot(o, o.options.width, o.options.depth);
      var x0 = o.position[0] - f[0] / 2, z0 = o.position[2] - f[1] / 2;
      ctx.save();
      ctx.strokeStyle = 'rgba(252, 250, 242, 0.95)';
      ctx.lineWidth = L(0.55);
      for (var z = z0 + 0.4; z < z0 + f[1] - 0.2; z += 1.1) {
        ctx.beginPath(); ctx.moveTo(X(x0 + 0.2), Z(z)); ctx.lineTo(X(x0 + f[0] - 0.2), Z(z)); ctx.stroke();
      }
      ctx.restore();
    });
  }

  /* ---------------- 3. 水面 / 平台 / 停车 ---------------- */
  function drawWater() {
    var o = OBJ['lagoon'];
    if (!o) return;
    var pts = lagoonPoints();

    // 沙岸
    ctx.save();
    ctx.beginPath();
    var cx = 0, cy = 0;
    pts.forEach(function (p) { cx += p[0]; cy += p[1]; });
    cx /= pts.length; cy /= pts.length;
    var sandPts = pts.map(function (p) { return [cx + (p[0] - cx) * 1.08, cy + (p[1] - cy) * 1.08]; });
    ctx.moveTo(sandPts[0][0], sandPts[0][1]);
    closedCurve(sandPts);
    ctx.fillStyle = C.sand;
    ctx.fill();
    ctx.restore();

    // 水面
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(pts[0][0], pts[0][1]);
    closedCurve(pts);
    ctx.fillStyle = C.water;
    ctx.fill();
    ctx.strokeStyle = C.waterEdge;
    ctx.lineWidth = 1.4;
    ctx.stroke();
    ctx.restore();

    // 湖心岛
    var islands = o.options.islands || [];
    islands.forEach(function (it) {
      var wx = X(o.position[0] + it.x), wz = Z(o.position[2] + it.z);
      ctx.beginPath(); ctx.arc(wx, wz, L(it.r + 0.9), 0, Math.PI * 2);
      ctx.fillStyle = C.sand; ctx.fill();
      ctx.beginPath(); ctx.arc(wx, wz, L(it.r), 0, Math.PI * 2);
      ctx.fillStyle = C.lawn; ctx.fill();
      ctx.strokeStyle = C.lawnEdge; ctx.lineWidth = 0.9; ctx.stroke();
    });

    // 亲水圆台
    var deck = OBJ['round-deck'];
    if (deck) {
      circleW(deck.position[0], deck.position[2], 6.75, '#d7cfbe', '#a9a293', 1.2);
      circleW(deck.position[0], deck.position[2], 2.7, C.water, C.waterEdge, 1);
    }

    // 泳池
    var pool = OBJ['pool-small'];
    if (pool) {
      circleW(pool.position[0], pool.position[2], 4.9, '#d9d2c1', '#a9a293', 1.1);
      circleW(pool.position[0], pool.position[2], 4.3, C.water, C.waterEdge, 1.1);
    }
  }

  function drawParking() {
    var o = OBJ['parking-south'];
    if (!o) return;
    var f = foot(o, o.options.width, o.options.depth);
    var x0 = o.position[0] - f[0] / 2, z0 = o.position[2] - f[1] / 2;
    rect(x0, z0, x0 + f[0], z0 + f[1], '#deded6', '#bdbdb2', 1.1);

    var stalls = o.options.stalls;
    var sw = (f[0] - 1.6) / stalls;
    ctx.save();
    ctx.strokeStyle = 'rgba(255,255,255,0.9)';
    ctx.lineWidth = 1.1;
    for (var i = 0; i <= stalls; i++) {
      var x = x0 + 0.8 + i * sw;
      ctx.beginPath(); ctx.moveTo(X(x), Z(z0 + 0.6)); ctx.lineTo(X(x), Z(z0 + f[1] - 0.6)); ctx.stroke();
    }
    ctx.restore();

    // 车棚轮廓
    var cp = OBJ['carport'];
    if (cp) {
      ctx.save();
      ctx.setLineDash([6, 4]);
      ctx.strokeStyle = 'rgba(110, 120, 126, 0.75)';
      ctx.lineWidth = 1.2;
      ctx.strokeRect(X(cp.position[0] - 22), Z(cp.position[2] - 4.5), L(44), L(9));
      ctx.restore();
    }

    // 车
    LAYOUT.objects.filter(function (o2) { return o2.model === 'Car'; }).forEach(function (c) {
      var cf = foot(c, 1.9, 4.2);
      var cx0 = c.position[0] - cf[0] / 2, cz0 = c.position[2] - cf[1] / 2;
      rect(cx0, cz0, cx0 + cf[0], cz0 + cf[1], 'rgba(122, 134, 140, 0.7)', 'rgba(80,90,96,0.7)', 0.8);
    });
  }

  /* ---------------- 4. 建筑 ---------------- */
  function drawSlab(o) {
    var w = o.options.width, d = o.options.depth;
    var rot = o.rotation[1] || 0;
    var cx = X(o.position[0]), cz = Z(o.position[2]);
    var pw = L(w), pd = L(d);

    ctx.save();
    ctx.translate(cx, cz);
    ctx.rotate(-rot);

    // 投影
    ctx.fillStyle = 'rgba(90, 78, 54, 0.10)';
    ctx.fillRect(-pw / 2 + 4, -pd / 2 + 5, pw, pd);

    ctx.fillStyle = C.slab;
    ctx.fillRect(-pw / 2, -pd / 2, pw, pd);
    // 屋面示意（内收一圈）
    ctx.fillStyle = C.slabRoof;
    ctx.fillRect(-pw / 2 + 0.8, -pd / 2 + 0.8, pw - 1.6, pd - 1.6);

    ctx.strokeStyle = C.slabLine;
    ctx.lineWidth = 1.8;
    ctx.strokeRect(-pw / 2, -pd / 2, pw, pd);

    // 单元分缝 + 楼梯间
    ctx.strokeStyle = 'rgba(113, 93, 76, 0.5)';
    ctx.lineWidth = 0.9;
    var units = Math.round(w / 15);
    for (var i = 1; i < units; i++) {
      var x = -pw / 2 + (pw / units) * i;
      ctx.beginPath(); ctx.moveTo(x, -pd / 2); ctx.lineTo(x, pd / 2); ctx.stroke();
      ctx.fillStyle = 'rgba(113, 93, 76, 0.35)';
      ctx.fillRect(x - L(3), -pd / 2 + L(1), L(6), L(4));
    }
    ctx.restore();
  }

  function drawTower() {
    var o = OBJ['mainBuilding'];
    if (!o) return;
    var cx = o.position[0], cz = o.position[2];

    // 裙楼
    ctx.save();
    ctx.fillStyle = 'rgba(90, 78, 54, 0.12)';
    ctx.fillRect(X(cx - 16.2 + 0.8), Z(cz - 10.6 + 0.9), L(32.4), L(21.2));
    ctx.restore();
    rect(cx - 16.2, cz - 10.6, cx + 16.2, cz + 10.6, '#eef0ea', C.towerLine, 1.6);

    // 塔楼
    rect(cx - 15, cz - 10, cx + 15, cz + 10, C.tower, C.towerLine, 2.4);
    // 南立面玻璃幕墙（沿立面画粗线，平面图更准确）
    ctx.save();
    ctx.strokeStyle = 'rgba(70, 120, 145, 0.85)';
    ctx.lineWidth = 7;
    ctx.beginPath();
    ctx.moveTo(X(cx + 2.4), Z(cz + 9.9));
    ctx.lineTo(X(cx + 15), Z(cz + 9.9));
    ctx.stroke();
    ctx.strokeStyle = 'rgba(47,65,73,0.5)';
    ctx.lineWidth = 1;
    for (var i = 1; i < 6; i++) {
      ctx.beginPath();
      ctx.moveTo(X(cx + 2.4 + i * 2.1), Z(cz + 9.4));
      ctx.lineTo(X(cx + 2.4 + i * 2.1), Z(cz + 10.4));
      ctx.stroke();
    }
    ctx.restore();
    // 电梯井 + 连桥
    ctx.save();
    ctx.setLineDash([5, 4]);
    ctx.strokeStyle = C.accent;
    ctx.lineWidth = 1.4;
    ctx.strokeRect(X(cx - 19.4), Z(cz - 6.9), L(2.4), L(2.8));
    ctx.restore();
    ctx.save();
    ctx.strokeStyle = C.accent;
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(X(cx - 19.4), Z(cz - 5.5));
    ctx.lineTo(X(cx - 26), Z(cz - 5.5));
    ctx.lineTo(X(cx - 29), Z(cz - 9));
    ctx.stroke();
    ctx.restore();
    pxText('入户电梯', X(cx - 29), Z(cz - 9.4), 12, C.accent, '700', 'right');

    // 入口台阶
    rect(cx - 6, cz + 10.6, cx + 6, cz + 13.2, '#ded8c8', '#b8b0a0', 1);
  }

  // 联排住宅（坡屋顶：左右两坡不同明度 + 屋脊）
  function drawTownhouse(o) {
    var w = 9.2, d = 10, rot = (o.rotation && o.rotation[1]) || 0;
    ctx.save();
    ctx.translate(X(o.position[0]), Z(o.position[2]));
    ctx.rotate(-rot);

    ctx.fillStyle = 'rgba(90, 78, 54, 0.10)';
    ctx.fillRect(-L(w) / 2 + 3, -L(d) / 2 + 4, L(w), L(d));
    ctx.fillStyle = '#f6e6d4';
    ctx.fillRect(-L(w) / 2, -L(d) / 2, L(w), L(d));
    ctx.fillStyle = 'rgba(168, 112, 82, 0.18)';
    ctx.fillRect(0, -L(d) / 2, L(w) / 2, L(d));
    ctx.strokeStyle = '#7d5f4b';
    ctx.lineWidth = 1.3;
    ctx.strokeRect(-L(w) / 2, -L(d) / 2, L(w), L(d));
    ctx.strokeStyle = 'rgba(150, 92, 66, 0.8)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(0, -L(d) / 2);
    ctx.lineTo(0, L(d) / 2);
    ctx.stroke();
    ctx.restore();
  }

  function drawBuildings() {
    LAYOUT.objects.filter(function (o) { return o.model === 'Apartment'; }).forEach(drawSlab);
    LAYOUT.objects.filter(function (o) { return o.model === 'Townhouse'; }).forEach(drawTownhouse);
    drawTower();

    var shop = OBJ['shops'];
    if (shop) {
      var sw = shop.options.width, sd = shop.options.depth;
      ctx.save();
      ctx.fillStyle = 'rgba(90, 78, 54, 0.10)';
      ctx.fillRect(X(shop.position[0] - sw / 2 + 0.7), Z(shop.position[2] - sd / 2 + 0.9), L(sw), L(sd));
      ctx.restore();
      rect(shop.position[0] - sw / 2, shop.position[2] - sd / 2, shop.position[0] + sw / 2, shop.position[2] + sd / 2, '#f5e8d5', '#6f5f4f', 1.6);
      ctx.save();
      ctx.fillStyle = 'rgba(196, 86, 47, 0.5)';
      ctx.fillRect(X(shop.position[0] - sw / 2 + 0.8), Z(shop.position[2] + sd / 2 - 1.3), L(sw - 1.6), L(0.9));
      ctx.restore();
    }

    LAYOUT.objects.filter(function (o) { return o.model === 'Pavilion'; }).forEach(function (o) {
      circleW(o.position[0], o.position[2], o.options.radius, '#ecdfc9', '#a08a6c', 1.3);
    });
    var gate = OBJ['gate-south'];
    if (gate) {
      rect(gate.position[0] - 1.2, gate.position[2] - 4.2, gate.position[0] + 1.2, gate.position[2] - 3.4, '#d6cdb9', '#8a8170', 1);
      rect(gate.position[0] - 1.2, gate.position[2] + 3.4, gate.position[0] + 1.2, gate.position[2] + 4.2, '#d6cdb9', '#8a8170', 1);
    }
  }

  /* ---------------- 5. 绿化 / 小品 ---------------- */
  function drawGreen() {
    LAYOUT.objects.filter(function (o) { return o.model === 'Tree'; }).forEach(function (o) {
      var r = 1.55 * (o.scale ? o.scale[0] : 1);
      circleW(o.position[0], o.position[2], r, C.tree, C.treeEdge, 0.9);
      circleW(o.position[0], o.position[2], r * 0.3, 'rgba(122, 156, 92, 0.5)', null);
    });

    LAYOUT.objects.filter(function (o) { return o.model === 'Bench'; }).forEach(function (o) {
      ctx.save();
      ctx.fillStyle = 'rgba(160, 120, 80, 0.8)';
      ctx.fillRect(X(o.position[0] - 1.0), Z(o.position[2] - 0.25), L(2.0), L(0.5));
      ctx.restore();
    });

    LAYOUT.objects.filter(function (o) { return o.model === 'Bollard'; }).forEach(function (o) {
      ctx.beginPath();
      ctx.arc(X(o.position[0]), Z(o.position[2]), 1.8, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(110, 119, 124, 0.8)';
      ctx.fill();
    });
  }

  /* ---------------- 6. 标注 ---------------- */
  function drawNumbers() {
    LAYOUT.objects.forEach(function (o) {
      if (!o.plan || !o.plan.no || o.id === 'mainBuilding') return;
      var cx = X(o.position[0]), cz = Z(o.position[2]);
      var size = o.model === 'Townhouse' ? 9 : 11;
      ctx.font = '600 ' + size + 'px "Microsoft YaHei", sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillStyle = 'rgba(92, 78, 62, 0.78)';
      ctx.fillText(String(o.plan.no), cx, cz);
    });
  }

  function drawLabels() {
    text('D 栋', 65, 40.4, 19, '#1f3b46', '700');
    text('可进入', 65, 43.6, 11, '#1f3b46', '600');

    text('中心湖面', -30, 8, 22, '#2f5f70', '700');
    text('亲水圆台', -6, 5.6, 10, '#4a6a72', '600');
    text('泳池', -46, 54, 10, '#2f5f70', '600');
    text('停车带', 65, 84, 11, '#5d5d54', '600');
    text('邻里商铺', -30, 88, 11, '#8a4a2c', '700');
    text('宅间绿地', 24, 40, 10, '#4f6a3a', '600');
    text('庭院绿地', -14, 58, 9, '#4f6a3a', '600');
    text('斜巷', 40, 24, 9, 'rgba(120, 96, 62, 0.9)', '600');
    text('南入口', 34, 101.5, 10, '#7a5a2e', '600');
    text('城市道路', 100, -78, 10, 'rgba(70,80,84,0.75)', '600');

    ctx.save();
    ctx.strokeStyle = 'rgba(120, 110, 90, 0.6)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(X(-0.8), Z(22));
    ctx.lineTo(X(4), Z(24));
    ctx.stroke();
    ctx.restore();
    text('湖岸步道', 10, 24, 9, 'rgba(90, 82, 68, 0.9)', '600');
  }

  /* ---------------- 7. 图面信息（左栏 / 右下标题栏） ---------------- */
  function drawInfo() {
    // 标题
    pxText('云栖里住区', 70, 106, 44, C.ink, '700');
    pxText('总平面图  ·  SITE PLAN', 70, 142, 15, C.inkSoft, '600');
    ctx.fillStyle = C.accent;
    ctx.fillRect(70, 158, 58, 4);

    // 左栏分隔线
    ctx.save();
    ctx.strokeStyle = 'rgba(60, 70, 74, 0.16)';
    ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(430, 190); ctx.lineTo(430, 1700); ctx.stroke();
    ctx.restore();

    // 主要指标
    pxText('主要指标', 70, 232, 13, 'rgba(90,102,107,0.9)', '700');
    var rows = [
      ['用地面积', '约 3.3 ha'],
      ['住宅', '30 栋（3–14F）'],
      ['可进入建筑', 'D 栋（8F 房间）'],
      ['停车位', '7 位'],
      ['中心湖面', '约 3300 ㎡']
    ];
    rows.forEach(function (r, i) {
      var y = 268 + i * 40;
      pxText(r[0], 70, y, 13, C.inkSoft, '500');
      pxText(r[1], 70, y + 17, 14, C.ink, '600');
    });

    // 图例
    pxText('图例', 70, 520, 13, 'rgba(90,102,107,0.9)', '700');
    var items = [
      { c: C.slab, s: C.slabLine, t: '板楼住宅' },
      { c: C.tower, s: C.towerLine, t: 'D 栋（可进入）' },
      { c: C.water, s: C.waterEdge, t: '水面' },
      { c: C.lawn, s: C.lawnEdge, t: '绿地' },
      { c: C.tree, s: C.treeEdge, t: '乔木' },
      { c: C.pave, s: C.paveLine, t: '硬质铺装' },
      { c: C.walk, s: C.walkEdge, t: '人行道' },
      { c: '#deded6', s: '#bdbdb2', t: '停车' }
    ];
    items.forEach(function (it, i) {
      var y = 556 + i * 38;
      ctx.fillStyle = it.c;
      ctx.strokeStyle = it.s;
      ctx.lineWidth = 1.1;
      ctx.fillRect(70, y - 13, 24, 18);
      ctx.strokeRect(70, y - 13, 24, 18);
      pxText(it.t, 104, y, 13, C.inkSoft, '500');
    });

    // 指北针
    drawNorth(100, 1080);
    // 比例尺
    drawScale(70, 1200);

    // 右下标题栏
    ctx.save();
    ctx.strokeStyle = 'rgba(60, 70, 74, 0.35)';
    ctx.lineWidth = 1;
    ctx.strokeRect(1440, 1800, 700, 138);
    ctx.beginPath();
    ctx.moveTo(1440, 1865); ctx.lineTo(2140, 1865);
    ctx.moveTo(1790, 1800); ctx.lineTo(1790, 1938);
    ctx.stroke();
    ctx.restore();
    pxText('云栖里住区 · 总平面图', 1462, 1834, 16, C.ink, '700');
    pxText('1 : 600（示意）', 1462, 1898, 14, C.inkSoft, '500');
    pxText('既有 D 栋主楼保留', 1810, 1834, 12, C.inkSoft, '500');
    pxText('其余住宅为装饰体量', 1810, 1856, 12, C.inkSoft, '500');
    pxText('2026.11', 1810, 1898, 12, C.inkSoft, '500');

    // 底部说明
    pxText('注：D 栋沿用既有主楼（1F 门厅 / 剪刀楼梯 / 室外玻璃电梯 / 8F 室内）；其余 30 栋住宅与商铺仅作社区背景体量，不设室内空间。',
      70, 1950, 12, 'rgba(90,102,107,0.9)', '500');
  }

  function drawNorth(x, y) {
    ctx.save();
    ctx.translate(x + 22, y);
    ctx.fillStyle = 'rgba(47, 58, 63, 0.05)';
    ctx.beginPath(); ctx.arc(0, 0, 34, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = 'rgba(47, 58, 63, 0.22)';
    ctx.lineWidth = 1;
    ctx.beginPath(); ctx.arc(0, 0, 28, 0, Math.PI * 2); ctx.stroke();

    ctx.fillStyle = C.ink;
    ctx.beginPath();
    ctx.moveTo(0, -22);
    ctx.lineTo(7, 4);
    ctx.lineTo(0, -1);
    ctx.lineTo(-7, 4);
    ctx.closePath();
    ctx.fill();
    ctx.beginPath();
    ctx.moveTo(0, 22);
    ctx.lineTo(5, 8);
    ctx.lineTo(0, 11);
    ctx.lineTo(-5, 8);
    ctx.closePath();
    ctx.fillStyle = 'rgba(47, 58, 63, 0.3)';
    ctx.fill();

    ctx.font = '700 13px "Microsoft YaHei", sans-serif';
    ctx.fillStyle = C.ink;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('N', 0, -38);
    ctx.restore();
  }

  function drawScale(x, y) {
    var seg = L(10);
    ctx.save();
    for (var i = 0; i < 4; i++) {
      ctx.fillStyle = i % 2 === 0 ? 'rgba(47,58,63,0.7)' : '#f8f4e9';
      ctx.fillRect(x + i * seg, y, seg, 7);
      ctx.strokeStyle = 'rgba(47,58,63,0.55)';
      ctx.lineWidth = 1;
      ctx.strokeRect(x + i * seg, y, seg, 7);
    }
    ctx.font = '500 11px "Microsoft YaHei", sans-serif';
    ctx.fillStyle = C.inkSoft;
    ctx.textAlign = 'center';
    ['0', '10', '20', '30', '40 m'].forEach(function (t, i) {
      ctx.fillText(t, x + i * seg, y + 22);
    });
    ctx.restore();
  }

  /* ---------------- 绘制 ---------------- */
  drawSheet();
  drawGround();
  drawWater();
  drawParking();
  drawBuildings();
  drawGreen();
  drawNumbers();
  drawLabels();
  drawInfo();

  window.__READY = true;
})();
