/* ============================================================
 * district-models.js — 街区扩展物件（低多边形 / 纯几何体 / 无外部资源）
 * 依赖：全局 THREE（传统 <script> 标签）
 * 注册：window.GameModels.<Name>(options) -> THREE.Group
 *
 * 约定：1 单位 = 1 米；物件原点在脚下（Y = 0）；Y 轴向上
 *       住宅正面统一朝 +Z（在布局里用 rotation.y 转向）
 * 说明：只生成并返回 Group，位置 / 旋转 / 缩放一律写在 district-layout.js。
 *       与根目录 building.js / environment.js 同一套注册机制，不改动原文件。
 * ============================================================ */
(function (global) {
  'use strict';

  var NS = global.GameModels = global.GameModels || {};

  /* ---------------- 共用工具 ---------------- */
  var UNIT_BOX = null;
  var HELPER = null;
  var MATS = {};

  function unitBox() {
    if (!UNIT_BOX) UNIT_BOX = new THREE.BoxGeometry(1, 1, 1);
    return UNIT_BOX;
  }

  function helper() {
    if (!HELPER) HELPER = new THREE.Object3D();
    return HELPER;
  }

  function solid(color, roughness, metalness) {
    var key = 's' + color + '_' + (roughness === undefined ? 0.92 : roughness) + '_' + (metalness || 0);
    if (MATS[key]) return MATS[key];
    MATS[key] = new THREE.MeshStandardMaterial({
      color: color,
      roughness: roughness === undefined ? 0.92 : roughness,
      metalness: metalness === undefined ? 0.02 : metalness,
      flatShading: true
    });
    return MATS[key];
  }

  function glow(color, emissive, intensity, roughness) {
    var key = 'g' + color + '_' + emissive + '_' + intensity;
    if (MATS[key]) return MATS[key];
    MATS[key] = new THREE.MeshStandardMaterial({
      color: color, roughness: roughness === undefined ? 0.6 : roughness,
      metalness: 0.0, flatShading: true,
      emissive: new THREE.Color(emissive), emissiveIntensity: intensity
    });
    return MATS[key];
  }

  function mesh(w, h, d, mat, x, y, z, name) {
    var m = new THREE.Mesh(unitBox(), mat);
    m.scale.set(w, h, d);
    m.position.set(x || 0, y || 0, z || 0);
    m.castShadow = true;
    m.receiveShadow = true;
    if (name) m.name = name;
    return m;
  }

  function cylinder(rTop, rBottom, h, seg, mat, x, y, z, name) {
    var m = new THREE.Mesh(new THREE.CylinderGeometry(rTop, rBottom, h, seg), mat);
    m.position.set(x || 0, y || 0, z || 0);
    m.castShadow = true;
    m.receiveShadow = true;
    if (name) m.name = name;
    return m;
  }

  function instanced(list, mat, name) {
    if (!list.length) return null;
    var m = new THREE.InstancedMesh(unitBox(), mat, list.length);
    var d = helper();
    for (var i = 0; i < list.length; i++) {
      var t = list[i];
      d.position.set(t.p[0], t.p[1], t.p[2]);
      d.rotation.set(t.r ? t.r[0] : 0, t.r ? t.r[1] : 0, t.r ? t.r[2] : 0);
      d.scale.set(t.s[0], t.s[1], t.s[2]);
      d.updateMatrix();
      m.setMatrixAt(i, d.matrix);
    }
    m.instanceMatrix.needsUpdate = true;
    m.castShadow = true;
    m.receiveShadow = true;
    if (name) m.name = name;
    return m;
  }

  function add(parent, child) {
    if (child) parent.add(child);
    return child;
  }

  function walk(m) {
    if (m) m.userData.walk = true;
    return m;
  }

  // 三角面（山墙）
  function triGeo(ax, ay, bx, by, cx, cy) {
    var g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute([ax, ay, 0, bx, by, 0, cx, cy, 0], 3));
    g.setAttribute('uv', new THREE.Float32BufferAttribute([0, 0, 1, 0, 0.5, 1], 2));
    g.computeVertexNormals();
    return g;
  }

  // 双坡屋面：屋脊沿 Z，坡向 ±X（+Z 面看到山墙）
  function gableRoof(parent, w, d, rise, mat, matEdge, y, over, name) {
    over = over === undefined ? 0.45 : over;
    var halfW = w / 2;
    var ang = Math.atan2(rise, halfW);
    var slopeLen = halfW / Math.cos(ang) + over;
    var g = new THREE.Group();
    g.name = name || 'gable-roof';

    [1, -1].forEach(function (s, i) {
      var slab = mesh(slopeLen, 0.16, d + over * 2, mat, 0, 0, 0, 'roof-slab-' + i);
      var mid = slopeLen / 2 - over / 2;
      slab.position.set(s * mid * Math.cos(ang), rise - mid * Math.sin(ang) + 0.08, 0);
      slab.rotation.z = -s * ang;
      g.add(slab);
    });

    // 屋脊压顶
    g.add(mesh(0.34, 0.18, d + over * 2 + 0.1, matEdge || mat, 0, rise + 0.12, 0, 'roof-ridge'));

    // 两端山墙（组已抬到檐口标高，这里只写局部坐标）
    [1, -1].forEach(function (s, i) {
      var tri = new THREE.Mesh(triGeo(-halfW + 0.02, 0, halfW - 0.02, 0, 0, rise - 0.06), matEdge || mat);
      tri.position.set(0, 0.02, s * (d / 2 - 0.06));
      tri.rotation.y = s > 0 ? 0 : Math.PI;
      tri.castShadow = true;
      tri.receiveShadow = true;
      tri.name = 'gable-end-' + i;
      g.add(tri);
    });

    g.position.y = y;
    add(parent, g);
    return { group: g, rise: rise };
  }

  // 四坡 / 攒尖屋面：底面 w×d，高 rise
  function hipRoof(parent, w, d, rise, mat, y, over, name) {
    over = over === undefined ? 0.5 : over;
    var geo = new THREE.ConeGeometry(0.7071, 1, 4, 1);
    var m = new THREE.Mesh(geo, mat);
    m.rotation.y = Math.PI / 4;
    m.scale.set(w + over * 2, rise, d + over * 2);
    m.position.y = y + rise / 2;
    m.castShadow = true;
    m.receiveShadow = true;
    m.name = name || 'hip-roof';
    add(parent, m);
    return m;
  }

  /* ============================================================
   * 1. 场地：地面 / 铺装 / 草坪 / 沥青场
   * ============================================================ */
  NS.Ground = function (o) {
    var W = o.width || 260;
    var D = o.depth || 220;
    var g = new THREE.Group();
    g.name = 'Ground';
    var matSoil = solid(o.color || 0x93a17f, 0.99);
    var slab = mesh(W, 0.6, D, matSoil, 0, -0.3, 0, 'ground-slab');
    slab.userData.walk = true;
    g.add(slab);
    return g;
  };

  // 铺装（广场 / 步行街 / 小路）
  NS.Plaza = function (o) {
    var W = o.width || 20;
    var D = o.depth || 12;
    var H = o.height === undefined ? 0.06 : o.height;
    var color = o.color || 0xc6bfae;
    var g = new THREE.Group();
    g.name = 'Plaza';

    var matPave = solid(color, 0.95);
    var matJoint = solid(o.joint || 0xb2ab99, 0.97);
    var matEdge = solid(o.edge || 0x9a9587, 0.9);

    g.add(walk(mesh(W, H, D, matPave, 0, H / 2, 0, 'plaza-slab')));

    if (o.border !== false) {
      var t = 0.22;
      g.add(mesh(W, H + 0.03, t, matEdge, 0, (H + 0.03) / 2, D / 2 - t / 2, 'plaza-edge-f'));
      g.add(mesh(W, H + 0.03, t, matEdge, 0, (H + 0.03) / 2, -D / 2 + t / 2, 'plaza-edge-b'));
      g.add(mesh(t, H + 0.03, D, matEdge, W / 2 - t / 2, (H + 0.03) / 2, 0, 'plaza-edge-r'));
      g.add(mesh(t, H + 0.03, D, matEdge, -W / 2 + t / 2, (H + 0.03) / 2, 0, 'plaza-edge-l'));
    }

    if (o.pattern !== 'plain') {
      var step = o.pattern === 'tile' ? 2 : 4;
      var joints = [];
      for (var x = -W / 2 + step; x < W / 2 - 0.2; x += step) {
        joints.push({ p: [x, H + 0.004, 0], s: [0.045, 0.006, D - 0.4] });
      }
      for (var z = -D / 2 + step; z < D / 2 - 0.2; z += step) {
        joints.push({ p: [0, H + 0.004, z], s: [W - 0.4, 0.006, 0.045] });
      }
      add(g, instanced(joints, matJoint, 'plaza-joints'));
    }
    return g;
  };

  NS.Lawn = function (o) {
    var W = o.width || 20;
    var D = o.depth || 16;
    var color = o.color || 0x7a9c5c;
    var g = new THREE.Group();
    g.name = 'Lawn';
    var matGrass = solid(color, 0.99);
    g.add(walk(mesh(W, 0.1, D, matGrass, 0, 0.05, 0, 'lawn-slab')));

    if (o.stripes) {
      var matStripe = solid(o.stripeColor || 0x85a966, 0.99);
      var list = [];
      for (var x = -W / 2 + 1.6; x < W / 2 - 0.4; x += 3.2) {
        list.push({ p: [x, 0.102, 0], s: [1.6, 0.006, D - 0.2] });
      }
      add(g, instanced(list, matStripe, 'mow-stripes'));
    }
    return g;
  };

  NS.AsphaltPad = function (o) {
    var W = o.width || 24;
    var D = o.depth || 16;
    var g = new THREE.Group();
    g.name = 'AsphaltPad';
    var mat = solid(o.color || 0x63665f, 0.98);
    g.add(walk(mesh(W, 0.12, D, mat, 0, 0.06, 0, 'pad-slab')));
    return g;
  };

  NS.ParkingLot = function (o) {
    var W = o.width || 30;
    var D = o.depth || 16;
    var stalls = o.stalls || 8;
    var g = new THREE.Group();
    g.name = 'ParkingLot';

    var matPad = solid(0x5f625c, 0.98);
    var matLine = solid(0xe6e1d1, 0.9);
    var matStop = solid(0xb9b4a4, 0.85);

    g.add(walk(mesh(W, 0.12, D, matPad, 0, 0.06, 0, 'parking-pad')));

    var sw = (W - 1.6) / stalls;
    var lines = [], stops = [];
    for (var i = 0; i <= stalls; i++) {
      lines.push({ p: [-W / 2 + 0.8 + i * sw, 0.125, 0], s: [0.1, 0.01, D * 0.62] });
    }
    for (i = 0; i < stalls; i++) {
      stops.push({ p: [-W / 2 + 0.8 + (i + 0.5) * sw, 0.16, -D * 0.26], s: [sw * 0.5, 0.12, 0.18] });
    }
    add(g, instanced(lines, matLine, 'stall-lines'));
    add(g, instanced(stops, matStop, 'wheel-stops'));
    return g;
  };

  /* ============================================================
   * 2. 联排住宅（社区主力）
   * ============================================================ */
  NS.Townhouse = function (o) {
    var W = o.width || 9;
    var D = o.depth || 10;
    var floors = o.floors || 3;
    var fh = o.floorHeight || 3.0;
    var H = floors * fh;
    var wallC = o.wall === undefined ? 0xe4dccd : o.wall;
    var roofC = o.roofColor === undefined ? 0x8a5642 : o.roofColor;
    var trimC = o.trim === undefined ? 0x5d5145 : o.trim;
    var roofType = o.roof || 'gable';

    var g = new THREE.Group();
    g.name = 'Townhouse';

    var matWall = solid(wallC, 0.94);
    var matBase = solid(o.base || 0x9c9488, 0.96);
    var matTrim = solid(trimC, 0.8, 0.05);
    var matGlass = solid(0x4a6670, 0.16, 0.3);
    var matFrame = solid(0xe9e4d8, 0.7, 0.05);
    var matDoor = solid(o.door || 0x4a5b60, 0.55, 0.1);
    var matRoof = solid(roofC, 0.9);
    var matMetal = solid(0x8d9298, 0.55, 0.4);
    var matStep = solid(0xb3aa9a, 0.95);

    // 基座 + 主体 + 腰线
    g.add(mesh(W + 0.18, 0.42, D + 0.18, matBase, 0, 0.21, 0, 'plinth'));
    g.add(mesh(W, H, D, matWall, 0, 0.4 + H / 2, 0, 'body'));

    var bands = [];
    for (var f = 1; f < floors; f++) {
      bands.push({ p: [0, 0.4 + f * fh, 0], s: [W + 0.08, 0.12, D + 0.08] });
    }
    add(g, instanced(bands, matFrame, 'floor-bands'));

    // 窗（前 / 后 / 两侧）
    var winW = 1.28, winH = 1.5;
    var wins = [], frames = [];
    for (f = 0; f < floors; f++) {
      var wy = 0.4 + f * fh + 1.55;
      var offs = [-W * 0.26, W * 0.26];
      for (var k = 0; k < 2; k++) {
        if (f === 0 && Math.abs(offs[k]) < 1.0) continue;
        wins.push({ p: [offs[k], wy, D / 2 + 0.06], s: [winW, winH, 0.1] });
        frames.push({ p: [offs[k], wy + winH / 2 + 0.09, D / 2 + 0.04], s: [winW + 0.24, 0.12, 0.14] });
        frames.push({ p: [offs[k], wy - winH / 2 - 0.09, D / 2 + 0.04], s: [winW + 0.24, 0.12, 0.14] });
        frames.push({ p: [offs[k] - winW / 2 - 0.06, wy, D / 2 + 0.04], s: [0.12, winH, 0.14] });
        frames.push({ p: [offs[k] + winW / 2 + 0.06, wy, D / 2 + 0.04], s: [0.12, winH, 0.14] });

        wins.push({ p: [offs[k], wy, -D / 2 - 0.06], s: [winW, winH, 0.1] });
      }
      wins.push({ p: [W / 2 + 0.06, wy, 0], s: [0.1, winH, winW] });
      wins.push({ p: [-W / 2 - 0.06, wy, 0], s: [0.1, winH, winW] });
    }
    add(g, instanced(wins, matGlass, 'windows'));
    add(g, instanced(frames, matFrame, 'window-frames'));

    // 入户门 + 门头雨棚 + 踏步
    var doorW = 1.05, doorH = 2.2;
    g.add(mesh(doorW + 0.22, doorH + 0.16, 0.14, matFrame, 0, 0.4 + doorH / 2 + 0.08, D / 2 + 0.1, 'door-frame'));
    g.add(mesh(doorW, doorH, 0.1, matDoor, 0, 0.4 + doorH / 2, D / 2 + 0.15, 'door'));
    g.add(mesh(0.5, 0.06, 0.06, matMetal, 0.26, 0.4 + 1.05, D / 2 + 0.2, 'door-handle'));
    g.add(mesh(2.0, 0.12, 0.9, matRoof, 0, 0.4 + doorH + 0.34, D / 2 + 0.42, 'door-canopy'));
    g.add(mesh(1.9, 0.16, 0.4, matStep, 0, 0.08, D / 2 + 0.55, 'door-step-1'));
    g.add(mesh(1.9, 0.16, 0.3, matStep, 0, 0.24, D / 2 + 0.3, 'door-step-2'));

    // 二层阳台
    if (floors >= 2 && o.balcony !== false) {
      var by = 0.4 + fh;
      g.add(mesh(W * 0.64, 0.14, 1.1, matStep, 0, by, D / 2 + 0.55, 'balcony-slab'));
      g.add(mesh(W * 0.64, 0.09, 0.07, matMetal, 0, by + 0.95, D / 2 + 1.06, 'balcony-rail-top'));
      g.add(mesh(W * 0.64, 0.06, 0.06, matMetal, 0, by + 0.55, D / 2 + 1.06, 'balcony-rail-mid'));
      [-1, 1].forEach(function (s, i) {
        g.add(mesh(0.07, 0.95, 0.07, matMetal, s * W * 0.31, by + 0.48, D / 2 + 1.06, 'balcony-post-' + i));
      });
    }

    // 侧墙空调外机
    var acs = [];
    for (f = 0; f < floors - 1; f++) {
      acs.push({ p: [-W / 2 - 0.24, 0.4 + f * fh + 2.4, D * 0.18], s: [0.42, 0.55, 0.7] });
    }
    add(g, instanced(acs, matFrame, 'ac-units'));

    // 屋顶
    if (roofType === 'flat') {
      g.add(mesh(W + 0.2, 0.24, D + 0.2, matRoof, 0, 0.4 + H + 0.12, 0, 'roof-slab'));
      g.add(mesh(W + 0.2, 0.6, 0.22, matBase, 0, 0.4 + H + 0.42, D / 2, 'parapet-f'));
      g.add(mesh(W + 0.2, 0.6, 0.22, matBase, 0, 0.4 + H + 0.42, -D / 2, 'parapet-b'));
    } else if (roofType === 'hip') {
      hipRoof(g, W, D, W * 0.3, matRoof, 0.4 + H, 0.5, 'hip-roof');
    } else {
      gableRoof(g, W, D, W * 0.31, matRoof, matWall, 0.4 + H, 0.45, 'gable-roof');
      // 阁楼小窗
      g.add(mesh(0.62, 0.62, 0.08, matGlass, 0, 0.4 + H + W * 0.11, D / 2 + 0.06, 'attic-window'));
      if (o.chimney) {
        g.add(mesh(0.6, 1.5, 0.6, matBase, -W * 0.28, 0.4 + H + W * 0.18, -D * 0.2, 'chimney'));
      }
    }

    return g;
  };

  /* ============================================================
   * 3. 邻里商铺（2 层，底层玻璃 + 雨棚 + 招牌）
   * ============================================================ */
  NS.ShopRow = function (o) {
    var W = o.width || 18;
    var D = o.depth || 12;
    var units = o.units || 3;
    var fh = 3.4;
    var H = fh * 2;
    var g = new THREE.Group();
    g.name = 'ShopRow';

    var matWall = solid(o.wall || 0xd9d2c2, 0.94);
    var matBase = solid(0x8f887c, 0.95);
    var matGlass = solid(0x38515a, 0.15, 0.4);
    var matFrame = solid(0x3d474d, 0.55, 0.35);
    var matAwning = solid(o.awning || 0xb65a3c, 0.9);
    var matRoof = solid(0x6d7276, 0.9);
    var matSign = solid(0x2f5d8a, 0.75, 0.05);
    var matText = solid(0xf1eee2, 0.85);
    var matWood = solid(0xb0895c, 0.85);

    g.add(mesh(W + 0.16, 0.3, D + 0.16, matBase, 0, 0.15, 0, 'plinth'));
    g.add(mesh(W, H, D, matWall, 0, 0.3 + H / 2, 0, 'body'));
    g.add(mesh(W + 0.5, 0.34, D + 0.5, matRoof, 0, 0.3 + H + 0.17, 0, 'roof-cap'));
    g.add(mesh(W + 0.5, 0.55, 0.3, matBase, 0, 0.3 + H + 0.55, D / 2 + 0.1, 'parapet-f'));

    var uw = W / units;
    var wins = [], awnings = [], signs = [], texts = [], mullions = [];
    for (var i = 0; i < units; i++) {
      var cx = -W / 2 + uw * (i + 0.5);
      // 底层橱窗
      wins.push({ p: [cx, 0.3 + 1.35, D / 2 + 0.05], s: [uw - 0.7, 2.1, 0.1] });
      // 门
      g.add(mesh(0.95, 2.1, 0.1, matFrame, cx + uw * 0.28, 0.3 + 1.05, D / 2 + 0.12, 'shop-door-' + i));
      // 雨棚
      awnings.push({ p: [cx, 0.3 + 2.78, D / 2 + 0.55], s: [uw - 0.45, 0.1, 1.1], r: [-0.12, 0, 0] });
      // 招牌
      signs.push({ p: [cx, 0.3 + 3.42, D / 2 + 0.14], s: [uw - 0.5, 0.62, 0.1] });
      texts.push({ p: [cx - 0.25, 0.3 + 3.42, D / 2 + 0.21], s: [uw * 0.4, 0.1, 0.03] });
      // 二层窗
      wins.push({ p: [cx, 0.3 + 5.15, D / 2 + 0.05], s: [uw - 1.1, 1.4, 0.1] });
      mullions.push({ p: [cx, 0.3 + 1.35, D / 2 + 0.12], s: [0.07, 2.1, 0.1] });
    }
    add(g, instanced(wins, matGlass, 'shop-glass'));
    add(g, instanced(awnings, matAwning, 'awnings'));
    add(g, instanced(signs, matSign, 'signs'));
    add(g, instanced(texts, matText, 'sign-text'));
    add(g, instanced(mullions, matFrame, 'mullions'));

    // 背面窗带（沿主路一侧，避免整面实墙）
    var backWins = [];
    for (var b = 0; b < units * 2; b++) {
      backWins.push({ p: [-W / 2 + (W / (units * 2)) * (b + 0.5), 0.3 + 5.2, -D / 2 - 0.05], s: [1.5, 1.5, 0.1] });
      backWins.push({ p: [-W / 2 + (W / (units * 2)) * (b + 0.5), 0.3 + 1.6, -D / 2 - 0.05], s: [1.2, 1.3, 0.1] });
    }
    add(g, instanced(backWins, matGlass, 'shop-back-windows'));

    // 室外小桌（社区商业的烟火气）
    for (i = 0; i < 2; i++) {
      var tx = -W / 2 + 3.0 + i * 6.2;
      g.add(cylinder(0.42, 0.38, 0.06, 8, matWood, tx, 0.78, D / 2 + 1.45, 'cafe-top-' + i));
      g.add(cylinder(0.05, 0.05, 0.76, 6, matFrame, tx, 0.38, D / 2 + 1.45, 'cafe-leg-' + i));
      [-1, 1].forEach(function (s, j) {
        g.add(mesh(0.36, 0.05, 0.36, matWood, tx + s * 0.68, 0.46, D / 2 + 1.45, 'stool-' + i + '-' + j));
        g.add(mesh(0.05, 0.44, 0.05, matFrame, tx + s * 0.68, 0.23, D / 2 + 1.45, 'stool-leg-' + i + '-' + j));
      });
    }
    return g;
  };

  /* ============================================================
   * 4. 社区中心（2 层，玻璃门厅 + 雨棚 + 标志墙）
   * ============================================================ */
  NS.CommunityHall = function (o) {
    var W = o.width || 24;
    var D = o.depth || 16;
    var H = 9.2;
    var g = new THREE.Group();
    g.name = 'CommunityHall';

    var matWall = solid(o.wall || 0xe0d9c9, 0.93);
    var matBase = solid(0x7d7a70, 0.95);
    var matGlass = solid(0x3f5f68, 0.12, 0.4);
    var matFrame = solid(0x3a444a, 0.5, 0.4);
    var matRoof = solid(0x777c7d, 0.9);
    var matAccent = solid(0xc4562f, 0.8);
    var matWood = solid(0xb08a5e, 0.85);
    var matLamp = glow(0xfff2d8, 0xffe6bb, 0.55, 0.6);

    g.add(mesh(W + 0.3, 0.4, D + 0.3, matBase, 0, 0.2, 0, 'plinth'));
    g.add(mesh(W, H, D, matWall, 0, 0.4 + H / 2, 0, 'body'));

    // 正立面整片玻璃 + 竖向框
    g.add(mesh(W * 0.62, 4.6, 0.16, matGlass, -W * 0.06, 0.4 + 2.5, D / 2 + 0.06, 'hall-glass'));
    var mulls = [];
    for (var i = -3; i <= 3; i++) {
      mulls.push({ p: [-W * 0.06 + i * (W * 0.62 / 7), 0.4 + 2.5, D / 2 + 0.14], s: [0.09, 4.6, 0.12] });
    }
    add(g, instanced(mulls, matFrame, 'hall-mullions'));

    // 入口雨棚（挑出 3m，带斜拉杆）
    g.add(mesh(W * 0.4, 0.22, 3.2, matFrame, 0, 0.4 + 4.9, D / 2 + 1.5, 'canopy'));
    g.add(mesh(W * 0.4, 0.1, 0.16, matAccent, 0, 0.4 + 4.9, D / 2 + 3.05, 'canopy-edge'));
    [-1, 1].forEach(function (s, i) {
      g.add(cylinder(0.09, 0.09, 3.0, 6, matFrame, s * W * 0.17, 0.4 + 3.4, D / 2 + 2.85, 'canopy-rod-' + i));
    });

    // 二层窗带
    g.add(mesh(W * 0.78, 1.9, 0.12, matGlass, 0, 0.4 + 7.0, D / 2 + 0.05, 'hall-band'));
    g.add(mesh(W * 0.82, 0.14, 0.2, matFrame, 0, 0.4 + 5.95, D / 2 + 0.06, 'hall-band-sill'));

    // 标志墙（左侧，竖向橙红板 + 白字条）
    g.add(mesh(2.6, 6.2, 0.7, matAccent, -W / 2 + 1.5, 0.4 + 3.1, D / 2 + 0.2, 'sign-wall'));
    [0, 1, 2].forEach(function (k) {
      g.add(mesh(1.5 - k * 0.25, 0.16, 0.06, matLamp, -W / 2 + 1.5, 0.4 + 4.5 - k * 0.7, D / 2 + 0.58, 'sign-line-' + k));
    });

    // 屋顶
    g.add(mesh(W + 0.5, 0.36, D + 0.5, matRoof, 0, 0.4 + H + 0.18, 0, 'roof-slab'));
    g.add(mesh(W + 0.5, 0.7, 0.26, matBase, 0, 0.4 + H + 0.7, D / 2, 'parapet-f'));

    // 侧面竖向木格栅
    var slats = [];
    for (i = 0; i < 10; i++) {
      slats.push({ p: [W / 2 + 0.1, 0.4 + 3.2, -D / 2 + 1.2 + i * 1.5], s: [0.16, 5.6, 0.42] });
    }
    add(g, instanced(slats, matWood, 'side-slat'));

    // 门前台阶与旗杆
    g.add(mesh(W * 0.42, 0.18, 1.2, matBase, 0, 0.09, D / 2 + 1.9, 'entry-step'));
    g.add(cylinder(0.06, 0.08, 8.5, 8, matFrame, W / 2 - 3.2, 4.25, D / 2 + 3.2, 'flag-pole'));
    g.add(mesh(1.6, 0.9, 0.04, matAccent, W / 2 - 2.4, 7.9, D / 2 + 3.2, 'flag'));
    return g;
  };

  /* ============================================================
   * 5. 背景公寓（6~8 层板楼，带阳台）
   * ============================================================ */
  NS.Apartment = function (o) {
    var W = o.width || 26;
    var D = o.depth || 16;
    var floors = o.floors || 6;
    var fh = 3.0;
    var H = floors * fh;
    var g = new THREE.Group();
    g.name = 'Apartment';

    var matWall = solid(o.wall || 0xd6cfc0, 0.94);
    var matBase = solid(0x8d877b, 0.95);
    var matGlass = solid(0x3c5158, 0.2, 0.35);
    var matFrame = solid(0xe4dfd3, 0.75, 0.05);
    var matRail = solid(0x7f8890, 0.55, 0.4);
    var matRoof = solid(0x7b7f80, 0.9);

    g.add(mesh(W + 0.4, 0.5, D + 0.4, matBase, 0, 0.25, 0, 'plinth'));
    g.add(mesh(W, H, D, matWall, 0, 0.5 + H / 2, 0, 'body'));
    g.add(mesh(W + 0.8, 0.4, D + 0.8, matRoof, 0, 0.5 + H + 0.2, 0, 'roof-slab'));

    // 屋面楼梯间 + 设备箱，避免俯视一片平灰
    var roofTop = 0.5 + H + 0.4;
    g.add(mesh(W * 0.2, 2.2, D * 0.4, matWall, -W * 0.24, roofTop + 1.1, -D * 0.08, 'roof-stair'));
    g.add(mesh(W * 0.2 + 0.3, 0.22, D * 0.4 + 0.3, matRoof, -W * 0.24, roofTop + 2.3, -D * 0.08, 'roof-stair-cap'));
    g.add(mesh(W * 0.09, 1.0, D * 0.2, matRail, W * 0.22, roofTop + 0.5, D * 0.15, 'roof-ac-1'));
    g.add(mesh(W * 0.07, 0.8, D * 0.16, matRail, W * 0.32, roofTop + 0.4, -D * 0.18, 'roof-ac-2'));

    var wins = [], frames = [], balconies = [], rails = [];
    var nWin = Math.max(3, Math.round(W / 3.6));
    for (var f = 0; f < floors; f++) {
      var wy = 0.5 + f * fh + 1.55;
      for (var i = 0; i < nWin; i++) {
        var wx = -W / 2 + (W / nWin) * (i + 0.5);
        wins.push({ p: [wx, wy, D / 2 + 0.06], s: [1.5, 1.5, 0.1] });
        wins.push({ p: [wx, wy, -D / 2 - 0.06], s: [1.5, 1.5, 0.1] });
      }
      // 山墙端窗，避免整面实墙
      [-0.24, 0.24].forEach(function (k) {
        wins.push({ p: [W / 2 + 0.06, wy, D * k], s: [0.1, 1.5, 1.5] });
        wins.push({ p: [-W / 2 - 0.06, wy, D * k], s: [0.1, 1.5, 1.5] });
      });
      // 每隔一层做通长阳台
      if (f % 2 === 1) {
        balconies.push({ p: [0, 0.5 + f * fh + 0.1, D / 2 + 0.7], s: [W * 0.86, 0.16, 1.5] });
        rails.push({ p: [0, 0.5 + f * fh + 1.0, D / 2 + 1.4], s: [W * 0.86, 0.09, 0.08] });
        rails.push({ p: [0, 0.5 + f * fh + 0.55, D / 2 + 1.4], s: [W * 0.86, 0.06, 0.06] });
      }
    }
    add(g, instanced(wins, matGlass, 'apt-windows'));
    add(g, instanced(balconies, matFrame, 'apt-balconies'));
    add(g, instanced(rails, matRail, 'apt-rails'));

    // 门头
    g.add(mesh(5.0, 3.2, 0.24, matFrame, 0, 0.5 + 1.6, D / 2 + 0.1, 'entry-portal'));
    g.add(mesh(4.2, 2.5, 0.12, matGlass, 0, 0.5 + 1.35, D / 2 + 0.24, 'entry-glass'));
    g.add(mesh(6.0, 0.24, 2.2, matRoof, 0, 0.5 + 3.4, D / 2 + 1.0, 'entry-canopy'));
    [-2.4, 2.4].forEach(function (x, i) {
      g.add(cylinder(0.12, 0.12, 3.3, 8, matRail, x, 1.65, D / 2 + 1.9, 'entry-column-' + i));
    });
    return g;
  };

  /* ============================================================
   * 6. 凉亭 / 廊架 / 花坛
   * ============================================================ */
  NS.Pavilion = function (o) {
    var R = o.radius || 3.2;
    var sides = o.sides || 6;
    var H = o.height || 3.1;
    var g = new THREE.Group();
    g.name = 'Pavilion';

    var matWood = solid(o.wood || 0x9a6a45, 0.85);
    var matRoof = solid(o.roofColor || 0x7c4a38, 0.9);
    var matStone = solid(0xa9a498, 0.95);
    var matLamp = glow(0xffe9c2, 0xffdca8, 0.5, 0.6);

    // 台基 + 柱 + 坐凳
    g.add(mesh(R * 2 + 0.8, 0.22, R * 2 + 0.8, matStone, 0, 0.11, 0, 'pavilion-base'));
    var posts = [];
    for (var i = 0; i < sides; i++) {
      var a = (i / sides) * Math.PI * 2 + Math.PI / sides;
      posts.push({ x: Math.cos(a) * (R - 0.15), z: Math.sin(a) * (R - 0.15) });
    }
    posts.forEach(function (p, i) {
      g.add(cylinder(0.13, 0.15, H, 8, matWood, p.x, H / 2 + 0.22, p.z, 'pavilion-post-' + i));
      g.add(mesh(0.5, 0.55, 1.5, matWood, p.x * 0.72, 0.62, p.z * 0.72, 'pavilion-bench-' + i));
    });

    // 六角攒尖顶
    var roof = new THREE.Mesh(new THREE.ConeGeometry(R + 0.55, 1.7, sides, 1), matRoof);
    roof.position.y = H + 0.92;
    roof.rotation.y = Math.PI / sides;
    roof.castShadow = true;
    roof.receiveShadow = true;
    roof.name = 'pavilion-roof';
    g.add(roof);

    // 顶尖 + 挂灯
    g.add(cylinder(0.05, 0.08, 0.8, 6, matStone, 0, H + 2.0, 0, 'pavilion-finial'));
    g.add(cylinder(0.16, 0.2, 0.26, 8, matLamp, 0, H + 0.35, 0, 'pavilion-lamp'));
    return g;
  };

  NS.Pergola = function (o) {
    var W = o.width || 8;
    var D = o.depth || 4;
    var H = 2.7;
    var g = new THREE.Group();
    g.name = 'Pergola';

    var matWood = solid(0x8d6647, 0.88);
    var matBeam = solid(0x74533a, 0.9);
    var matLeaf = solid(0x5f8f4e, 0.92);

    [[-1, -1], [1, -1], [-1, 1], [1, 1]].forEach(function (s, i) {
      g.add(mesh(0.2, H, 0.2, matWood, s[0] * (W / 2 - 0.2), H / 2, s[1] * (D / 2 - 0.2), 'pergola-post-' + i));
    });
    g.add(mesh(W, 0.18, 0.2, matBeam, 0, H, -D / 2 + 0.2, 'pergola-beam-a'));
    g.add(mesh(W, 0.18, 0.2, matBeam, 0, H, D / 2 - 0.2, 'pergola-beam-b'));

    var slats = [];
    for (var x = -W / 2 + 0.4; x < W / 2; x += 0.62) {
      slats.push({ p: [x, H + 0.22, 0], s: [0.1, 0.14, D + 0.5] });
    }
    add(g, instanced(slats, matWood, 'pergola-slats'));

    // 爬藤
    [[-1, 0.1], [0.6, -0.6]].forEach(function (p, i) {
      for (var k = 0; k < 5; k++) {
        var leaf = new THREE.Mesh(new THREE.IcosahedronGeometry(0.34 + (k % 2) * 0.12, 0), matLeaf);
        leaf.position.set(p[0] * (W / 2 - 0.2) + (k - 2) * 0.55, H + 0.12, p[1] * (D / 2 - 0.2) + (k % 2) * 0.3);
        leaf.castShadow = true;
        g.add(leaf);
      }
    });
    return g;
  };

  NS.FlowerBed = function (o) {
    var W = o.width || 5;
    var D = o.depth || 3;
    var g = new THREE.Group();
    g.name = 'FlowerBed';

    var matStone = solid(0xb0aa9c, 0.95);
    var matSoil = solid(0x5b4a3a, 0.98);
    var matLeaf = solid(0x5f8f4e, 0.92);
    var flowers = [0xd05a4a, 0xe0b040, 0xd97b9a, 0xe8e2d4];

    g.add(mesh(W, 0.42, D, matStone, 0, 0.21, 0, 'bed-wall'));
    g.add(mesh(W - 0.3, 0.1, D - 0.3, matSoil, 0, 0.45, 0, 'bed-soil'));

    var leafy = [];
    for (var x = -W / 2 + 0.5; x < W / 2 - 0.2; x += 0.9) {
      for (var z = -D / 2 + 0.5; z < D / 2 - 0.2; z += 0.9) {
        leafy.push({ p: [x, 0.55, z], s: [0.55, 0.3, 0.55] });
      }
    }
    add(g, instanced(leafy, matLeaf, 'bed-leaf'));
    for (var i = 0; i < 4; i++) {
      var fm = solid(flowers[i], 0.85);
      var list = [];
      for (x = -W / 2 + 0.6 + i * 0.7; x < W / 2 - 0.4; x += 2.6) {
        for (z = -D / 2 + 0.6 + i * 0.4; z < D / 2 - 0.4; z += 1.8) {
          list.push({ p: [x, 0.74, z], s: [0.22, 0.2, 0.22] });
        }
      }
      add(g, instanced(list, fm, 'flowers-' + i));
    }
    return g;
  };

  /* ============================================================
   * 7. 游乐场 / 篮球场 / 水景
   * ============================================================ */
  NS.Playground = function (o) {
    var W = o.width || 22;
    var D = o.depth || 16;
    var g = new THREE.Group();
    g.name = 'Playground';

    var matRubber = solid(o.surface || 0xc98a5e, 0.97);
    var matSand = solid(0xd8c69a, 0.99);
    var matWood = solid(0x9a6a45, 0.86);
    var matRed = solid(0xc4562f, 0.8);
    var matBlue = solid(0x3f7d9c, 0.8);
    var matYellow = solid(0xe0b040, 0.8);
    var matMetal = solid(0x8b9299, 0.5, 0.4);

    g.add(walk(mesh(W, 0.12, D, matRubber, 0, 0.06, 0, 'play-surface')));

    // 沙坑
    g.add(walk(mesh(8, 0.08, 6, matSand, -W * 0.22, 0.16, -D * 0.1, 'sand-pit')));

    // 滑梯：平台 + 梯 + 滑道
    var sx = -W * 0.22, sz = -D * 0.1;
    g.add(mesh(1.6, 0.2, 1.6, matWood, sx, 2.0, sz, 'slide-deck'));
    [[-0.7, -0.7], [0.7, -0.7], [-0.7, 0.7], [0.7, 0.7]].forEach(function (p, i) {
      g.add(mesh(0.12, 2.0, 0.12, matWood, sx + p[0], 1.0, sz + p[1], 'slide-post-' + i));
    });
    g.add(mesh(1.5, 0.9, 0.1, matBlue, sx, 2.55, sz - 0.72, 'slide-rail'));
    g.add(mesh(1.8, 0.16, 0.16, matWood, sx, 2.4, sz - 0.72, 'slide-topbar'));

    // 滑道（斜面）
    var chute = mesh(0.9, 0.12, 4.2, matYellow, sx + 1.25, 1.1, sz + 1.55, 'slide-chute');
    chute.rotation.x = -0.47;
    g.add(chute);
    [-0.42, 0.42].forEach(function (x, i) {
      var rail = mesh(0.07, 0.34, 4.2, matRed, sx + 1.25 + x, 1.22, sz + 1.55, 'slide-side-' + i);
      rail.rotation.x = -0.47;
      g.add(rail);
    });

    // 爬梯
    for (var s = 0; s < 5; s++) {
      g.add(mesh(0.9, 0.06, 0.06, matMetal, sx - 1.2, 0.45 + s * 0.4, sz, 'slide-rung-' + s));
    }
    g.add(mesh(0.07, 2.1, 0.07, matMetal, sx - 1.2, 1.05, sz - 0.45, 'slide-ladder-a'));
    g.add(mesh(0.07, 2.1, 0.07, matMetal, sx - 1.2, 1.05, sz + 0.45, 'slide-ladder-b'));

    // 秋千
    var wx = W * 0.2, wz = -D * 0.22;
    [-1, 1].forEach(function (side, i) {
      g.add(mesh(0.1, 2.6, 0.1, matMetal, wx + side * 1.5, 1.3, wz, 'swing-leg-a-' + i));
      g.add(mesh(0.1, 2.6, 0.1, matMetal, wx + side * 1.5, 1.3, wz + 0.5, 'swing-leg-b-' + i));
    });
    g.add(mesh(3.2, 0.12, 0.12, matMetal, wx, 2.55, wz, 'swing-top'));
    [-0.65, 0.65].forEach(function (x, i) {
      g.add(mesh(0.05, 1.7, 0.05, matMetal, wx + x - 0.22, 1.7, wz, 'swing-chain-a-' + i));
      g.add(mesh(0.05, 1.7, 0.05, matMetal, wx + x + 0.22, 1.7, wz, 'swing-chain-b-' + i));
      g.add(mesh(0.5, 0.08, 0.24, i ? matRed : matBlue, wx + x, 0.82, wz, 'swing-seat-' + i));
    });

    // 弹簧摇马
    [[W * 0.3, D * 0.24, matRed], [W * 0.36, D * 0.1, matBlue]].forEach(function (p, i) {
      g.add(cylinder(0.06, 0.08, 0.5, 6, matMetal, p[0], 0.28, p[1], 'spring-' + i));
      g.add(mesh(1.0, 0.22, 0.34, p[2], p[0], 0.62, p[1], 'ride-' + i));
      g.add(mesh(0.34, 0.26, 0.3, p[2], p[0] + 0.36, 0.78, p[1], 'ride-head-' + i));
    });

    // 看护长椅
    g.add(mesh(1.8, 0.1, 0.5, matWood, -W * 0.42, 0.55, D * 0.28, 'pg-bench'));
    g.add(mesh(1.8, 0.5, 0.08, matWood, -W * 0.42, 0.8, D * 0.05, 'pg-bench-back'));
    return g;
  };

  NS.BasketballCourt = function (o) {
    var W = o.width || 28;
    var D = o.depth || 15;
    var g = new THREE.Group();
    g.name = 'BasketballCourt';

    var matCourt = solid(o.surface || 0x4f7d6a, 0.97);
    var matLine = solid(0xeae5d6, 0.92);
    var matPole = solid(0x5d666c, 0.55, 0.4);
    var matBoard = solid(0xece7d8, 0.7);
    var matRim = solid(0xc4562f, 0.7, 0.2);

    g.add(walk(mesh(W, 0.12, D, matCourt, 0, 0.06, 0, 'court')));
    // 边线 / 中线 / 罚球圈
    var lines = [];
    lines.push({ p: [0, 0.13, D / 2 - 0.4], s: [W, 0.01, 0.1] });
    lines.push({ p: [0, 0.13, -D / 2 + 0.4], s: [W, 0.01, 0.1] });
    lines.push({ p: [W / 2 - 0.4, 0.13, 0], s: [0.1, 0.01, D] });
    lines.push({ p: [-W / 2 + 0.4, 0.13, 0], s: [0.1, 0.01, D] });
    lines.push({ p: [0, 0.13, 0], s: [0.1, 0.01, D] });
    add(g, instanced(lines, matLine, 'court-lines'));

    var ring = new THREE.Mesh(new THREE.RingGeometry(1.7, 1.82, 28), matLine);
    ring.rotation.x = -Math.PI / 2;
    ring.position.y = 0.135;
    g.add(ring);

    // 两个篮架
    [-1, 1].forEach(function (s, i) {
      var bx = s * (W / 2 - 1.0);
      g.add(cylinder(0.16, 0.2, 3.4, 8, matPole, bx, 1.7, 0, 'hoop-pole-' + i));
      g.add(mesh(0.12, 0.12, 1.5, matPole, bx, 3.3, -s * 0.7, 'hoop-arm-' + i));
      g.add(mesh(0.1, 1.0, 1.8, matBoard, bx, 3.55, -s * 1.35, 'backboard-' + i));
      var rim = new THREE.Mesh(new THREE.TorusGeometry(0.24, 0.035, 6, 14), matRim);
      rim.rotation.x = Math.PI / 2;
      rim.position.set(bx, 3.05, -s * 1.6);
      rim.castShadow = true;
      g.add(rim);
    });
    return g;
  };

  NS.Pond = function (o) {
    var R = o.radius || 7;
    var g = new THREE.Group();
    g.name = 'Pond';

    var matWater = new THREE.MeshStandardMaterial({
      color: o.color || 0x5f8fa6, roughness: 0.08, metalness: 0.25,
      transparent: true, opacity: 0.86, flatShading: false
    });
    var matRim = solid(0xa8a396, 0.95);
    var matReed = solid(0x6d8a4f, 0.92);

    var water = new THREE.Mesh(new THREE.CircleGeometry(R, 30), matWater);
    water.rotation.x = -Math.PI / 2;
    water.position.y = 0.16;
    water.receiveShadow = true;
    water.name = 'water';
    g.add(water);

    // 石砌驳岸（一圈矮石块）
    var stones = [];
    var n = Math.max(10, Math.round(R * 3.2));
    for (var i = 0; i < n; i++) {
      var a = (i / n) * Math.PI * 2;
      stones.push({
        p: [Math.cos(a) * (R + 0.28), 0.1, Math.sin(a) * (R + 0.28)],
        s: [0.9, 0.26, 0.55], r: [0, -a, 0]
      });
    }
    add(g, instanced(stones, matRim, 'pond-rim'));

    // 芦苇
    var reeds = [];
    for (i = 0; i < 26; i++) {
      var ang = (i / 26) * Math.PI * 2;
      reeds.push({
        p: [Math.cos(ang) * (R - 0.5), 0.45, Math.sin(ang) * (R - 0.5)],
        s: [0.09, 0.9, 0.09]
      });
    }
    add(g, instanced(reeds, matReed, 'reeds'));
    return g;
  };

  /* ============================================================
   * 8. 边界：绿篱 / 栅栏 / 大门
   * ============================================================ */
  NS.Hedge = function (o) {
    var L = o.length || 6;
    var H = o.height || 1.0;
    var T = o.thickness || 0.9;
    var g = new THREE.Group();
    g.name = 'Hedge';

    var matBody = solid(o.color || 0x4f7a3f, 0.95);
    var matTop = solid(o.topColor || 0x638f4c, 0.93);
    g.add(mesh(L, H, T, matBody, 0, H / 2, 0, 'hedge-body'));

    var lumps = [];
    for (var x = -L / 2 + 0.4; x < L / 2 - 0.2; x += 0.7) {
      lumps.push({ p: [x, H + 0.04, 0], s: [0.78, 0.24, T * 0.92] });
    }
    add(g, instanced(lumps, matTop, 'hedge-top'));
    return g;
  };

  NS.Fence = function (o) {
    var L = o.length || 6;
    var H = o.height || 0.95;
    var g = new THREE.Group();
    g.name = 'Fence';

    var matWood = solid(o.color || 0xdad3c2, 0.9);
    var matRail = solid(o.rail || 0xc0b8a6, 0.9);

    g.add(mesh(L, 0.08, 0.08, matRail, 0, H - 0.1, 0, 'fence-rail-top'));
    g.add(mesh(L, 0.07, 0.07, matRail, 0, H * 0.45, 0, 'fence-rail-mid'));

    var pickets = [];
    for (var x = -L / 2 + 0.12; x < L / 2; x += 0.34) {
      pickets.push({ p: [x, H / 2, 0], s: [0.08, H, 0.06] });
    }
    add(g, instanced(pickets, matWood, 'pickets'));

    [-1, 1].forEach(function (s, i) {
      g.add(mesh(0.13, H + 0.24, 0.13, matRail, s * (L / 2 - 0.06), (H + 0.24) / 2, 0, 'fence-post-' + i));
    });
    return g;
  };

  NS.CommunityGate = function (o) {
    var W = o.width || 9;
    var H = o.height || 5.2;
    var g = new THREE.Group();
    g.name = 'CommunityGate';

    var matStone = solid(0xa9a293, 0.95);
    var matWood = solid(0x7c4a38, 0.88);
    var matGold = solid(0xc9a54e, 0.6, 0.3);
    var matBoard = solid(0x3f4a44, 0.8);

    [-1, 1].forEach(function (s, i) {
      g.add(mesh(0.85, H, 0.85, matStone, s * (W / 2 - 0.4), H / 2, 0, 'gate-pillar-' + i));
      g.add(mesh(1.1, 0.24, 1.1, matStone, s * (W / 2 - 0.4), H + 0.12, 0, 'gate-cap-' + i));
      g.add(mesh(0.5, 0.5, 0.5, matGold, s * (W / 2 - 0.4), H + 0.5, 0, 'gate-finial-' + i));
    });
    g.add(mesh(W, 0.55, 0.65, matWood, 0, H - 0.9, 0, 'gate-beam'));
    g.add(mesh(W - 1.4, 1.5, 0.35, matBoard, 0, H - 0.15, 0, 'gate-board'));
    // 匾额上的抽象字条
    [0, 1, 2].forEach(function (k) {
      g.add(mesh(1.0 - k * 0.12, 0.14, 0.06, matGold, 0, H + 0.2 - k * 0.34, 0.21, 'gate-text-' + k));
    });
    // 檐口小坡顶
    g.add(mesh(W + 0.7, 0.18, 1.1, matStone, 0, H + 0.5, 0, 'gate-eave'));
    return g;
  };

  /* ============================================================
   * 8.5 有机湖面 / 圆形亲水平台 / 停车棚（参考图里的中央水景）
   * ============================================================ */

  // 自由曲线湖面：o.points 为 [x, z] 控制点，splineThru 平滑成闭合水面
  NS.Lagoon = function (o) {
    var pts = o.points || [
      [-59, 4], [-54, -9], [-42, -21], [-25, -29], [-5, -30], [11, -23],
      [16, -11], [6, -1], [17, 8], [14, 21], [-2, 29], [-22, 31], [-42, 25], [-56, 15]
    ];
    var islands = o.islands || [
      { x: -18, z: 2, r: 6 }, { x: -2, z: 14, r: 4.5 }, { x: -27, z: -9, r: 3.6 }
    ];

    var g = new THREE.Group();
    g.name = 'Lagoon';

    var matSand = solid(o.sand || 0xd9c79c, 0.97);
    var matWater = new THREE.MeshStandardMaterial({
      color: o.color || 0x4f93a8, roughness: 0.05, metalness: 0.3,
      transparent: true, opacity: 0.9
    });
    var matStone = solid(0xb9b3a5, 0.92);
    var matLawn = solid(0x7fa35f, 0.96);
    var matBank = solid(0xcbb98e, 0.97);

    function shapeAt(k) {
      var s = new THREE.Shape();
      var v = new THREE.Vector2(pts[0][0] * k, -pts[0][1] * k);
      s.moveTo(v.x, v.y);
      var list = [];
      for (var i = 1; i < pts.length; i++) {
        list.push(new THREE.Vector2(pts[i][0] * k, -pts[i][1] * k));
      }
      list.push(new THREE.Vector2(pts[0][0] * k, -pts[0][1] * k));
      s.splineThru(list);
      return s;
    }

    // 沙岸
    var sand = new THREE.Mesh(new THREE.ShapeGeometry(shapeAt(1.07), 10), matSand);
    sand.rotation.x = -Math.PI / 2;
    sand.position.y = 0.09;
    sand.receiveShadow = true;
    sand.name = 'lagoon-sand';
    g.add(sand);

    // 水面
    var water = new THREE.Mesh(new THREE.ShapeGeometry(shapeAt(1.0), 10), matWater);
    water.rotation.x = -Math.PI / 2;
    water.position.y = 0.16;
    water.name = 'lagoon-water';
    g.add(water);

    // 湖心岛
    islands.forEach(function (it, i) {
      var bank = new THREE.Mesh(new THREE.CircleGeometry(it.r + 0.9, 20), matBank);
      bank.rotation.x = -Math.PI / 2;
      bank.position.set(it.x, 0.2, it.z);
      bank.name = 'island-bank-' + i;
      g.add(bank);

      var isle = new THREE.Mesh(new THREE.CircleGeometry(it.r, 20), matLawn);
      isle.rotation.x = -Math.PI / 2;
      isle.position.set(it.x, 0.24, it.z);
      isle.receiveShadow = true;
      isle.name = 'island-' + i;
      g.add(isle);
    });

    // 临水石阶（东岸一小段）
    if (o.steps !== false) {
      var stepList = [];
      for (var s2 = 0; s2 < 5; s2++) {
        stepList.push({ p: [16.5 + s2 * 0.6, 0.1 + s2 * 0.02, 12], s: [0.6, 0.16, 7] });
      }
      add(g, instanced(stepList, matStone, 'lagoon-steps'));
    }

    return g;
  };

  NS.RoundDeck = function (o) {
    var R = o.radius || 6.5;
    var g = new THREE.Group();
    g.name = 'RoundDeck';

    var matStone = solid(o.color || 0xcfc7b6, 0.93);
    var matEdge = solid(0xa9a293, 0.92);
    var matWater = new THREE.MeshStandardMaterial({
      color: 0x6fa9bc, roughness: 0.05, metalness: 0.3, transparent: true, opacity: 0.88
    });

    g.add(cylinder(R, R, 0.18, 32, matStone, 0, 0.09, 0, 'deck'));
    g.add(cylinder(R + 0.25, R + 0.25, 0.1, 32, matEdge, 0, 0.2, 0, 'deck-edge'));

    if (o.pool !== false) {
      g.add(cylinder(R * 0.42, R * 0.42, 0.1, 28, matEdge, 0, 0.24, 0, 'deck-pool-rim'));
      var w = new THREE.Mesh(new THREE.CircleGeometry(R * 0.38, 28), matWater);
      w.rotation.x = -Math.PI / 2;
      w.position.y = 0.3;
      w.name = 'deck-pool';
      g.add(w);
    }

    // 台阶
    g.add(mesh(3.2, 0.12, 0.8, matEdge, 0, 0.06, R + 0.45, 'deck-step'));
    return g;
  };

  NS.Carport = function (o) {
    var W = o.width || 44;
    var D = o.depth || 10;
    var H = o.height || 3.0;
    var g = new THREE.Group();
    g.name = 'Carport';

    var matPost = solid(0x6f7a80, 0.55, 0.4);
    var matRoof = solid(0x8d9298, 0.7, 0.25);
    var matSlat = solid(0x7a6a55, 0.9);

    var n = Math.max(2, Math.round(W / 6));
    for (var i = 0; i <= n; i++) {
      var x = -W / 2 + (W / n) * i;
      g.add(mesh(0.18, H, 0.18, matPost, x, H / 2, -D / 2 + 0.3, 'carport-post-a-' + i));
      g.add(mesh(0.18, H, 0.18, matPost, x, H / 2, D / 2 - 0.3, 'carport-post-b-' + i));
    }
    g.add(mesh(W, 0.14, D, matRoof, 0, H + 0.07, 0, 'carport-roof'));

    var slats = [];
    for (var sx = -W / 2 + 0.5; sx < W / 2; sx += 0.9) {
      slats.push({ p: [sx, H - 0.12, 0], s: [0.12, 0.12, D - 0.4] });
    }
    add(g, instanced(slats, matSlat, 'carport-slats'));
    return g;
  };

  NS.Fountain = function (o) {
    var R = o.radius || 4;
    var g = new THREE.Group();
    g.name = 'Fountain';

    var matStone = solid(0xb6b0a2, 0.9);
    var matStoneDark = solid(0x8f897c, 0.95);
    var matWater = new THREE.MeshStandardMaterial({
      color: 0x7aa7b8, roughness: 0.06, metalness: 0.3,
      transparent: true, opacity: 0.82
    });
    var matJet = new THREE.MeshStandardMaterial({
      color: 0xdff0f4, roughness: 0.2, metalness: 0.0,
      transparent: true, opacity: 0.55
    });

    // 外圈池壁
    var wall = new THREE.Mesh(new THREE.CylinderGeometry(R, R, 0.62, 32, 1, true), matStone);
    wall.position.y = 0.31;
    wall.castShadow = true;
    wall.receiveShadow = true;
    wall.material.side = THREE.DoubleSide;
    g.add(wall);
    g.add(cylinder(R + 0.12, R + 0.12, 0.1, 32, matStoneDark, 0, 0.64, 0, 'fountain-coping'));

    // 水面
    var water = new THREE.Mesh(new THREE.CircleGeometry(R - 0.16, 32), matWater);
    water.rotation.x = -Math.PI / 2;
    water.position.y = 0.46;
    water.receiveShadow = true;
    water.name = 'fountain-water';
    g.add(water);

    // 中心两层水盘
    g.add(cylinder(0.55, 0.7, 0.9, 16, matStoneDark, 0, 0.9, 0, 'fountain-pedestal'));
    g.add(cylinder(1.5, 1.35, 0.16, 24, matStone, 0, 1.38, 0, 'fountain-bowl-1'));
    g.add(cylinder(0.32, 0.42, 0.7, 12, matStoneDark, 0, 1.78, 0, 'fountain-stem'));
    g.add(cylinder(0.9, 0.8, 0.13, 20, matStone, 0, 2.12, 0, 'fountain-bowl-2'));

    // 水柱（半透明圆柱，不用粒子）
    g.add(cylinder(0.09, 0.13, 1.5, 8, matJet, 0, 2.9, 0, 'jet-core'));
    for (var i = 0; i < 6; i++) {
      var a = (i / 6) * Math.PI * 2;
      var jet = cylinder(0.05, 0.07, 1.1, 6, matJet,
        Math.cos(a) * 1.05, 1.75, Math.sin(a) * 1.05, 'jet-' + i);
      jet.rotation.z = Math.cos(a) * 0.42;
      jet.rotation.x = -Math.sin(a) * 0.42;
      g.add(jet);
    }
    return g;
  };

  /* ============================================================
   * 9. 车 / 公交站 / 邮筒 / 隔离柱
   * ============================================================ */
  NS.Car = function (o) {
    var g = new THREE.Group();
    g.name = 'Car';
    var bodyC = o.color === undefined ? 0x9aa3a8 : o.color;
    var matBody = solid(bodyC, 0.45, 0.35);
    var matGlass = solid(0x2b3a42, 0.15, 0.5);
    var matTire = solid(0x1e2326, 0.85);
    var matHub = solid(0x9aa0a4, 0.5, 0.5);
    var matLight = glow(0xfff4d8, 0xffe9b0, 0.35, 0.5);

    g.add(mesh(1.78, 0.62, 4.1, matBody, 0, 0.62, 0, 'car-body'));
    g.add(mesh(1.62, 0.52, 2.0, matBody, 0, 1.14, -0.15, 'car-cabin'));
    g.add(mesh(1.56, 0.42, 1.84, matGlass, 0, 1.16, -0.15, 'car-glass'));
    g.add(mesh(1.7, 0.1, 0.5, matBody, 0, 1.42, -0.15, 'car-roof'));

    [[-0.83, 1.32], [0.83, 1.32], [-0.83, -1.34], [0.83, -1.34]].forEach(function (p, i) {
      var tire = cylinder(0.33, 0.33, 0.22, 10, matTire, p[0], 0.36, p[1], 'tire-' + i);
      tire.rotation.z = Math.PI / 2;
      g.add(tire);
      var hub = cylinder(0.16, 0.16, 0.235, 8, matHub, p[0], 0.36, p[1], 'hub-' + i);
      hub.rotation.z = Math.PI / 2;
      g.add(hub);
    });

    [-1, 1].forEach(function (s, i) {
      g.add(mesh(0.34, 0.16, 0.06, matLight, s * 0.6, 0.66, 2.06, 'headlight-' + i));
      g.add(mesh(0.3, 0.14, 0.06, solid(0xa8412f, 0.6), s * 0.6, 0.68, -2.06, 'taillight-' + i));
    });
    return g;
  };

  NS.BusStop = function (o) {
    var W = o.width || 5.2;
    var g = new THREE.Group();
    g.name = 'BusStop';

    var matMetal = solid(0x6f7a80, 0.55, 0.4);
    var matGlass = new THREE.MeshStandardMaterial({
      color: 0x9fc4d8, roughness: 0.1, metalness: 0.2,
      transparent: true, opacity: 0.3, side: THREE.DoubleSide, depthWrite: false
    });
    var matRoof = solid(0x5d666c, 0.7, 0.2);
    var matSign = solid(0x2f5d8a, 0.75);

    [-1, 1].forEach(function (s, i) {
      g.add(mesh(0.12, 2.7, 0.12, matMetal, s * (W / 2 - 0.3), 1.35, -0.8, 'bus-post-' + i));
    });
    g.add(mesh(W, 0.16, 1.9, matRoof, 0, 2.75, 0, 'bus-roof'));
    g.add(mesh(W - 0.4, 1.9, 0.06, matGlass, 0, 1.55, -0.86, 'bus-glass-back'));
    g.add(mesh(1.8, 0.1, 0.5, solid(0xb07a45, 0.85), -0.6, 0.55, -0.5, 'bus-bench'));
    [-1.2, 0].forEach(function (x, i) {
      g.add(mesh(0.08, 0.55, 0.4, matMetal, x, 0.27, -0.5, 'bus-bench-leg-' + i));
    });
    g.add(mesh(0.5, 1.4, 0.08, matSign, W / 2 + 0.45, 1.9, 0, 'bus-sign'));
    g.add(cylinder(0.07, 0.07, 2.6, 6, matMetal, W / 2 + 0.45, 1.3, 0, 'bus-sign-post'));
    return g;
  };

  NS.Mailbox = function () {
    var g = new THREE.Group();
    g.name = 'Mailbox';
    var matPost = solid(0x5d666c, 0.6, 0.3);
    var matBox = solid(0x3f6d8c, 0.6, 0.15);
    g.add(mesh(0.1, 1.0, 0.1, matPost, 0, 0.5, 0, 'mail-post'));
    g.add(mesh(0.5, 0.36, 0.34, matBox, 0, 1.1, 0, 'mail-box'));
    g.add(mesh(0.34, 0.05, 0.02, solid(0xe8e3d4, 0.8), 0, 1.16, 0.18, 'mail-slot'));
    return g;
  };

  NS.Bollard = function () {
    var g = new THREE.Group();
    g.name = 'Bollard';
    var mat = solid(0x6e777c, 0.55, 0.3);
    g.add(cylinder(0.1, 0.12, 0.85, 8, mat, 0, 0.425, 0, 'bollard'));
    g.add(mesh(0.24, 0.05, 0.24, mat, 0, 0.86, 0, 'bollard-cap'));
    return g;
  };

  /* ============================================================
   * 统一注册兜底：保证返回 Group 且报错带物件名
   * ============================================================ */
  Object.keys(NS).forEach(function (k) {
    if (typeof NS[k] !== 'function' || NS[k].__wrapped) return;
    var raw = NS[k];
    if (['Building', 'Interior', 'Character', 'Environment', 'Road', 'Sidewalk', 'Crosswalk',
      'AssemblyPoint', 'StreetLamp', 'Tree', 'Bench', 'TrashBin', 'Railing', 'Signboard',
      'Billboard', 'PowerPole'].indexOf(k) >= 0) return;
    var wrapped = function (options) {
      if (!global.THREE) throw new Error(k + ' model failed: THREE is not loaded');
      var g = raw(options || {});
      if (!g || !g.isObject3D) throw new Error(k + ' builder did not return a THREE.Group');
      g.name = g.name || k;
      return g;
    };
    wrapped.__wrapped = true;
    NS[k] = wrapped;
  });
})(window);
