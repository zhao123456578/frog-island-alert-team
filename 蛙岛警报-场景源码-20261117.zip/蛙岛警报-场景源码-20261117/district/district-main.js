/* ============================================================
 * district-main.js — 云栖里街区漫游控制器（基于根目录 main.js 的街区版）
 * 依赖：three.js + window.GameModels + window.SCENE_LAYOUT（district-layout.js）
 * 相对原版的差异：
 *   1) 阴影相机 / 雾距 / 远裁剪面按 260×220m 街区放大
 *   2) 加渐变天穹，效果图更像成品渲染
 *   3) 支持 ?shot=hero|street|axis 固定机位出图，出图时隐藏 HUD
 *   4) 出生点与初始朝向来自布局数据，不再写死
 * ============================================================ */
(function (global) {
  'use strict';

  var THREE = global.THREE;
  var elStatus = document.getElementById('hud-status');
  var elLoading = document.getElementById('loading');
  var elFatal = document.getElementById('fatal');

  function fatal(msg) {
    if (elLoading) elLoading.style.display = 'none';
    if (elFatal) { elFatal.style.display = 'block'; elFatal.textContent = msg; }
  }

  if (!THREE) { fatal('three.js 未加载：请检查 three.min.js 是否与 index.html 同目录。'); return; }
  if (!global.GameModels) { fatal('模型未加载：请检查 building.js / environment.js / player.js。'); return; }
  if (!global.SCENE_LAYOUT) { fatal('布局未加载：请检查 scene-layout.js。'); return; }

  /* ================= 参数 ================= */
  var CFG = {
    walkSpeed: 4.8,
    runSpeed: 7.4,
    crouchSpeed: 2.2,
    accel: 55,          // 地面加速（越大越跟手）
    decel: 60,
    airAccel: 9,
    gravity: 26,
    jumpSpeed: 7.2,
    jumpCut: 0.55,      // 提前松开空格，跳跃高度衰减
    coyote: 0.11,       // 离开地面后仍可起跳的宽限
    jumpBuffer: 0.12,   // 落地前提前按跳
    radius: 0.34,
    standHeight: 1.8,
    crouchHeight: 1.12,
    stepUp: 0.45,
    camDistance: 4.6,
    camMin: 1.8,
    camMax: 10,
    camFollow: 16,
    mouseSensitivity: 0.0022,
    shoulder: 0.42,     // 过肩偏移
    fov: 58,
    fovSprint: 67
  };

  /* ================= 渲染器 / 场景 ================= */
  var renderer = new THREE.WebGLRenderer({ antialias: true });
  renderer.setPixelRatio(Math.min(2, global.devicePixelRatio || 1));
  renderer.setSize(global.innerWidth, global.innerHeight);
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  if (THREE.SRGBColorSpace && 'outputColorSpace' in renderer) {
    renderer.outputColorSpace = THREE.SRGBColorSpace;
  } else if (THREE.sRGBEncoding) {
    renderer.outputEncoding = THREE.sRGBEncoding;
  }
  renderer.toneMapping = (function () {
    try {
      var t = new URLSearchParams(global.location.search || '').get('tone');
      if (t === 'aces' && THREE.ACESFilmicToneMapping) return THREE.ACESFilmicToneMapping;
    } catch (e) { /* ignore */ }
    return THREE.NoToneMapping;
  })();
  renderer.toneMappingExposure = 1.02;
  document.getElementById('app').appendChild(renderer.domElement);
  renderer.domElement.style.touchAction = 'none';

  var scene = new THREE.Scene();
  scene.background = new THREE.Color(0xd3e0e8);
  scene.fog = new THREE.Fog(0xd3e0e8, 250, 760);

  var camera = new THREE.PerspectiveCamera(CFG.fov, global.innerWidth / global.innerHeight, 0.1, 1800);

  // 渐变天穹（画布贴图，不依赖外部资源）
  (function buildSky() {
    try {
      var cv = document.createElement('canvas');
      cv.width = 4; cv.height = 256;
      var ctx = cv.getContext('2d');
      var grd = ctx.createLinearGradient(0, 0, 0, 256);
      grd.addColorStop(0.00, '#7fb2d3');
      grd.addColorStop(0.42, '#b8d3e2');
      grd.addColorStop(0.72, '#dde8ec');
      grd.addColorStop(1.00, '#eef1ec');
      ctx.fillStyle = grd;
      ctx.fillRect(0, 0, 4, 256);
      var tex = new THREE.CanvasTexture(cv);
      if (THREE.sRGBEncoding) tex.encoding = THREE.sRGBEncoding;
      var dome = new THREE.Mesh(
        new THREE.SphereGeometry(900, 24, 18),
        new THREE.MeshBasicMaterial({ map: tex, side: THREE.BackSide, fog: false, depthWrite: false })
      );
      dome.position.y = -60;
      dome.name = 'sky-dome';
      dome.renderOrder = -1;
      scene.add(dome);
    } catch (e) { /* 天穹失败不影响场景 */ }
  })();

  scene.add(new THREE.HemisphereLight(0xdfeaff, 0x86877a, 0.34));

  var sun = new THREE.DirectionalLight(0xfff1d8, 0.95);
  sun.position.set(-90, 135, 95);
  sun.castShadow = true;
  var isShotUrl = (global.location.search || '').indexOf('shot=') >= 0;
  sun.shadow.mapSize.set(isShotUrl ? 4096 : 2048, isShotUrl ? 4096 : 2048);
  sun.shadow.camera.left = -150;
  sun.shadow.camera.right = 150;
  sun.shadow.camera.top = 150;
  sun.shadow.camera.bottom = -150;
  sun.shadow.camera.near = 10;
  sun.shadow.camera.far = 520;
  sun.shadow.camera.updateProjectionMatrix();
  sun.shadow.bias = -0.0006;
  scene.add(sun);
  scene.add(sun.target);

  /* ================= 关卡（按布局实例化） ================= */
  var level = new THREE.Group();
  level.name = 'Level';
  scene.add(level);

  var colliders = [];     // { id, box }
  var walkables = [];     // 可站立的面（射线检测用）
  var problems = [];

  // 世界空间 AABB：把布局里的碰撞盒按 yaw 旋转后取外包络
  function boxFromSpec(o, size, offset) {
    var sc = o.scale || [1, 1, 1];
    var hx = size[0] * sc[0] / 2;
    var hy = size[1] * sc[1] / 2;
    var hz = size[2] * sc[2] / 2;
    var ang = o.rotation[1] || 0;
    var ca = Math.abs(Math.cos(ang));
    var sa = Math.abs(Math.sin(ang));
    var ox = (offset ? offset[0] : 0) * sc[0];
    var oy = (offset ? offset[1] : 0) * sc[1];
    var oz = (offset ? offset[2] : 0) * sc[2];
    var wx = o.position[0] + ox * Math.cos(ang) + oz * Math.sin(ang);
    var wz = o.position[2] - ox * Math.sin(ang) + oz * Math.cos(ang);
    var wy = o.position[1] + oy;
    return new THREE.Box3(
      new THREE.Vector3(wx - (ca * hx + sa * hz), wy - hy, wz - (sa * hx + ca * hz)),
      new THREE.Vector3(wx + (ca * hx + sa * hz), wy + hy, wz + (sa * hx + ca * hz))
    );
  }

  var elevator = null;

  global.SCENE_LAYOUT.objects.forEach(function (o) {
    var factory = global.GameModels[o.model];
    if (!factory) { problems.push('缺少模型：' + o.model); return; }

    var obj;
    try {
      obj = factory(o.options);
    } catch (err) {
      problems.push(o.id + ' → ' + err.message);
      return;
    }

    obj.position.fromArray(o.position);
    obj.rotation.set(o.rotation[0] || 0, o.rotation[1] || 0, o.rotation[2] || 0);
    obj.scale.fromArray(o.scale || [1, 1, 1]);
    obj.userData.layoutId = o.id;
    level.add(obj);

    if (o.collision && o.collision.type === 'aabb') {
      colliders.push({ id: o.id, box: boxFromSpec(o, o.collision.size, o.collision.offset) });
    } else if (o.collision && o.collision.type === 'aabbs') {
      o.collision.boxes.forEach(function (b, bi) {
        colliders.push({ id: o.id + '#' + bi, box: boxFromSpec(o, b.size, b.offset) });
      });
    }

    // 模型自带的碰撞盒（室内墙体 / 家具）
    if (obj.userData.colliders) {
      obj.userData.colliders.forEach(function (c, ci) {
        var px = obj.position.x + c.offset[0];
        var py = obj.position.y + c.offset[1];
        var pz = obj.position.z + c.offset[2];
        colliders.push({
          id: o.id + '-self-' + ci,
          box: new THREE.Box3(
            new THREE.Vector3(px - c.size[0] / 2, py - c.size[1] / 2, pz - c.size[2] / 2),
            new THREE.Vector3(px + c.size[0] / 2, py + c.size[1] / 2, pz + c.size[2] / 2)
          )
        });
      });
    }

    // 模型自带的灯光（室内）
    if (obj.userData.lights) {
      obj.userData.lights.forEach(function (L) {
        var light = new THREE.PointLight(L.color || 0xffffff, L.intensity || 1, L.distance || 10, 1);
        light.position.set(obj.position.x + L.offset[0], obj.position.y + L.offset[1], obj.position.z + L.offset[2]);
        if (L.shadow) {
          light.castShadow = true;
          light.shadow.mapSize.set(512, 512);
          light.shadow.bias = -0.002;
          light.shadow.camera.near = 0.4;
          light.shadow.camera.far = L.distance || 12;
        }
        light.name = o.id + '-light';
        scene.add(light);
      });
    }

    if (obj.userData.elevator) {
      elevator = obj.userData.elevator;
      // 电梯句柄里的 center 是室内局部坐标，主楼不在原点时要换算到世界坐标
      elevator.center.x += obj.position.x;
      elevator.center.z += obj.position.z;
    }
  });

  level.traverse(function (n) {
    if (n.isMesh && n.userData.walk) walkables.push(n);
  });

  // 轿厢内灯（跟随轿厢移动）
  if (elevator) {
    var cabinLight = new THREE.PointLight(0xfff4e6, 1.3, 6, 1);
    cabinLight.position.set(0, 2.1, 0);
    cabinLight.name = 'cabin-light';
    elevator.cabin.add(cabinLight);
  }

  /* ================= 角色 ================= */
  var character = global.GameModels.Character({});
  scene.add(character);
  if ((global.location.search || '').indexOf('shot=') >= 0) character.visible = false;   // 出图时不出现角色

  var spawnData = global.SCENE_LAYOUT.spawn || { position: [0, 0.2, 30] };
  var spawnPos = spawnData.position;

  var player = {
    pos: new THREE.Vector3(spawnPos[0], spawnPos[1], spawnPos[2]),
    vel: new THREE.Vector3(),
    heading: Math.PI,
    height: CFG.standHeight,
    crouch: 0,
    onGround: true,
    phase: 0,
    jumpQueued: false,
    jumpBuffer: 0,
    coyote: 0,
    sprinting: false
  };

  character.position.copy(player.pos);
  character.rotation.y = player.heading;

  var camYaw = Math.PI;
  var camPitch = 0.22;
  var camDist = CFG.camDistance;

  /* ================= 出图机位（?shot=hero|street|axis） ================= */
  var SHOT = (function () {
    try {
      var q = new URLSearchParams(global.location.search || '');
      return q.get('shot');
    } catch (e) { return null; }
  })();
  var shotCfg = (SHOT && global.SCENE_LAYOUT.shots) ? global.SCENE_LAYOUT.shots[SHOT] : null;
  var shotMode = !!shotCfg;
  var shotLook = new THREE.Vector3();
  if (shotMode) {
    document.body.classList.add('shot');
    shotLook.fromArray(shotCfg.target);
    camera.position.fromArray(shotCfg.pos);
    camera.fov = shotCfg.fov || CFG.fov;
    camera.updateProjectionMatrix();
    camera.lookAt(shotLook);
  }

  /* ================= 输入 ================= */
  var keys = Object.create(null);
  var dragging = false;
  var lastX = 0, lastY = 0;

  global.addEventListener('keydown', function (e) {
    if (e.code === 'F1') {
      e.preventDefault();
      toggleDev();
      return;
    }
    if (e.code === 'KeyR') {
      respawn();
      return;
    }
    if (e.code === 'KeyE') {
      useElevator();
      return;
    }
    if (e.code === 'Space') e.preventDefault();
    if (e.code === 'Space' && !keys.Space) player.jumpQueued = true;
    keys[e.code] = true;
  });

  global.addEventListener('keyup', function (e) {
    // 提前松手 → 跳跃高度变矮，落地更干脆
    if (e.code === 'Space' && player.vel.y > 2.2) player.vel.y *= CFG.jumpCut;
    keys[e.code] = false;
  });

  global.addEventListener('blur', function () {
    for (var k in keys) keys[k] = false;
    dragging = false;
  });

  var dom = renderer.domElement;
  var locked = false;

  function requestLock() {
    if (!dom.requestPointerLock) return;
    var p = dom.requestPointerLock();
    if (p && typeof p.catch === 'function') p.catch(function () { });
  }

  dom.addEventListener('click', function () {
    var hint = document.getElementById('lock-hint');
    if (hint) hint.style.display = 'none';   // 即使锁定被浏览器拒绝，也先收起引导
    if (!locked) requestLock();
  });

  document.addEventListener('pointerlockchange', function () {
    locked = document.pointerLockElement === dom;
    var hint = document.getElementById('lock-hint');
    if (hint) hint.style.display = locked ? 'none' : 'flex';
  });

  // 指针锁定：真正的 FPS 视角；未锁定时退化为拖动
  document.addEventListener('mousemove', function (e) {
    if (!locked) return;
    camYaw -= e.movementX * CFG.mouseSensitivity;
    camPitch = clamp(camPitch + e.movementY * CFG.mouseSensitivity, -0.45, 1.08);
  });

  dom.addEventListener('pointerdown', function (e) {
    if (locked) return;
    dragging = true;
    lastX = e.clientX;
    lastY = e.clientY;
    try { dom.setPointerCapture(e.pointerId); } catch (err) { /* 合成事件可能没有真实指针 */ }
  });

  dom.addEventListener('pointermove', function (e) {
    if (!dragging || locked) return;
    camYaw -= (e.clientX - lastX) * 0.0045;
    camPitch = clamp(camPitch + (e.clientY - lastY) * 0.0032, -0.45, 1.08);
    lastX = e.clientX;
    lastY = e.clientY;
  });

  dom.addEventListener('pointerup', function (e) {
    dragging = false;
    if (dom.hasPointerCapture && dom.hasPointerCapture(e.pointerId)) dom.releasePointerCapture(e.pointerId);
  });

  dom.addEventListener('wheel', function (e) {
    e.preventDefault();
    camDist = clamp(camDist + e.deltaY * 0.004, CFG.camMin, CFG.camMax);
  }, { passive: false });

  /* ================= 工具 ================= */
  function clamp(v, a, b) { return v < a ? a : (v > b ? b : v); }

  function damp(current, target, lambda, dt) {
    return current + (target - current) * (1 - Math.exp(-lambda * dt));
  }

  function angleLerp(a, b, t) {
    var d = ((b - a + Math.PI) % (Math.PI * 2) + Math.PI * 2) % (Math.PI * 2) - Math.PI;
    return a + d * t;
  }

  var boxTmp = new THREE.Box3();
  var rayOrigin = new THREE.Vector3();
  var DOWN = new THREE.Vector3(0, -1, 0);
  var raycaster = new THREE.Raycaster();

  function playerBox(out) {
    out.min.set(player.pos.x - CFG.radius, player.pos.y, player.pos.z - CFG.radius);
    out.max.set(player.pos.x + CFG.radius, player.pos.y + player.height, player.pos.z + CFG.radius);
    return out;
  }

  // 地面高度（射线打在可站立面上）
  function groundHeight() {
    if (!walkables.length) return 0;
    rayOrigin.set(player.pos.x, player.pos.y + 0.7, player.pos.z);
    raycaster.set(rayOrigin, DOWN);
    raycaster.far = 10;
    var hits = raycaster.intersectObjects(walkables, false);
    return hits.length ? hits[0].point.y : 0;
  }

  // 支撑面 = 地面与「脚边低矮碰撞体顶面」的较高者
  function supportHeight() {
    var gh = groundHeight();
    var r = CFG.radius;
    for (var i = 0; i < colliders.length; i++) {
      var c = colliders[i].box;
      if (player.pos.x + r <= c.min.x || player.pos.x - r >= c.max.x) continue;
      if (player.pos.z + r <= c.min.z || player.pos.z - r >= c.max.z) continue;
      if (c.max.y <= player.pos.y + CFG.stepUp + 0.02 && c.max.y > gh) gh = c.max.y;
    }
    return gh;
  }

  function resolveHorizontal(axis, dir) {
    if (dir === 0) return;
    var box = playerBox(boxTmp);

    for (var i = 0; i < colliders.length; i++) {
      var c = colliders[i].box;
      // 顶面与脚底齐平（或更低）的碰撞体不参与水平阻挡
      if (c.max.y <= player.pos.y + 0.02) continue;
      if (!box.intersectsBox(c)) continue;

      // 低矮台阶：直接抬脚站上去，不阻挡
      var rise = c.max.y - player.pos.y;
      if (player.vel.y <= 0.01 && rise > 0.02 && rise <= CFG.stepUp) {
        player.pos.y = c.max.y;
        box = playerBox(boxTmp);
        continue;
      }

      if (axis === 'x') {
        player.pos.x = dir > 0 ? c.min.x - CFG.radius - 0.001 : c.max.x + CFG.radius + 0.001;
      } else {
        player.pos.z = dir > 0 ? c.min.z - CFG.radius - 0.001 : c.max.z + CFG.radius + 0.001;
      }
      player.vel[axis] = 0;
      box = playerBox(boxTmp);
    }
  }

  function resolveVertical() {
    if (player.vel.y > 0) return;
    var box = playerBox(boxTmp);
    var bestTop = -Infinity;

    for (var i = 0; i < colliders.length; i++) {
      var c = colliders[i].box;
      if (box.max.x <= c.min.x || box.min.x >= c.max.x) continue;
      if (box.max.z <= c.min.z || box.min.z >= c.max.z) continue;
      if (player.pos.y <= c.max.y + 0.02 && c.max.y - player.pos.y <= CFG.stepUp + 0.35 && c.max.y > bestTop) {
        bestTop = c.max.y;
      }
    }

    if (bestTop > -Infinity) {
      player.pos.y = bestTop;
      player.vel.y = 0;
      player.onGround = true;
    }
  }

  /* ================= 更新 ================= */
  var forward = new THREE.Vector3();
  var right = new THREE.Vector3();
  var wish = new THREE.Vector3();
  var UP = new THREE.Vector3(0, 1, 0);

  function updatePlayer(dt) {
    forward.set(Math.sin(camYaw), 0, Math.cos(camYaw));
    right.crossVectors(forward, UP);

    var ix = (keys.KeyD ? 1 : 0) - (keys.KeyA ? 1 : 0);
    var iz = (keys.KeyW ? 1 : 0) - (keys.KeyS ? 1 : 0);

    wish.set(0, 0, 0);
    if (ix || iz) {
      wish.addScaledVector(forward, iz).addScaledVector(right, ix).normalize();
    }

    // 电梯运行（含关门等待）期间锁住横向移动，避免走出轿厢
    if (elevator && (liftState.moving || liftState.wait > 0) && inCabin()) {
      wish.set(0, 0, 0);
      player.vel.x = 0;
      player.vel.z = 0;
    }

    /* --- 下蹲 --- */
    var wantCrouch = !!keys.KeyC;
    if (!wantCrouch && player.height < CFG.standHeight - 0.02) {
      // 头顶有东西时不能站起来
      var test = new THREE.Box3(
        new THREE.Vector3(player.pos.x - CFG.radius, player.pos.y, player.pos.z - CFG.radius),
        new THREE.Vector3(player.pos.x + CFG.radius, player.pos.y + CFG.standHeight, player.pos.z + CFG.radius)
      );
      for (var ci = 0; ci < colliders.length; ci++) {
        if (colliders[ci].box.intersectsBox(test)) { wantCrouch = true; break; }
      }
    }
    player.crouch = damp(player.crouch, wantCrouch ? 1 : 0, 12, dt);
    player.height = CFG.standHeight + (CFG.crouchHeight - CFG.standHeight) * player.crouch;

    /* --- 水平速度（高加速度，松手即停）--- */
    var running = (keys.ShiftLeft || keys.ShiftRight) && player.crouch < 0.4;
    var speed = player.crouch > 0.5 ? CFG.crouchSpeed : (running ? CFG.runSpeed : CFG.walkSpeed);
    player.sprinting = running && player.onGround && wish.lengthSq() > 0.01;
    var hasInput = wish.lengthSq() > 0.001;
    var rate = player.onGround ? (hasInput ? CFG.accel : CFG.decel) : CFG.airAccel;
    var k = 1 - Math.exp(-rate * dt);
    player.vel.x += (wish.x * speed - player.vel.x) * k;
    player.vel.z += (wish.z * speed - player.vel.z) * k;

    /* --- 跳跃：coyote time + 输入缓冲 --- */
    if (player.jumpQueued) {
      player.jumpQueued = false;
      player.jumpBuffer = CFG.jumpBuffer;
    }
    player.jumpBuffer = Math.max(0, player.jumpBuffer - dt);
    player.coyote = player.onGround ? CFG.coyote : Math.max(0, player.coyote - dt);

    if (player.jumpBuffer > 0 && player.coyote > 0 && player.crouch < 0.65) {
      player.vel.y = CFG.jumpSpeed;
      player.onGround = false;
      player.jumpBuffer = 0;
      player.coyote = 0;
    }

    player.vel.y -= CFG.gravity * dt;
    if (player.vel.y < -32) player.vel.y = -32;

    /* --- 位移 + 碰撞 --- */
    var wasGround = player.onGround;
    player.onGround = false;

    player.pos.x += player.vel.x * dt;
    resolveHorizontal('x', Math.sign(player.vel.x));

    player.pos.z += player.vel.z * dt;
    resolveHorizontal('z', Math.sign(player.vel.z));

    player.pos.y += player.vel.y * dt;
    resolveVertical();

    var impact = -player.vel.y;
    var gh = supportHeight();
    var snap = wasGround ? CFG.stepUp : 0.04;
    if (player.vel.y <= 0 && player.pos.y <= gh + snap) {
      player.pos.y = gh;
      player.vel.y = 0;
      player.onGround = true;
      if (!wasGround && impact > 3.5) camDip = Math.max(-0.24, -impact * 0.022);
    }

    // 站在电梯里：随轿厢升降
    if (elevator && inCabin()) {
      player.pos.y = liftState.y;
      player.vel.y = 0;
      player.onGround = true;
    }

    /* --- 街区边界，避免走出地面 --- */
    var bounds = global.SCENE_LAYOUT.bounds;
    if (bounds && bounds.size) {
      var halfX = bounds.size[0] / 2 - 1;
      var halfZ = bounds.size[1] / 2 - 1;
      player.pos.x = clamp(player.pos.x, -halfX, halfX);
      player.pos.z = clamp(player.pos.z, -halfZ, halfZ);
    }

    /* --- 朝向 --- */
    if (wish.lengthSq() > 0.001) {
      var target = Math.atan2(wish.x, wish.z);
      player.heading = angleLerp(player.heading, target, 1 - Math.exp(-14 * dt));
    }

    character.position.copy(player.pos);
    character.rotation.y = player.heading;

    poseCharacter(dt);
  }

  /* ================= 角色姿态 ================= */
  function poseCharacter(dt) {
    var p = character.userData.parts;
    var hSpeed = Math.hypot(player.vel.x, player.vel.z);
    var crouchF = player.crouch;
    var moveF = Math.min(1, hSpeed / CFG.walkSpeed);
    var airF = player.onGround ? 0 : 1;

    if (player.onGround && hSpeed > 0.25) {
      player.phase += dt * (3.2 + hSpeed * 1.5);
    }

    var swing = Math.sin(player.phase) * moveF * (1 - 0.65 * crouchF) * 0.62;
    var d = 1 - Math.exp(-16 * dt);

    function rot(obj, x) {
      obj.rotation.x += (x - obj.rotation.x) * d;
    }

    rot(p.legL, -swing - crouchF * 1.0 - airF * 0.28);
    rot(p.legR, swing - crouchF * 1.0 - airF * 0.28);
    rot(p.kneeL, Math.max(0, swing) * 1.1 + crouchF * 1.75 + airF * 0.95);
    rot(p.kneeR, Math.max(0, -swing) * 1.1 + crouchF * 1.75 + airF * 0.95);
    rot(p.armL, swing * 0.75 + crouchF * 0.4 - airF * 0.85);
    rot(p.armR, -swing * 0.75 + crouchF * 0.4 - airF * 0.85);
    rot(p.elbowL, -0.18 - crouchF * 0.55 - airF * 0.5);
    rot(p.elbowR, -0.18 - crouchF * 0.55 - airF * 0.5);

    p.body.position.y += ((crouchF * -0.42 + airF * 0.03) - p.body.position.y) * d;
    p.body.rotation.x += ((crouchF * 0.16) - p.body.rotation.x) * d;
  }

  /* ================= 入户电梯（玻璃梯） ================= */
  var liftState = { y: 0, target: 0, moving: false, doors: 0, doorTarget: 1, floor: 0, wait: 0 };
  var elPrompt = document.getElementById('prompt');

  function inCabin() {
    if (!elevator) return false;
    return Math.abs(player.pos.x - elevator.center.x) < 1.12 &&
           Math.abs(player.pos.z - elevator.center.z) < 1.32 &&
           Math.abs(player.pos.y - liftState.y) < 1.4;
  }

  function nearLiftZone(which) {
    if (!elevator) return false;
    var cx2 = elevator.center.x, cz2 = elevator.center.z;
    if (which === 0) {
      return player.pos.y < 3.0 && player.pos.x > cx2 - 2.8 && player.pos.x < cx2 + 0.6 &&
             Math.abs(player.pos.z - cz2) < 1.8;
    }
    // 8F 门洞位置跟随电梯井，不写死绝对坐标
    return player.pos.y > 21.2 && player.pos.y < 25.6 && player.pos.x > cx2 + 0.8 && player.pos.x < cx2 + 4.2 &&
           Math.abs(player.pos.z - cz2) < 1.7;
  }

  function useElevator() {
    if (!elevator || liftState.moving || liftState.wait > 0) return;

    // 轿厢内：开门 / 关门并去另一层
    if (inCabin()) {
      if (liftState.doors > 0.55) {
        liftState.doorTarget = 0;
        liftState.floor = liftState.floor === 0 ? 1 : 0;
        liftState.target = elevator.floors[liftState.floor];
        liftState.wait = 0.6;
      } else {
        liftState.doorTarget = 1;
      }
      return;
    }

    // 轿厢外：叫梯
    var want = nearLiftZone(1) ? 1 : (nearLiftZone(0) ? 0 : -1);
    if (want < 0) return;

    if (Math.abs(liftState.y - elevator.floors[want]) > 0.05) {
      liftState.floor = want;
      liftState.target = elevator.floors[want];
      liftState.moving = true;
      liftState.doorTarget = 0;
    } else {
      liftState.doorTarget = 1;
    }
  }

  function updateLift(dt) {
    if (!elevator) return;

    liftState.doors += (liftState.doorTarget - liftState.doors) * (1 - Math.exp(-7 * dt));
    liftState.doors = clamp(liftState.doors, 0, 1);

    if (liftState.wait > 0) {
      liftState.wait -= dt;
      if (liftState.wait <= 0) liftState.moving = true;
    }

    if (liftState.moving) {
      var dy = liftState.target - liftState.y;
      var step = Math.sign(dy) * Math.min(Math.abs(dy), 4.0 * dt);
      liftState.y += step;
      if (Math.abs(liftState.target - liftState.y) < 0.008) {
        liftState.y = liftState.target;
        liftState.moving = false;
        liftState.doorTarget = 1;
      }
    }

    elevator.cabin.position.y = liftState.y;

    var openOuter = liftState.floor === 0 ? liftState.doors : 0;
    var openInner = liftState.floor === 1 ? liftState.doors : 0;
    for (var i = 0; i < 2; i++) {
      var sign = i === 0 ? -1 : 1;
      var slide = elevator.doorClosedZ + (elevator.doorOpenZ - elevator.doorClosedZ);
      elevator.doorsOuter[i].position.z = sign * (elevator.doorClosedZ + (slide - elevator.doorClosedZ) * openOuter);
      elevator.doorsInner[i].position.z = sign * (elevator.doorClosedZ + (slide - elevator.doorClosedZ) * openInner);
    }

    if (elPrompt) {
      var tip = '';
      if (!liftState.moving) {
        if (inCabin()) {
          tip = liftState.doors > 0.6
            ? (liftState.floor === 0 ? '按 E 上行到 8F' : '按 E 回到地面')
            : '按 E 开门';
        } else if (nearLiftZone(0) || nearLiftZone(1)) {
          tip = '按 E 乘坐电梯';
        }
      }
      elPrompt.textContent = tip;
      elPrompt.style.opacity = tip ? '1' : '0';
    }
  }

  /* ================= 相机 ================= */
  var camDip = 0;
  var camTarget = new THREE.Vector3();
  var camDesired = new THREE.Vector3();
  var camDir = new THREE.Vector3();
  var camProbe = new THREE.Vector3();
  var camInit = false;

  function pointBlocked(p) {
    for (var i = 0; i < colliders.length; i++) {
      var c = colliders[i].box;
      if (p.x > c.min.x - 0.25 && p.x < c.max.x + 0.25 &&
          p.y > c.min.y - 0.05 && p.y < c.max.y + 0.25 &&
          p.z > c.min.z - 0.25 && p.z < c.max.z + 0.25) return true;
    }
    return false;
  }

  function updateCamera(dt) {
    if (shotMode) {
      camera.position.fromArray(shotCfg.pos);
      var sf = shotCfg.fov || CFG.fov;
      if (camera.fov !== sf) {
        camera.fov = sf;
        camera.updateProjectionMatrix();
      }
      camera.lookAt(shotLook);
      return;
    }
    // 过肩视角：目标点向相机右侧偏移，准星位置让给小人的左肩
    var rightX = -Math.cos(camYaw);
    var rightZ = Math.sin(camYaw);
    camDip += (0 - camDip) * (1 - Math.exp(-9 * dt));
    var bob = player.onGround ? Math.sin(player.phase * 2) * 0.012 * Math.min(1, Math.hypot(player.vel.x, player.vel.z) / CFG.walkSpeed) : 0;

    camTarget.set(
      player.pos.x + rightX * CFG.shoulder,
      player.pos.y + player.height * 0.74 + camDip + bob,
      player.pos.z + rightZ * CFG.shoulder
    );

    var cp = Math.cos(camPitch);
    var sp = Math.sin(camPitch);
    camDir.set(-Math.sin(camYaw) * cp, sp, -Math.cos(camYaw) * cp);

    var dist = camDist;
    for (var t = 0.25; t <= 1.0001; t += 0.075) {
      camProbe.copy(camTarget).addScaledVector(camDir, camDist * t);
      if (pointBlocked(camProbe)) {
        dist = Math.max(CFG.camMin * 0.6, camDist * (t - 0.07));
        break;
      }
    }

    camDesired.copy(camTarget).addScaledVector(camDir, dist);
    if (camDesired.y < 0.55) camDesired.y = 0.55;

    if (!camInit) {
      camera.position.copy(camDesired);
      camInit = true;
    } else {
      camera.position.lerp(camDesired, 1 - Math.exp(-CFG.camFollow * dt));
    }
    camera.lookAt(camTarget);

    // 冲刺时轻微拉伸视野，强化速度感
    var targetFov = player.sprinting ? CFG.fovSprint : CFG.fov;
    if (Math.abs(camera.fov - targetFov) > 0.05) {
      camera.fov += (targetFov - camera.fov) * (1 - Math.exp(-7 * dt));
      camera.updateProjectionMatrix();
    }
  }

  /* ================= 开发者模式：碰撞体积 ================= */
  var devGroup = new THREE.Group();
  devGroup.name = 'DevColliders';
  scene.add(devGroup);

  var UNIT_BOX_DEV = new THREE.BoxGeometry(1, 1, 1);

  function addCollisionVolume(box, color) {
    var size = box.getSize(new THREE.Vector3());
    var center = box.getCenter(new THREE.Vector3());
    var group = new THREE.Group();
    var volume = size.x * size.y * size.z;

    // 小物件加半透明体块，便于看清体积；大楼等大体块只画线，避免挡住视线
    if (volume < 150) {
      var fill = new THREE.Mesh(UNIT_BOX_DEV, new THREE.MeshBasicMaterial({
        color: color, transparent: true, opacity: 0.07, depthWrite: false, side: THREE.DoubleSide
      }));
      fill.scale.set(size.x, size.y, size.z);
      fill.position.copy(center);
      group.add(fill);
    }

    var edges = new THREE.LineSegments(
      new THREE.EdgesGeometry(UNIT_BOX_DEV),
      new THREE.LineBasicMaterial({ color: color, transparent: true, opacity: 0.85 })
    );
    edges.scale.set(size.x, size.y, size.z);
    edges.position.copy(center);
    group.add(edges);

    return group;
  }

  colliders.forEach(function (c) {
    var vol = addCollisionVolume(c.box, 0xff3b30);
    vol.name = 'collider-' + c.id;
    devGroup.add(vol);
  });

  // 玩家自身包围盒（每帧更新）
  var playerFill = new THREE.Mesh(UNIT_BOX_DEV, new THREE.MeshBasicMaterial({
    color: 0x00c07a, transparent: true, opacity: 0.05, depthWrite: false, side: THREE.DoubleSide
  }));
  var playerEdges = new THREE.LineSegments(
    new THREE.EdgesGeometry(UNIT_BOX_DEV),
    new THREE.LineBasicMaterial({ color: 0x00c07a, transparent: true, opacity: 0.95 })
  );
  playerFill.name = 'player-box';
  playerEdges.name = 'player-box-edges';
  scene.add(playerFill, playerEdges);

  function updatePlayerHelper() {
    var b = playerBox(boxTmp);
    var size = b.getSize(new THREE.Vector3());
    var center = b.getCenter(new THREE.Vector3());
    playerFill.scale.set(size.x, size.y, size.z);
    playerFill.position.copy(center);
    playerEdges.scale.set(size.x, size.y, size.z);
    playerEdges.position.copy(center);
  }

  var devEnabled = false;
  devGroup.visible = devEnabled;
  playerFill.visible = devEnabled;
  playerEdges.visible = devEnabled;

  function toggleDev() {
    devEnabled = !devEnabled;
    devGroup.visible = devEnabled;
    playerFill.visible = devEnabled;
    playerEdges.visible = devEnabled;
    updateHud(true);
  }

  /* ================= HUD ================= */
  var triCount = 0;
  var meshCount = 0;
  scene.traverse(function (n) {
    if (!n.isMesh) return;
    meshCount++;
    var g = n.geometry;
    var t = g.index ? g.index.count / 3 : g.attributes.position.count / 3;
    triCount += t * (n.isInstancedMesh ? n.count : 1);
  });

  var fps = 60, hudTimer = 0;

  function updateHud(force) {
    if (!elStatus) return;
    var state = !player.onGround ? '腾空' : (player.crouch > 0.5 ? '下蹲' : (Math.hypot(player.vel.x, player.vel.z) > 0.4 ? '移动' : '站立'));
    elStatus.innerHTML =
      '位置　' + player.pos.x.toFixed(1) + ' , ' + player.pos.y.toFixed(2) + ' , ' + player.pos.z.toFixed(1) +
      '<br>速度　' + Math.hypot(player.vel.x, player.vel.z).toFixed(1) + ' m/s　·　状态 ' + state +
      '<br>碰撞体　' + colliders.length + ' 个　·　开发者模式 ' + (devEnabled ? '开 (F1)' : '关 (F1)') +
      '<br>网格　' + meshCount + '　·　三角面 ' + Math.round(triCount).toLocaleString() +
      '<br>FPS　' + Math.round(fps);
  }

  /* ================= 复位 / 主循环 ================= */
  function respawn() {
    player.pos.set(spawnPos[0], spawnPos[1], spawnPos[2]);
    player.vel.set(0, 0, 0);
    player.heading = Math.PI;
    player.height = CFG.standHeight;
    player.crouch = 0;
    camYaw = Math.PI;
    camPitch = 0.22;
    camDist = CFG.camDistance;
    camInit = false;
    character.position.copy(player.pos);
    character.rotation.y = player.heading;
    updateHud(true);
  }

  var clock = new THREE.Clock();
  var renderedOnce = false;

  function tick() {
    global.requestAnimationFrame(tick);
    var dt = Math.min(0.05, clock.getDelta());

    fps = fps * 0.92 + (dt > 0 ? 1 / dt : 60) * 0.08;

    updateLift(dt);
    updatePlayer(dt);
    updateCamera(dt);

    if (devEnabled) updatePlayerHelper();

    hudTimer += dt;
    if (hudTimer > 0.15) {
      hudTimer = 0;
      updateHud();
    }

    renderer.render(scene, camera);
    if (!renderedOnce) {
      renderedOnce = true;
      global.__READY = true;
    }
  }

  global.addEventListener('resize', function () {
    camera.aspect = global.innerWidth / global.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(global.innerWidth, global.innerHeight);
  });

  /* ================= 启动 ================= */
  if (problems.length) {
    console.warn('[scene] 以下对象未载入：\n' + problems.join('\n'));
  }

  updateHud(true);
  if (elLoading) {
    elLoading.textContent = problems.length ? '部分对象未载入（详见控制台）' : '已进入场景';
    setTimeout(function () {
      elLoading.style.opacity = '0';
      setTimeout(function () { elLoading.style.display = 'none'; }, 450);
    }, 550);
  }

  // 调试句柄：便于在控制台查看碰撞体与玩家状态
  global.__GAME = {
    scene: scene,
    camera: camera,
    player: player,
    keys: keys,
    lift: liftState,
    elevator: elevator,
    colliders: colliders,
    walkables: walkables,
    toggleDev: toggleDev,
    respawn: respawn,
    problems: problems,
    setCamera: function (yaw, pitch, dist) {
      if (typeof yaw === 'number') camYaw = yaw;
      if (typeof pitch === 'number') camPitch = pitch;
      if (typeof dist === 'number') camDist = dist;
      camInit = false;
    },
    // 固定步长推进一帧（不含渲染），便于调试与自动化测试
    step: function (dt) {
      var d = dt || 1 / 60;
      updateLift(d);
      updatePlayer(d);
      updateCamera(d);
      updatePlayerHelper();
    }
  };

  tick();
})(window);
