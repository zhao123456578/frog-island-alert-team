/* ============================================================
 * district-layout.js — 云栖里住区：布局数据（高密度城镇社区版）
 * 加载顺序：three → building → environment → interior → player
 *           → district-models → 本文件 → district-main
 * 约定：1 单位 = 1 米；Y 轴向上；position 为物件原点（多数在脚下）
 *
 * 规划（俯视，-Z 为北）：
 *   场地      X -95..90, Z -95..96，西北角切角
 *   城市道路  东侧 X 94..106 / 南侧 Z 101..113
 *   东区      X -4..86，两列板楼 + 6m 中央巷道，行距 20m（净距 5m）
 *             板楼 42×15 / 20×15、点式 18×18、联排 9.2×10、层数 3~8F
 *   西南 A 区  两栋板楼拼 L + 临街商铺
 *   西北 F 区  斜置板楼 + 湖滨联排
 *   D 栋      东区中部 —— 唯一可进入（原主楼 + 8F 室内 + 玻璃电梯）
 *   中心湖面   西侧有机水面 + 三座湖心岛 + 圆形亲水平台
 * ============================================================ */
(function (global) {
  'use strict';

  var G = global.GameModels;
  var objects = [];
  var serial = 0;

  function put(o) { objects.push(o); }
  function collideAABB(size, offset) { return { type: 'aabb', size: size, offset: offset || [0, 0, 0] }; }

  /* ============================================================
   * 通用住宅：板楼 / 点式（同一 Apartment 模型，参数不同）
   * ============================================================ */
  function block(id, x, z, w, d, floors, rot, label) {
    var h = floors * 3.0 + 0.5;
    var no = ++serial;
    put({
      id: id, model: 'Apartment',
      position: [x, 0, z], rotation: [0, rot || 0, 0], scale: [1, 1, 1],
      options: { width: w, depth: d, floors: floors },
      collision: collideAABB([w, h, d], [0, h / 2, 0]),
      plan: { label: label || null, kind: 'slab', no: no }
    });
  }

  // 联排住宅（3 层坡屋顶）
  var TH_PALETTE = [
    { wall: 0xe8dfcd, roof: 0xa4614a, trim: 0x6b5b4b },
    { wall: 0xd9d4c8, roof: 0x5d666c, trim: 0x4f565c },
    { wall: 0xe3d0b0, roof: 0x9a5f44, trim: 0x7a6250 },
    { wall: 0xd2dcc9, roof: 0x5c6b5f, trim: 0x4a544c },
    { wall: 0xcfdae0, roof: 0x53626e, trim: 0x44515a },
    { wall: 0xe6d3c6, roof: 0x8c5a44, trim: 0x6a4f42 }
  ];

  function townhouse(id, x, z, rot, idx, label) {
    var p = TH_PALETTE[idx % TH_PALETTE.length];
    var no = ++serial;
    put({
      id: id, model: 'Townhouse',
      position: [x, 0, z], rotation: [0, rot || 0, 0], scale: [1, 1, 1],
      options: {
        width: 9.2, depth: 10, floors: 3,
        wall: p.wall, roofColor: p.roof, trim: p.trim,
        roof: idx % 4 === 2 ? 'hip' : 'gable',
        balcony: idx % 3 !== 1, chimney: idx % 2 === 0
      },
      collision: collideAABB([9.4, 12.6, 10.4], [0, 6.3, 0]),
      plan: { label: label || null, kind: 'house', no: no }
    });
  }

  // 一排联排（沿 X 排布，正面朝 +Z，rot 可整体转向）
  function terrace(prefix, x0, z, count, rot, flip) {
    for (var i = 0; i < count; i++) {
      var x = x0 + i * 9.8;
      townhouse(prefix + '-' + i, x, z, rot || 0, i + (flip ? 3 : 0), i === 0 ? prefix : null);
    }
  }

  /* ============================================================
   * 0. 场地底板
   * ============================================================ */
  put({ id: 'ground', model: 'Ground', position: [0, 0, 0], rotation: [0, 0, 0], scale: [1, 1, 1],
    options: { width: 240, depth: 230, color: 0x94a281 }, collision: { type: 'none' } });

  /* ============================================================
   * 1. 城市道路 + 人行道 + 斑马线
   * ============================================================ */
  put({ id: 'road-east', model: 'Road', position: [100, 0, 0], rotation: [0, Math.PI / 2, 0], scale: [1, 1, 1],
    options: { length: 230, width: 12 }, collision: { type: 'none' } });
  put({ id: 'road-south', model: 'Road', position: [0, 0, 107], rotation: [0, 0, 0], scale: [1, 1, 1],
    options: { length: 240, width: 12 }, collision: { type: 'none' } });

  put({ id: 'walk-east', model: 'Sidewalk', position: [92, 0, 0], rotation: [0, Math.PI / 2, 0], scale: [1, 1, 1],
    options: { length: 230, width: 4 }, collision: { type: 'none' } });
  put({ id: 'walk-south', model: 'Sidewalk', position: [-4, 0, 99], rotation: [0, 0, 0], scale: [1, 1, 1],
    options: { length: 232, width: 4 }, collision: { type: 'none' } });

  put({ id: 'crosswalk-east', model: 'Crosswalk', position: [100, 0, 44], rotation: [0, Math.PI / 2, 0], scale: [1, 1, 1],
    options: { width: 6, depth: 12 }, collision: { type: 'none' } });
  put({ id: 'crosswalk-south', model: 'Crosswalk', position: [34, 0, 107], rotation: [0, 0, 0], scale: [1, 1, 1],
    options: { width: 7, depth: 12 }, collision: { type: 'none' } });

  /* ============================================================
   * 2. 铺装 / 巷道路面
   * ============================================================ */
  put({ id: 'pave-east', model: 'Plaza', position: [41, 0, 0], rotation: [0, 0, 0], scale: [1, 1, 1],
    options: { width: 94, depth: 184, height: 0.05, pattern: 'grid', color: 0xc9c4b4, joint: 0xb3ae9d, border: false },
    collision: { type: 'none' } });
  put({ id: 'pave-sw', model: 'Plaza', position: [-57, 0, 65.5], rotation: [0, 0, 0], scale: [1, 1, 1],
    options: { width: 74, depth: 57, height: 0.07, pattern: 'grid', color: 0xc5c0b0, joint: 0xaea997, border: false },
    collision: { type: 'none' } });
  put({ id: 'pave-f', model: 'Plaza', position: [-38, 0, -52], rotation: [0, 0.62, 0], scale: [1, 1, 1],
    options: { width: 62, depth: 30, height: 0.045, pattern: 'grid', color: 0xc9c4b4, joint: 0xb3ae9d, border: false },
    collision: { type: 'none' } });

  // 斜向巷道（走向随建筑错位，不设贯通直街）
  [
    ['lane-1', 40, -58, 5, 34, 9],
    ['lane-2', 44, -14, 5, 30, -14],
    ['lane-3', 40, 22, 5, 24, 18],
    ['lane-4', 38, 66, 5, 26, -11],
    ['lane-5', 68, -52, 4, 26, 24]
  ].forEach(function (l) {
    put({ id: l[0], model: 'Plaza', position: [l[1], 0, l[2]], rotation: [0, l[5] * Math.PI / 180, 0], scale: [1, 1, 1],
      options: { width: l[3], depth: l[4], height: 0.09, pattern: 'plain', color: 0xcdbfa6, border: false },
      collision: { type: 'none' } });
  });

  // 湖畔步道 + 连接段
  put({ id: 'path-lake', model: 'Plaza', position: [-3, 0, 12], rotation: [0, 0, 0], scale: [1, 1, 1],
    options: { width: 4.5, depth: 56, height: 0.1, pattern: 'plain', color: 0xd6cdb8, border: false },
    collision: { type: 'none' }, plan: { label: '湖岸步道', kind: 'path' } });
  put({ id: 'path-link', model: 'Plaza', position: [12, 0, 75], rotation: [0, 0, 0], scale: [1, 1, 1],
    options: { width: 62, depth: 3.6, height: 0.1, pattern: 'plain', color: 0xd6cdb8, border: false },
    collision: { type: 'none' } });

  /* ============================================================
   * 3. 东区住宅（两列 × 六排，净距 5m，楼型混合）
   * ============================================================ */
  // 北组团：错位 + 小角度转角，围出不方正的小院
  block('n1', 10, -86, 28, 14, 6, 0);
  block('n2', 36, -78, 16, 15, 5, -0.32);
  block('n3', 10, -68, 22, 14, 7, 0.21);
  block('n4', 30, -48, 24, 15, 6, 0.09);

  // 东北组团：长短咬合，留斜缝
  block('n6', 64, -85, 32, 14, 6, 0);
  block('n7', 82, -70, 12, 16, 5, 0);
  block('n8', 58, -64, 20, 16, 8, 0.17);
  block('n9', 72, -44, 22, 14, 6, -0.14);

  // 中部组团：围合三角院
  block('n10', 14, -24, 26, 16, 6, 0);
  block('n11', 8, -6, 16, 14, 5, -0.24);
  block('n12', 32, -6, 20, 14, 7, 0.14);
  block('n13', 14, 14, 28, 14, 8, 0);
  block('n14', 66, -24, 30, 14, 6, 0);
  block('n16', 78, 4, 16, 16, 7, -0.17);
  block('n17', 66, 20, 26, 14, 6, 0);

  // 南组团：向停车带方向错动
  block('n18', 16, 54, 32, 14, 6, 0);
  block('n19', 10, 72, 16, 16, 5, 0.21);
  block('n20', 34, 76, 18, 14, 7, -0.14);
  block('n21', 62, 64, 26, 14, 6, 0);
  block('n22', 84, 68, 10, 12, 5, 0);

  // 联排两组，塞进组团缝隙
  terrace('th1', 50, -4, 2, 0, 0);
  terrace('th3', 2, -44, 2, 0, 1);

  // 东区南侧：D 栋前场
  put({
    id: 'mainBuilding', model: 'Building',
    position: [65, 0, 42], rotation: [0, 0, 0], scale: [1, 1, 1],
    options: { openings: G.Interior.OPENINGS, lobbyVoid: G.Interior.STAIR_VOID },
    collision: {
      type: 'aabbs',
      boxes: [
        { size: [13.6, 6.43, 0.6], offset: [-9.4, 3.215, 10.9] },
        { size: [13.6, 6.43, 0.6], offset: [9.4, 3.215, 10.9] },
        { size: [5.2, 2.68, 0.6], offset: [0, 5.09, 10.9] },
        { size: [32.4, 6.43, 0.6], offset: [0, 3.215, -10.9] },
        { size: [0.6, 6.43, 21.2], offset: [-15.9, 3.215, 0] },
        { size: [0.6, 6.43, 21.2], offset: [15.9, 3.215, 0] },
        { size: [30, 38.57, 0.6], offset: [0, 25.715, 9.7] },
        { size: [30, 38.57, 0.6], offset: [0, 25.715, -9.7] },
        { size: [0.6, 38.57, 18.8], offset: [14.7, 25.715, 0] },
        { size: [0.6, 16.07, 18.8], offset: [-14.7, 14.465, 0] },
        { size: [0.6, 20.3, 18.8], offset: [-14.7, 34.85, 0] },
        { size: [0.6, 2.2, 2.9], offset: [-14.7, 23.6, -7.95] },
        { size: [0.6, 2.2, 13.9], offset: [-14.7, 23.6, 2.45] },
        { size: [30, 0.8, 20], offset: [0, 45.2, 0] }
      ]
    },
    plan: { label: 'D 栋', kind: 'tower', no: ++serial }
  });
  put({ id: 'interior', model: 'Interior', position: [65, 0, 42], rotation: [0, 0, 0], scale: [1, 1, 1],
    collision: { type: 'none' } });

  put({ id: 'sign-d', model: 'Signboard', position: [77.5, 0.07, 57], rotation: [0, -0.3, 0], scale: [1.1, 1.1, 1.1],
    collision: { type: 'none' }, plan: { label: 'D 栋入口', kind: 'facility' } });
  put({ id: 'bench-d1', model: 'Bench', position: [55.5, 0.07, 58], rotation: [0, Math.PI, 0], scale: [1, 1, 1],
    collision: collideAABB([2.1, 0.95, 0.6], [0, 0.475, 0]) });
  put({ id: 'bench-d2', model: 'Bench', position: [73, 0.07, 58], rotation: [0, Math.PI, 0], scale: [1, 1, 1],
    collision: collideAABB([2.1, 0.95, 0.6], [0, 0.475, 0]) });

  /* ============================================================
   * 4. 西南 A 区 + 临街商铺
   * ============================================================ */
  block('a1', -70, 84, 46, 15, 6, 0, 'A 区');
  block('a2', -64, 62, 46, 15, 6, Math.PI / 2);

  put({ id: 'shops', model: 'ShopRow', position: [-30, 0, 88], rotation: [0, 0, 0], scale: [1, 1, 1],
    options: { width: 20, depth: 12, units: 3 },
    collision: collideAABB([20, 10, 12.4], [0, 5, 0]), plan: { label: '邻里商铺', kind: 'shop' } });

  put({ id: 'pool-small', model: 'Pond', position: [-46, 0, 54], rotation: [0, 0, 0], scale: [0.68, 1, 0.68],
    options: { radius: 7 }, collision: collideAABB([10, 1.0, 10], [0, 0.5, 0]),
    plan: { label: '泳池', kind: 'water' } });

  // 西南小广场
  put({ id: 'plaza-a', model: 'Plaza', position: [-39, 0, 72], rotation: [0, 0, 0], scale: [1, 1, 1],
    options: { width: 16, depth: 22, height: 0.1, pattern: 'grid', color: 0xd2c9b6, border: false },
    collision: { type: 'none' } });

  /* ============================================================
   * 5. 西北 F 区（斜置板楼 + 湖滨联排）
   * ============================================================ */
  block('f1', -38, -52, 46, 15, 6, 0.62, 'F 区');
  townhouse('th2-0', -78, -30, 0, 1);
  townhouse('th2-1', -68.2, -30, 0, 2);

  /* ============================================================
   * 6. 中心湖面 + 亲水圆台
   * ============================================================ */
  put({ id: 'lawn-park', model: 'Lawn', position: [-53, 0, 2], rotation: [0, 0, 0], scale: [1, 1, 1],
    options: { width: 94, depth: 74 }, collision: { type: 'none' } });
  put({ id: 'lagoon', model: 'Lagoon', position: [-29, 0, 8], rotation: [0, 0, 0], scale: [1, 1, 1],
    options: {
      islands: [{ x: -18, z: 2, r: 6 }, { x: -2, z: 14, r: 4.5 }, { x: -27, z: -9, r: 3.6 }]
    },
    collision: { type: 'aabbs', boxes: [
      { size: [32, 1.0, 24], offset: [-44, 0.5, 12] },
      { size: [26, 1.0, 22], offset: [-20, 0.5, 22] },
      { size: [24, 1.0, 18], offset: [-58, 0.5, -6] }
    ] },
    plan: { label: '中心湖面', kind: 'water' } });

  put({ id: 'round-deck', model: 'RoundDeck', position: [-2, 0, -4], rotation: [0, 0, 0], scale: [1, 1, 1],
    options: { radius: 6.5 }, collision: collideAABB([13.5, 0.4, 13.5], [0, 0.2, 0]),
    plan: { label: '亲水圆台', kind: 'deck' } });

  // 湖心岛乔木（岛面标高 0.24）
  [[-47, 0.24, 10], [-31, 0.24, 22], [-56, 0.24, -1]].forEach(function (t, i) {
    put({ id: 'tree-island-' + i, model: 'Tree', position: [t[0], t[1], t[2]], rotation: [0, i * 1.7, 0],
      scale: [0.8, 0.85, 0.8], collision: collideAABB([1.0, 2.2, 1.0], [0, 1.1, 0]) });
  });

  /* ============================================================
   * 7. 停车带 + 车棚
   * ============================================================ */
  put({ id: 'parking-south', model: 'ParkingLot', position: [65, 0, 84], rotation: [0, 0, 0], scale: [1, 1, 1],
    options: { width: 40, depth: 9, stalls: 8 }, collision: { type: 'none' },
    plan: { label: '停车带', kind: 'parking' } });
  put({ id: 'carport', model: 'Carport', position: [65, 0, 84], rotation: [0, 0, 0], scale: [1, 1, 1],
    options: { width: 40, depth: 9, height: 3.0 }, collision: { type: 'none' } });

  var CAR_COLORS = [0xb9c0c4, 0x8f9aa3, 0x3f4a52, 0xa8543c, 0x4f6c78, 0xd8d3c6, 0x6b7a6a, 0xcfc6b4];
  for (var ci = 0; ci < 7; ci++) {
    put({ id: 'car-' + ci, model: 'Car', position: [48.5 + ci * 4.7, 0.14, 83.4], rotation: [0, Math.PI, 0], scale: [1, 1, 1],
      options: { color: CAR_COLORS[ci % CAR_COLORS.length] }, collision: collideAABB([1.9, 1.6, 4.2], [0, 0.8, 0]) });
  }

  /* ============================================================
   * 8. 草坪 / 绿篱 / 边界
   * ============================================================ */
  put({ id: 'lawn-east', model: 'Lawn', position: [88, 0, 0], rotation: [0, 0, 0], scale: [1, 1, 1],
    options: { width: 4, depth: 184 }, collision: { type: 'none' } });
  put({ id: 'lawn-west', model: 'Lawn', position: [-92.5, 0, 30], rotation: [0, 0, 0], scale: [1, 1, 1],
    options: { width: 5, depth: 120 }, collision: { type: 'none' } });

  // 南侧绿化带
  put({ id: 'lawn-south', model: 'Lawn', position: [32, 0, 92.5], rotation: [0, 0, 0], scale: [1, 1, 1],
    options: { width: 96, depth: 6 }, collision: { type: 'none' } });

  // 不规则小绿块（塞在建筑缝隙里，方向随组团）
  [
    ['green-1', 44, -36, 8, 10, 0],
    ['green-2', 44, 10, 6, 12, 0],
    ['green-3', 24, 40, 8, 8, 25],
    ['green-4', 44, 44, 6, 8, -10],
    ['green-5', 22, 62, 7, 7, 18]
  ].forEach(function (g) {
    put({ id: g[0], model: 'Lawn', position: [g[1], 0, g[2]], rotation: [0, g[5] * Math.PI / 180, 0], scale: [1, 1, 1],
      options: { width: g[3], depth: g[4], height: 0.12, stripes: true }, collision: { type: 'none' } });
  });

  put({ id: 'hedge-chamfer', model: 'Hedge', position: [-60, 0.08, -60], rotation: [0, -Math.PI / 4, 0], scale: [1, 1, 1],
    options: { length: 94, height: 1.2, thickness: 1.2 }, collision: collideAABB([66, 1.4, 1.2], [0, 0.7, 0]) });
  put({ id: 'lawn-court', model: 'Lawn', position: [-14, 0, 58], rotation: [0, 0, 0], scale: [1, 1, 1],
    options: { width: 18, depth: 14, stripes: true }, collision: { type: 'none' },
    plan: { label: '庭院绿地', kind: 'lawn' } });
  [[-20, 54], [-8, 54], [-20, 64], [-8, 64]].forEach(function (t, i) {
    put({ id: 'tree-court-' + i, model: 'Tree', position: [t[0], 0.12, t[1]], rotation: [0, i * 1.5, 0],
      scale: [0.8, 0.85, 0.8], collision: collideAABB([1.0, 2.2, 1.0], [0, 1.1, 0]) });
  });

  put({ id: 'hedge-parking', model: 'Hedge', position: [65, 0.08, 89], rotation: [0, 0, 0], scale: [1, 1, 1],
    options: { length: 40, height: 0.8, thickness: 0.8 }, collision: collideAABB([40, 1.0, 0.8], [0, 0.5, 0]) });

  [
    ['hedge-n', 31.5, -94.2, 0, 113],
    ['hedge-w', -94.2, 35, Math.PI / 2, 120],
    ['hedge-e', 89.2, 0.5, Math.PI / 2, 191],
    ['hedge-s1', -55.5, 95.2, 0, 79],
    ['hedge-s2', 65, 95.2, 0, 50]
  ].forEach(function (h) {
    put({ id: h[0], model: 'Hedge', position: [h[1], 0.08, h[2]], rotation: [0, h[3], 0], scale: [1, 1, 1],
      options: { length: h[4], height: 1.25, thickness: 1.0 }, collision: collideAABB([h[4], 1.45, 1.0], [0, 0.72, 0]) });
  });

  /* ============================================================
   * 9. 乔木（边界 + 湖岸 + 巷道）
   * ============================================================ */
  var TREES = [
    // 西边界
    [-92, -72, 1.1], [-92, -52, 0.95], [-92, -32, 1.05], [-92, -12, 1.0], [-92, 8, 1.1], [-92, 28, 0.95],
    [-92, 48, 1.05], [-92, 68, 1.0], [-92, 76, 1.1],
    // 南边界（避开商铺）
    [-88, 93, 1.05], [-74, 93, 0.95], [82, 93, 1.1],
    // 湖岸
    [-88, 12, 1.15], [-84, -6, 1.0], [-86, 32, 1.05], [-58, -24, 1.05], [-32, -24, 0.95],
    [-14, 38, 1.05], [-24, 42, 0.95], [-4, 30, 1.0], [-46, 40, 1.0], [-70, 34, 1.0],
    // 西北三角地
    [-78, -38, 1.05], [-84, -22, 1.0],
    // 东侧绿带外侧
    [88.5, -80, 0.85], [88.5, -50, 0.85], [88.5, -20, 0.85], [88.5, 10, 0.85], [88.5, 40, 0.85], [88.5, 54, 0.85],
    [0, 92.5, 0.9], [22, 92.5, 0.9], [46, 92.5, 0.9], [70, 92.5, 0.9]
  ];
  TREES.forEach(function (t, i) {
    put({ id: 'tree-' + i, model: 'Tree', position: [t[0], 0.07, t[1]], rotation: [0, i * 1.13, 0],
      scale: [t[2], t[2] * 1.05, t[2]], collision: collideAABB([1.2, 2.6, 1.2], [0, 1.3, 0]) });
  });

  /* ============================================================
   * 10. 街具 / 小品
   * ============================================================ */
  [[40, -62], [44, -28], [40, 8], [42, 34], [38, 52], [46.5, 74], [-4, 26], [-4, 46], [24, 66], [-50, 66]]
    .forEach(function (l, i) {
      put({ id: 'lamp-' + i, model: 'StreetLamp', position: [l[0], 0.09, l[1]], rotation: [0, i * 0.9, 0], scale: [0.9, 0.9, 0.9],
        collision: collideAABB([0.5, 7, 0.5], [0, 3.5, 0]) });
    });

  [[41, -30, Math.PI / 2], [41, -4, Math.PI / 2], [41, 34, Math.PI / 2], [-4, 16, -Math.PI / 2],
   [-4, 36, -Math.PI / 2], [-4, 50, -Math.PI / 2], [30, 66, 0], [-30, 66, 0]].forEach(function (b, i) {
    put({ id: 'bench-' + i, model: 'Bench', position: [b[0], 0.09, b[1]], rotation: [0, b[2], 0], scale: [1, 1, 1],
      collision: collideAABB([2.1, 0.95, 0.6], [0, 0.475, 0]) });
  });

  [[41, 12], [41, 48], [-10, 66], [30, 66], [70, 58]].forEach(function (b, i) {
    put({ id: 'bin-' + i, model: 'TrashBin', position: [b[0], 0.09, b[1]], rotation: [0, 0.3, 0], scale: [1, 1, 1],
      collision: { type: 'none' } });
  });

  put({ id: 'pavilion-park', model: 'Pavilion', position: [-8, 0, 42], rotation: [0, 0.3, 0], scale: [1, 1, 1],
    options: { radius: 3.0 }, collision: collideAABB([6, 3.6, 6], [0, 1.8, 0]),
    plan: { label: '凉亭', kind: 'pavilion' } });

  put({ id: 'gate-south', model: 'CommunityGate', position: [34, 0, 98], rotation: [0, Math.PI / 2, 0], scale: [0.8, 0.8, 0.8],
    options: { width: 10 }, collision: { type: 'aabbs', boxes: [
      { size: [0.9, 4.2, 0.9], offset: [0, 1.9, -3.7] },
      { size: [0.9, 4.2, 0.9], offset: [0, 1.9, 3.7] }
    ] }, plan: { label: '南入口', kind: 'gate' } });

  put({ id: 'bus-stop', model: 'BusStop', position: [92, 0.18, 20], rotation: [0, -Math.PI / 2, 0], scale: [1, 1, 1],
    collision: collideAABB([2, 2.8, 5.2], [0, 1.4, 0]), plan: { label: '公交站', kind: 'facility' } });

  /* ============================================================
   * 11. 平面图分区（仅制图用）
   * ============================================================ */
  var zones = [
    { id: 'z-site', name: '住区用地', kind: 'site', polygon: [[-95, -25], [-25, -95], [90, -95], [90, 96], [-95, 96]] },
    { id: 'z-park', name: '中心水景公园', kind: 'park', x0: -95, x1: -8, z0: -25, z1: 52 }
  ];

  global.SCENE_LAYOUT = {
    name: '云栖里住区',
    units: 'meter',
    up: 'y',
    bounds: { size: [228, 218] },
    // 出生点：D 栋入口前，正对主楼
    spawn: { position: [65, 0.07, 68], rotation: [0, Math.PI, 0] },
    objects: objects,
    zones: zones,
    shots: {
      hero: { pos: [130, 175, 195], target: [0, 0, 10], fov: 38 },
      aerial: { pos: [-158, 128, 168], target: [6, 0, 8], fov: 42 },
      street: { pos: [96, 42, 90], target: [22, 0, 34], fov: 45 },
      park: { pos: [6, 3.0, 44], target: [-50, 2.0, 8], fov: 55 },
      axis: { pos: [65, 46, 124], target: [65, 24, 42], fov: 40 },
      top: { pos: [0, 320, 0.01], target: [0, 0, 0], fov: 40 }
    }
  };
})(window);
