const path = require('path');
const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch({ channel: 'chrome', args: ['--no-sandbox', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
  const page = await browser.newPage({ viewport: { width: 700, height: 500 } });
  page.on('pageerror', (e) => console.log('[pageerror]', e.message));
  await page.goto('file:///' + path.resolve(__dirname, '..', 'index.html').replace(/\\/g, '/'));
  await page.waitForFunction(() => window.__READY === true, { timeout: 90000 });
  const out = await page.evaluate(() => {
    const cs = __GAME.colliders;
    const res = [];
    for (let i = 0; i < cs.length; i++) {
      for (let j = i + 1; j < cs.length; j++) {
        const a = cs[i].box, b = cs[j].box;
        if (!a.intersectsBox(b)) continue;
        const ox = Math.min(a.max.x, b.max.x) - Math.max(a.min.x, b.min.x);
        const oz = Math.min(a.max.z, b.max.z) - Math.max(a.min.z, b.min.z);
        const oy = Math.min(a.max.y, b.max.y) - Math.max(a.min.y, b.min.y);
        if (ox > 0.4 && oz > 0.4 && oy > 1.0) {
          res.push([cs[i].id, cs[j].id, +ox.toFixed(1), +oz.toFixed(1)]);
        }
      }
    }
    return res;
  });
  console.log(JSON.stringify(out, null, 1));
  console.log('count', out.length);
  await browser.close();
})();
