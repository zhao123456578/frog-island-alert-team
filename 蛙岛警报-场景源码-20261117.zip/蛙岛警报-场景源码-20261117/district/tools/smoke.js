/* 交互冒烟测试：出生点、前进、住宅碰撞、电梯上下楼 */
const path = require('path');
const { chromium } = require('playwright');

(async () => {
  const browser = await chromium.launch({ channel: 'chrome', args: ['--no-sandbox', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
  const page = await browser.newPage({ viewport: { width: 1000, height: 640 } });
  page.on('pageerror', (e) => console.log('[pageerror]', e.message));
  await page.goto('file:///' + path.resolve(__dirname, '..', 'index.html').replace(/\\/g, '/'));
  await page.waitForFunction(() => window.__READY === true, { timeout: 90000 });
  await page.waitForTimeout(500);

  console.log('init', await page.evaluate(() => ({
    problems: __GAME.problems,
    colliders: __GAME.colliders.length,
    spawn: [__GAME.player.pos.x, +__GAME.player.pos.y.toFixed(2), __GAME.player.pos.z]
  })));

  // 从街道向北穿过牌坊（用固定步长推进，避免无头渲染过慢）
  await page.keyboard.down('KeyW');
  await page.evaluate(() => { for (let i = 0; i < 120; i++) __GAME.step(0.05); });
  await page.keyboard.up('KeyW');
  console.log('walk 6s', await page.evaluate(() => [
    +__GAME.player.pos.x.toFixed(2), +__GAME.player.pos.y.toFixed(2), +__GAME.player.pos.z.toFixed(2)
  ]));

  // 撞 B 排住宅后墙
  await page.evaluate(() => {
    __GAME.player.pos.set(17, 0.02, 52);
    __GAME.player.vel.set(0, 0, 0);
    __GAME.setCamera(Math.PI, 0.2, 4.6);
    __GAME.keys.KeyS = true;
    for (let i = 0; i < 90; i++) __GAME.step(0.05);
    __GAME.keys.KeyS = false;
  });
  console.log('hit house back (expect z≈74.04, not <73.5)', await page.evaluate(() => [
    +__GAME.player.pos.x.toFixed(2), +__GAME.player.pos.z.toFixed(2)
  ]));

  // 电梯：轿厢内按 E 开门 → 再按 E 上行
  await page.evaluate(() => {
    __GAME.player.pos.set(47.6, 0.02, 36.5);
    __GAME.player.vel.set(0, 0, 0);
    for (let i = 0; i < 30; i++) __GAME.step(0.05);
  });
  await page.keyboard.press('KeyE');
  await page.evaluate(() => { for (let i = 0; i < 50; i++) __GAME.step(0.05); });
  const d1 = await page.evaluate(() => ({ doors: +__GAME.lift.doors.toFixed(2), floor: __GAME.lift.floor }));
  await page.keyboard.press('KeyE');
  await page.evaluate(() => { for (let i = 0; i < 360; i++) __GAME.step(0.05); });
  console.log('lift', JSON.stringify(d1), await page.evaluate(() => ({
    y: +__GAME.lift.y.toFixed(2), floor: __GAME.lift.floor, moving: __GAME.lift.moving,
    player: [ +__GAME.player.pos.x.toFixed(2), +__GAME.player.pos.y.toFixed(2), +__GAME.player.pos.z.toFixed(2) ]
  })));

  // 8F 出门进房间
  await page.evaluate(() => {
    __GAME.player.pos.set(51.2, 22.5, 36.5);
    __GAME.player.vel.set(0, 0, 0);
    __GAME.setCamera(-Math.PI / 2, 0.15, 4);
    for (let i = 0; i < 20; i++) __GAME.step(0.05);
  });
  console.log('room', await page.evaluate(() => [
    +__GAME.player.pos.x.toFixed(2), +__GAME.player.pos.y.toFixed(2), +__GAME.player.pos.z.toFixed(2)
  ]));

  await browser.close();
})().catch((e) => { console.error(e); process.exit(1); });
