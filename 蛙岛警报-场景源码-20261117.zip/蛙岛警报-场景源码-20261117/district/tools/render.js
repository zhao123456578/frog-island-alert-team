/* ============================================================
 * render.js — 无头 Chromium 出图（效果图 / 平面图通用）
 * 用法：node render.js <shot> [width] [height] [scale]
 *   shot: hero | aerial | street | axis | plan
 * 依赖：playwright（通过 NODE_PATH 指向 npx 缓存）
 * ============================================================ */
const path = require('path');
const fs = require('fs');
const { chromium } = require('playwright');

const ROOT = path.resolve(__dirname, '..');
const OUT = path.join(ROOT, 'renders');
const shot = process.argv[2] || 'hero';
const W = parseInt(process.argv[3] || '1600', 10);
const H = parseInt(process.argv[4] || '1000', 10);
const SCALE = parseFloat(process.argv[5] || '1.5');

if (!fs.existsSync(OUT)) fs.mkdirSync(OUT, { recursive: true });

(async () => {
  const launchOpts = {
    channel: 'chrome',
    args: [
      '--use-angle=swiftshader',
      '--enable-unsafe-swiftshader',
      '--disable-gpu-sandbox',
      '--no-sandbox',
      '--hide-scrollbars'
    ]
  };
  let browser;
  try {
    browser = await chromium.launch(launchOpts);
  } catch (e) {
    console.log('[launch] channel chrome failed, fallback to executablePath');
    browser = await chromium.launch(Object.assign({}, launchOpts, {
      channel: undefined,
      executablePath: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe'
    }));
  }
  const page = await browser.newPage({
    viewport: { width: W, height: H },
    deviceScaleFactor: SCALE
  });

  const errors = [];
  page.on('console', (m) => {
    if (m.type() === 'error' || m.type() === 'warning') console.log('[console.' + m.type() + ']', m.text());
  });
  page.on('pageerror', (e) => { errors.push(e.message); console.log('[pageerror]', e.message); });

  const tone = process.env.TONE || '';
  const url = shot === 'plan'
    ? 'file:///' + path.join(ROOT, 'plan.html').replace(/\\/g, '/')
    : 'file:///' + path.join(ROOT, 'index.html').replace(/\\/g, '/') + '?shot=' + shot + (tone ? '&tone=' + tone : '');

  await page.goto(url, { waitUntil: 'load', timeout: 60000 });
  await page.waitForFunction(() => window.__READY === true, { timeout: 120000 });
  await page.waitForTimeout(1600);

  const info = await page.evaluate(() => {
    const g = window.__GAME || {};
    return {
      problems: g.problems || [],
      colliders: (g.colliders || []).length,
      status: (document.getElementById('hud-status') || {}).textContent || ''
    };
  });
  console.log('scene:', JSON.stringify(info, null, 2));

  const file = path.join(OUT, 'district-' + shot + (tone ? '-' + tone : '') + '.png');
  await page.screenshot({ path: file, type: 'png' });
  console.log('saved:', file, W * SCALE + '×' + H * SCALE);
  if (errors.length) console.log('page errors:', errors);
  await browser.close();
})().catch((e) => { console.error(e); process.exit(1); });
