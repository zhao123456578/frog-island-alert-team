# 蛙岛警报 · 场景版源码

Three.js 场景版蛙岛警报的完整源码。**无需构建、无需联网**，解压后双击 HTML 即可离线运行。

## 目录结构

```
蛙岛警报-场景源码-20261117/
├── index.html          场景入口（外壳 + HUD：坐标/速度/状态/三角面/FPS）
├── main.js             第三人称控制器：移动、相机避障、碰撞解析、电梯状态机
├── building.js         主楼模型（30×20×45m，裙楼 + 塔楼 + 实例化窗格 + 屋顶设备）
├── interior.js         楼内空间：8F 住宅、门厅、剪刀楼梯、室外玻璃电梯
├── environment.js      13 类环境物件（道路、人行道、斑马线、路灯、行道树、长椅、栏杆…）
├── scene-layout.js     场景布局：52 个对象的位置/旋转/缩放与碰撞体、出生点
├── player.js           低多边形角色模型与关节（userData.parts）
├── three.min.js        Three.js r149（UMD，本地存放）
├── district/           云栖里住区街区
│   ├── index.html      街区漫游入口
│   ├── district-layout.js   185×191m 街区布局，30 栋住宅 + 湖面 + 公园 + 球场 + 停车场
│   ├── district-models.js   住宅、商业、绿化、水景等 23 类模型
│   ├── district-main.js     街区版主程序（远裁剪/雾/渐变天穹，?shot= 固定机位出图）
│   ├── plan.html + plan.js  Canvas 2D 总平面图（道路、建筑编号、图例、比例尺、指北针）
│   ├── renders/        6 张效果图：hero / street / park / axis / plan / play
│   └── tools/          Playwright 出图与校验脚本（render / smoke / play-shot / check-overlap）
└── .workbuddy/memory/  开发过程记录（各轮迭代的设计决策与踩坑记录）
```

## 运行

| 入口 | 说明 |
| --- | --- |
| `index.html` | 主楼场景（双击即可） |
| `district/index.html` | 云栖里住区街区漫游 |

### 操作

| 键位 | 功能 |
| --- | --- |
| W A S D | 移动（相对相机） |
| Space | 跳跃 |
| C | 下蹲 |
| Shift | 奔跑 |
| 鼠标拖动 / 点击锁定 | 转视角（Esc 释放） |
| 滚轮 | 拉远拉近 |
| E | 电梯交互（叫梯 / 选层） |
| R | 回到出生点 |
| F1 | 开发者模式（碰撞体、FPS、三角面） |

## 技术约定

- 传统 `<script>` 全局脚本（非 ES Module），Three.js r149 UMD 本地存放，**无任何外部资源请求**
- 坐标基准：1 单位 = 1 米；物件原点在自身脚下；住宅正面朝 +Z
- 场景规模：主楼约 1.8 万三角面 / 86 碰撞体；街区约 10.4 万三角面 / 196 碰撞体
- 碰撞方案：布局 `collision.aabb` / `aabbs` + 模型自带 `userData.colliders`，分轴推出 + 台阶抬脚
- 重复构件用 `InstancedMesh`（窗、楼层线、栏杆立柱、楼梯踏步），长方体统一用共享单位 BoxGeometry + 缩放
- `district/tools/` 依赖 Playwright + 无头 Chrome，仅用于出图与自动化校验，运行 Demo 不需要
