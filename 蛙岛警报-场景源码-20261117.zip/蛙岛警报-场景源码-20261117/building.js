/* ============================================================
 * building.js — 程序化大楼（低多边形 / 纯几何体 / 无外部资源）
 * 依赖：全局 THREE（传统 <script> 标签，不使用 ES Module）
 * 注册：window.GameModels.Building(options) -> THREE.Group
 * 约定：1 单位 = 1 米；原点 = 建筑底面中心；Y 轴向上；底面在 Y = 0
 * 说明：只负责生成并返回 Group，不含玩家控制 / 主循环 / UI。
 * ============================================================ */
(function (global) {
  'use strict';

  var NS = global.GameModels = global.GameModels || {};

  /* ---------------- 参数默认值 ---------------- */
  var DEFAULTS = {
    width: 30,          // 塔楼宽（X）
    depth: 20,          // 塔楼进深（Z）
    height: 45,         // 总高
    floorHeight: 3.2,   // 目标层高（实际层高按总高均分）
    podiumFloors: 2,    // 裙楼层数（0 = 无裙楼）
    podiumOut: 1.2,     // 裙楼外扩尺寸
    curtainSide: 'front', // 玻璃幕墙所在立面：front / back / left / right / none
    curtainRatio: 0.42, // 幕墙占立面宽度比例
    stairTower: true,   // 背部室外消防楼梯
    colors: {
      wall: 0xd7d1c4,
      podium: 0xc2bbad,
      band: 0x596a76,
      mullion: 0x46525c,
      glass: 0x7d9fb4,
      curtain: 0x6d97b2,
      metal: 0x8b9299,
      roof: 0xb2b8bb,
      door: 0x2f3d47,
      accent: 0xc4562f
    }
  };

  /* ---------------- 本文件私有工具 ---------------- */
  var UNIT_BOX = null;
  var HELPER = null;

  function unitBox() {
    if (!UNIT_BOX) UNIT_BOX = new THREE.BoxGeometry(1, 1, 1);
    return UNIT_BOX;
  }

  function helper() {
    if (!HELPER) HELPER = new THREE.Object3D();
    return HELPER;
  }

  function num(v, fallback) {
    return (typeof v === 'number' && isFinite(v)) ? v : fallback;
  }

  function clamp(v, min, max) {
    return v < min ? min : (v > max ? max : v);
  }

  function merge(base, patch) {
    var out = {}, k;
    for (k in base) if (Object.prototype.hasOwnProperty.call(base, k)) out[k] = base[k];
    if (patch) for (k in patch) if (Object.prototype.hasOwnProperty.call(patch, k)) out[k] = patch[k];
    return out;
  }

  function solid(color, roughness, metalness, emissive, emissiveIntensity) {
    var m = new THREE.MeshStandardMaterial({
      color: color,
      roughness: roughness === undefined ? 0.92 : roughness,
      metalness: metalness === undefined ? 0.02 : metalness,
      flatShading: true
    });
    if (emissive !== undefined && emissive !== null) {
      m.emissive = new THREE.Color(emissive);
      m.emissiveIntensity = emissiveIntensity === undefined ? 1 : emissiveIntensity;
    }
    return m;
  }

  // 用单位立方体缩放生成长方体，几何体全局共享，减少内存与顶点
  function mesh(w, h, d, mat, x, y, z, name) {
    var m = new THREE.Mesh(unitBox(), mat);
    m.scale.set(w, h, d);
    m.position.set(x || 0, y || 0, z || 0);
    m.castShadow = true;
    m.receiveShadow = true;
    if (name) m.name = name;
    return m;
  }

  function cylinder(rTop, rBottom, h, seg, mat, x, y, z, name) {
    var m = new THREE.Mesh(new THREE.CylinderGeometry(rTop, rBottom, h, seg), mat);
    m.position.set(x || 0, y || 0, z || 0);
    m.castShadow = true;
    m.receiveShadow = true;
    if (name) m.name = name;
    return m;
  }

  // 合并同材质长方体为 InstancedMesh（窗、楼层线、栏杆、梯段等）
  function instanced(list, mat, name) {
    if (!list.length) return null;
    var m = new THREE.InstancedMesh(unitBox(), mat, list.length);
    var dummy = helper();
    for (var i = 0; i < list.length; i++) {
      var t = list[i];
      dummy.position.set(t.p[0], t.p[1], t.p[2]);
      dummy.rotation.set(t.r ? t.r[0] : 0, t.r ? t.r[1] : 0, t.r ? t.r[2] : 0);
      dummy.scale.set(t.s[0], t.s[1], t.s[2]);
      dummy.updateMatrix();
      m.setMatrixAt(i, dummy.matrix);
    }
    m.instanceMatrix.needsUpdate = true;
    m.castShadow = true;
    m.receiveShadow = true;
    if (name) m.name = name;
    return m;
  }

  function add(parent, child) {
    if (child) parent.add(child);
  }

  // 法线朝 Z 的墙（X-Y 面），带矩形洞：hole = { x0,x1,y0,y1 }
  function wallXY(parent, x0, x1, y0, y1, z, t, mat, hole, tag) {
    if (!hole) { add(parent, mesh(x1 - x0, y1 - y0, t, mat, (x0 + x1) / 2, (y0 + y1) / 2, z, tag)); return; }
    if (hole.y0 > y0 + 0.001) add(parent, mesh(x1 - x0, hole.y0 - y0, t, mat, (x0 + x1) / 2, (y0 + hole.y0) / 2, z, tag + '-bottom'));
    if (hole.y1 < y1 - 0.001) add(parent, mesh(x1 - x0, y1 - hole.y1, t, mat, (x0 + x1) / 2, (y1 + hole.y1) / 2, z, tag + '-top'));
    if (hole.x0 > x0 + 0.001) add(parent, mesh(hole.x0 - x0, hole.y1 - hole.y0, t, mat, (x0 + hole.x0) / 2, (hole.y0 + hole.y1) / 2, z, tag + '-left'));
    if (hole.x1 < x1 - 0.001) add(parent, mesh(x1 - hole.x1, hole.y1 - hole.y0, t, mat, (hole.x1 + x1) / 2, (hole.y0 + hole.y1) / 2, z, tag + '-right'));
  }

  // 法线朝 X 的墙（Z-Y 面），带矩形洞：hole = { z0,z1,y0,y1 }
  function wallYZ(parent, z0, z1, y0, y1, x, t, mat, hole, tag) {
    if (!hole) { add(parent, mesh(t, y1 - y0, z1 - z0, mat, x, (y0 + y1) / 2, (z0 + z1) / 2, tag)); return; }
    if (hole.y0 > y0 + 0.001) add(parent, mesh(t, hole.y0 - y0, z1 - z0, mat, x, (y0 + hole.y0) / 2, (z0 + z1) / 2, tag + '-bottom'));
    if (hole.y1 < y1 - 0.001) add(parent, mesh(t, y1 - hole.y1, z1 - z0, mat, x, (y1 + hole.y1) / 2, (z0 + z1) / 2, tag + '-top'));
    if (hole.z0 > z0 + 0.001) add(parent, mesh(t, hole.y1 - hole.y0, hole.z0 - z0, mat, x, (hole.y0 + hole.y1) / 2, (z0 + hole.z0) / 2, tag + '-back'));
    if (hole.z1 < z1 - 0.001) add(parent, mesh(t, hole.y1 - hole.y0, z1 - hole.z1, mat, x, (hole.y0 + hole.y1) / 2, (hole.z1 + z1) / 2, tag + '-front'));
  }

  /* ---------------- 注册：Building ---------------- */
  NS.Building = function (options) {
    if (!global.THREE) throw new Error('Building model failed: THREE is not loaded');

    try {
      var opt = options || {};
      var C = merge(DEFAULTS.colors, opt.colors);

      /* ---- 尺寸与层数 ---- */
      var W = Math.max(8, num(opt.width, DEFAULTS.width));
      var D = Math.max(8, num(opt.depth, DEFAULTS.depth));
      var H = Math.max(10, num(opt.height, DEFAULTS.height));
      var floors = Math.max(3, Math.round(H / Math.max(2.4, num(opt.floorHeight, DEFAULTS.floorHeight))));
      var fh = H / floors;

      var podiumFloors = clamp(Math.round(num(opt.podiumFloors, DEFAULTS.podiumFloors)), 0, floors - 1);
      var pOut = podiumFloors > 0 ? Math.max(0, num(opt.podiumOut, DEFAULTS.podiumOut)) : 0;
      var podiumH = podiumFloors * fh;
      var PW = W + pOut * 2;      // 裙楼宽
      var PD = D + pOut * 2;      // 裙楼进深
      var frontZ = PD / 2;        // 入口所在立面 Z

      /* ---- 材质 ---- */
      var mat = {
        wall: solid(C.wall, 0.94, 0.02),
        podium: solid(C.podium, 0.9, 0.02),
        band: solid(C.band, 0.7, 0.08),
        mullion: solid(C.mullion, 0.5, 0.45),
        glass: solid(C.glass, 0.18, 0.35, 0x0d1c26, 0.45),
        curtain: solid(C.curtain, 0.1, 0.5, 0x0d2130, 0.5),
        metal: solid(C.metal, 0.55, 0.45),
        roof: solid(C.roof, 0.9, 0.03),
        lobbyCeil: solid(0xd8d5cc, 0.95, 0.0, 0xd8d5cc, 0.22),
        door: solid(C.door, 0.35, 0.3, 0x0a1419, 0.3),
        accent: solid(C.accent, 0.75, 0.05)
      };

      var group = new THREE.Group();
      group.name = 'Building';

      /* ========== 1. 裙楼（门厅）+ 塔楼主体 ========== */
      if (podiumFloors > 0) {
        var PT = 0.6;
        var lobbyDoor = opt.lobbyDoor || { x0: -2.6, x1: 2.6, y0: 0, y1: 3.75 };

        // 裙楼改成 4 片外墙，内部是门厅（正面留出入口门洞）
        wallXY(group, -PW / 2, PW / 2, 0, podiumH, PD / 2 - PT / 2, PT, mat.podium, lobbyDoor, 'podium-front');
        wallXY(group, -PW / 2, PW / 2, 0, podiumH, -PD / 2 + PT / 2, PT, mat.podium, null, 'podium-back');
        wallYZ(group, -PD / 2, PD / 2, 0, podiumH, -PW / 2 + PT / 2, PT, mat.podium, null, 'podium-left');
        wallYZ(group, -PD / 2, PD / 2, 0, podiumH, PW / 2 - PT / 2, PT, mat.podium, null, 'podium-right');
        add(group, mesh(PW + 0.5, 0.34, PD + 0.5, mat.band, 0, podiumH + 0.02, 0, 'podium-cornice'));

        // 门厅天花（同时也是塔楼楼板），楼梯核心筒位置留洞
        var v = opt.lobbyVoid;
        var cx0 = -PW / 2 + PT, cx1 = PW / 2 - PT, cz0 = -PD / 2 + PT, cz1 = PD / 2 - PT;
        var cy = podiumH - 0.15;
        if (v) {
          if (v.z1 < cz1) add(group, mesh(cx1 - cx0, 0.3, cz1 - v.z1, mat.lobbyCeil, (cx0 + cx1) / 2, cy, (v.z1 + cz1) / 2, 'lobby-slab-front'));
          if (v.z0 > cz0) add(group, mesh(cx1 - cx0, 0.3, v.z0 - cz0, mat.lobbyCeil, (cx0 + cx1) / 2, cy, (cz0 + v.z0) / 2, 'lobby-slab-back'));
          if (v.x0 > cx0) add(group, mesh(v.x0 - cx0, 0.3, v.z1 - v.z0, mat.lobbyCeil, (cx0 + v.x0) / 2, cy, (v.z0 + v.z1) / 2, 'lobby-slab-left'));
          if (v.x1 < cx1) add(group, mesh(cx1 - v.x1, 0.3, v.z1 - v.z0, mat.lobbyCeil, (v.x1 + cx1) / 2, cy, (v.z0 + v.z1) / 2, 'lobby-slab-right'));
        } else {
          add(group, mesh(cx1 - cx0, 0.3, cz1 - cz0, mat.lobbyCeil, (cx0 + cx1) / 2, cy, (cz0 + cz1) / 2, 'lobby-slab'));
        }
      }

      var towerBase = podiumH;
      var towerH = H - towerBase;

      // 塔楼做成 4 片外墙（内部空腔），并按需要开窗洞 / 门洞
      var T = 0.6;
      var openings = opt.openings || {};
      var winHole = openings.window || null;
      var doorHole = openings.door || null;

      wallXY(group, -W / 2, W / 2, towerBase, H, D / 2 - T / 2, T, mat.wall, null, 'tower-front');
      wallXY(group, -W / 2, W / 2, towerBase, H, -D / 2 + T / 2, T, mat.wall, winHole, 'tower-back');
      wallYZ(group, -D / 2, D / 2, towerBase, H, -W / 2 + T / 2, T, mat.wall, doorHole, 'tower-left');
      wallYZ(group, -D / 2, D / 2, towerBase, H, W / 2 - T / 2, T, mat.wall, null, 'tower-right');

      // 四角壁柱，给塔楼竖向收边
      var pierH = towerH - 0.5;
      [[1, 1], [1, -1], [-1, 1], [-1, -1]].forEach(function (s, i) {
        add(group, mesh(0.9, pierH, 0.9, mat.podium,
          s[0] * (W / 2 - 0.32), towerBase + pierH / 2 + 0.15, s[1] * (D / 2 - 0.32), 'corner-pier-' + i));
      });

      /* ========== 2. 楼层分隔线 ========== */
      var bandList = [];
      var bandH = 0.2, bandE = 0.14;
      for (var bf = 1; bf < floors; bf++) {
        var by = bf * fh;
        var bw = (podiumFloors > 0 && by <= podiumH + 0.01) ? PW : W;
        var bd = (podiumFloors > 0 && by <= podiumH + 0.01) ? PD : D;
        bandList.push({ p: [0, by, bd / 2 + bandE / 2], s: [bw + bandE * 2, bandH, bandE] });
        bandList.push({ p: [0, by, -bd / 2 - bandE / 2], s: [bw + bandE * 2, bandH, bandE] });
        bandList.push({ p: [bw / 2 + bandE / 2, by, 0], s: [bandE, bandH, bd + bandE * 2] });
        bandList.push({ p: [-bw / 2 - bandE / 2, by, 0], s: [bandE, bandH, bd + bandE * 2] });
      }
      add(group, instanced(bandList, mat.band, 'floor-bands'));

      /* ========== 3. 玻璃幕墙（默认前立面右侧） ========== */
      var curtainSide = opt.curtainSide || DEFAULTS.curtainSide;
      var cwRatio = clamp(num(opt.curtainRatio, DEFAULTS.curtainRatio), 0.15, 0.85);
      var cwW = W * cwRatio;
      var cwX0 = W / 2 - cwW;                 // 未旋转时：前立面幕墙左边界
      var cwY0 = podiumH + 0.18;
      var cwY1 = H - 1.15;
      var cwH = cwY1 - cwY0;
      var cwCX = cwX0 + cwW / 2;
      var cwFaceZ = D / 2 + 0.18;

      if (curtainSide !== 'none' && cwH > 2) {
        var cw = new THREE.Group();
        cw.name = 'curtain-wall';

        // 玻璃面
        add(cw, mesh(cwW - 0.5, cwH, 0.12, mat.curtain, cwCX, cwY0 + cwH / 2, cwFaceZ, 'curtain-glass'));

        // 边框
        add(cw, mesh(0.42, cwH, 0.2, mat.mullion, cwX0 + 0.21, cwY0 + cwH / 2, cwFaceZ + 0.04, 'curtain-frame-l'));
        add(cw, mesh(0.42, cwH, 0.2, mat.mullion, cwX0 + cwW - 0.21, cwY0 + cwH / 2, cwFaceZ + 0.04, 'curtain-frame-r'));
        add(cw, mesh(cwW, 0.42, 0.2, mat.mullion, cwCX, cwY1, cwFaceZ + 0.04, 'curtain-frame-t'));
        add(cw, mesh(cwW, 0.42, 0.2, mat.mullion, cwCX, cwY0, cwFaceZ + 0.04, 'curtain-frame-b'));

        // 幕墙分格（竖梃 + 横梃）
        var mull = [];
        var vCount = Math.max(2, Math.round(cwW / 1.7));
        for (var vi = 1; vi < vCount; vi++) {
          var vx = cwX0 + (cwW / vCount) * vi;
          mull.push({ p: [vx, cwY0 + cwH / 2, cwFaceZ + 0.1], s: [0.1, cwH, 0.14] });
        }
        // 横梃对齐楼层线（与 floor-bands 同一标高，避免错缝）
        var firstLine = Math.ceil((cwY0 + 0.2) / fh) * fh;
        for (var hy = firstLine; hy < cwY1 - 0.4; hy += fh) {
          mull.push({ p: [cwCX, hy, cwFaceZ + 0.1], s: [cwW, 0.1, 0.14] });
        }
        add(cw, instanced(mull, mat.mullion, 'curtain-mullions'));

        var rotMap = { front: 0, right: Math.PI / 2, back: Math.PI, left: -Math.PI / 2 };
        if (rotMap[curtainSide] === undefined) {
          throw new Error('unknown curtainSide "' + curtainSide + '"');
        }
        cw.rotation.y = rotMap[curtainSide];
        add(group, cw);
      }

      /* ========== 4. 规则窗格（实例化） ========== */
      var winW = Math.min(1.7, Math.max(1.0, num(opt.windowWidth, 1.5)));
      var winH = Math.min(2.0, Math.max(1.1, num(opt.windowHeight, fh * 0.52)));
      var marginX = Math.min(2.2, W * 0.09);
      var marginZ = Math.min(2.2, D * 0.09);
      var nX = Math.max(2, Math.round((W - marginX * 2) / 2.45));
      var nZ = Math.max(2, Math.round((D - marginZ * 2) / 2.45));
      var stepX = (W - marginX * 2) / nX;
      var stepZ = (D - marginZ * 2) / nZ;
      var winList = [];

      for (var wf = podiumFloors; wf < floors; wf++) {
        var wy = wf * fh + fh * 0.55;
        var ix, iz, wx, wz;

        // 前立面（幕墙范围内不重复布窗）
        for (ix = 0; ix < nX; ix++) {
          wx = -W / 2 + marginX + (ix + 0.5) * stepX;
          if (curtainSide === 'front' && wx + winW / 2 > cwX0 - 0.2) continue;
          winList.push({ p: [wx, wy, D / 2 + 0.02], s: [winW, winH, 0.14] });
        }
        // 后立面
        for (ix = 0; ix < nX; ix++) {
          wx = -W / 2 + marginX + (ix + 0.5) * stepX;
          if (winHole && wx + winW / 2 > winHole.x0 && wx - winW / 2 < winHole.x1 &&
              wy + winH / 2 > winHole.y0 && wy - winH / 2 < winHole.y1) continue;
          winList.push({ p: [wx, wy, -D / 2 - 0.02], s: [winW, winH, 0.14] });
        }
        // 左右立面
        for (iz = 0; iz < nZ; iz++) {
          wz = -D / 2 + marginZ + (iz + 0.5) * stepZ;
          winList.push({ p: [W / 2 + 0.02, wy, wz], s: [0.14, winH, winW] });
          if (doorHole && wz + winW / 2 > doorHole.z0 && wz - winW / 2 < doorHole.z1 &&
              wy + winH / 2 > doorHole.y0 && wy - winH / 2 < doorHole.y1) continue;
          winList.push({ p: [-W / 2 - 0.02, wy, wz], s: [0.14, winH, winW] });
        }
      }
      add(group, instanced(winList, mat.glass, 'windows'));

      /* ========== 5. 裙楼落地玻璃 ========== */
      if (podiumFloors > 0) {
        var sfY0 = 1.3, sfY1 = podiumH - 0.85, sfH = sfY1 - sfY0;
        if (sfH > 0.8) {
          var sfHalf = PW / 2 - 0.9;
          var sfInner = 3.0;
          var paneW = sfHalf - sfInner;
          add(group, mesh(paneW, sfH, 0.12, mat.glass, -(sfInner + paneW / 2), sfY0 + sfH / 2, frontZ + 0.03, 'storefront-front-l'));
          add(group, mesh(paneW, sfH, 0.12, mat.glass, sfInner + paneW / 2, sfY0 + sfH / 2, frontZ + 0.03, 'storefront-front-r'));
          add(group, mesh(0.12, sfH, PD - 2.2, mat.glass, PW / 2 + 0.03, sfY0 + sfH / 2, 0, 'storefront-right'));
          add(group, mesh(0.12, sfH, PD - 2.2, mat.glass, -PW / 2 - 0.03, sfY0 + sfH / 2, 0, 'storefront-left'));
        }
      }

      /* ========== 6. 入口：门 / 平台 / 台阶 / 雨棚 ========== */
      var platH = 0.45, platW = 12, platD = 1.6;
      var platform = mesh(platW, platH, platD, mat.podium, 0, platH / 2, frontZ + platD / 2, 'entry-platform');
      platform.userData.walk = true;   // 可站立：入口平台
      add(group, platform);

      // 两级台阶（宽 0.36 / 高 0.15）
      for (var st = 1; st <= 2; st++) {
        var stTop = platH - st * 0.15;
        var stW = platW - st * 0.9;
        var step = mesh(stW, stTop, 0.36, mat.podium, 0, stTop / 2,
          frontZ + platD + (st - 0.5) * 0.36, 'entry-step-' + st);
        step.userData.walk = true;     // 可站立：台阶
        add(group, step);
      }

      // 门洞（门厅敞开，只保留金属门框）
      var doorH = 3.15;
      add(group, mesh(0.22, doorH + 0.3, 0.3, mat.mullion, -2.4, platH + (doorH + 0.3) / 2, frontZ + 0.09, 'door-jamb-l'));
      add(group, mesh(0.22, doorH + 0.3, 0.3, mat.mullion, 2.4, platH + (doorH + 0.3) / 2, frontZ + 0.09, 'door-jamb-r'));
      add(group, mesh(5.05, 0.24, 0.3, mat.mullion, 0, platH + doorH + 0.15, frontZ + 0.09, 'door-head'));
      add(group, mesh(0.1, doorH, 0.2, mat.mullion, 0, platH + doorH / 2, frontZ + 0.1, 'door-mullion'));

      // 雨棚 + 挑檐 + 支柱
      var canY = platH + 3.7;
      add(group, mesh(12.4, 0.3, 2.9, mat.metal, 0, canY, frontZ + 1.25, 'canopy'));
      add(group, mesh(12.6, 0.44, 0.16, mat.accent, 0, canY, frontZ + 2.68, 'canopy-fascia'));
      [-5.2, 5.2].forEach(function (cx, i) {
        add(group, cylinder(0.16, 0.18, canY - 0.15, 8, mat.metal, cx, (canY - 0.15) / 2, frontZ + 2.35, 'canopy-column-' + i));
      });

      /* ========== 7. 屋顶：顶板 / 女儿墙 / 设备 ========== */
      var roofY = H + 0.4;
      add(group, mesh(W + 0.7, 0.4, D + 0.7, mat.roof, 0, H + 0.2, 0, 'roof-slab'));

      var paraH = 1.2;
      add(group, mesh(W + 0.7, paraH, 0.4, mat.roof, 0, roofY + paraH / 2, D / 2 + 0.15, 'parapet-front'));
      add(group, mesh(W + 0.7, paraH, 0.4, mat.roof, 0, roofY + paraH / 2, -D / 2 - 0.15, 'parapet-back'));
      add(group, mesh(0.4, paraH, D - 0.1, mat.roof, W / 2 + 0.15, roofY + paraH / 2, 0, 'parapet-right'));
      add(group, mesh(0.4, paraH, D - 0.1, mat.roof, -W / 2 - 0.15, roofY + paraH / 2, 0, 'parapet-left'));

      // 出屋面楼梯间
      add(group, mesh(6.2, 3.2, 5.0, mat.wall, -6.5, roofY + 1.6, -3.6, 'roof-stair-house'));
      add(group, mesh(6.5, 0.3, 5.3, mat.roof, -6.5, roofY + 3.35, -3.6, 'roof-stair-cap'));

      // 设备箱
      add(group, mesh(2.6, 1.6, 2.0, mat.metal, 5.2, roofY + 0.8, 3.6, 'roof-unit-1'));
      add(group, mesh(2.6, 1.3, 2.0, mat.metal, 8.8, roofY + 0.65, 3.6, 'roof-unit-2'));
      add(group, mesh(2.2, 1.1, 1.8, mat.metal, 5.2, roofY + 0.55, -3.4, 'roof-unit-3'));

      // 天线与排风管
      add(group, cylinder(0.07, 0.09, 7.0, 6, mat.metal, 11.6, roofY + 3.5, 6.6, 'roof-antenna'));
      add(group, cylinder(0.34, 0.34, 1.1, 8, mat.roof, -10.8, roofY + 0.55, 5.2, 'roof-vent-1'));
      add(group, cylinder(0.28, 0.28, 0.9, 8, mat.roof, -0.4, roofY + 0.45, 6.4, 'roof-vent-2'));

      /* ========== 8. 背部室外消防楼梯 ========== */
      if (opt.stairTower !== false) {
        var sW = 4.8, sD = 2.0;
        var backZ = -D / 2;
        var lz = backZ - sD / 2 - 0.08;
        var landingList = [], flightList = [], railList = [];

        for (var sf = 1; sf <= floors - 1; sf++) {
          var ly = sf * fh;
          landingList.push({ p: [0, ly, lz], s: [sW, 0.14, sD] });
          railList.push({ p: [0, ly + 0.95, backZ - sD - 0.04], s: [sW + 0.12, 0.07, 0.07] });
          railList.push({ p: [0, ly + 0.5, backZ - sD - 0.04], s: [sW + 0.12, 0.06, 0.06] });
        }

        var run = sW - 0.8;
        var flightLen = Math.sqrt(run * run + fh * fh);
        var flightAng = Math.atan2(fh, run);
        for (var fl = 1; fl < floors - 1; fl++) {
          flightList.push({
            p: [0, fl * fh + fh / 2, lz],
            r: [0, 0, (fl % 2 === 0 ? -1 : 1) * flightAng],
            s: [flightLen, 0.12, 1.1]
          });
        }

        // 边柱
        [-1, 1].forEach(function (sx, i) {
          add(group, mesh(0.16, H - 0.4, 0.16, mat.metal, sx * (sW / 2 - 0.1), (H - 0.4) / 2, backZ - sD - 0.02, 'stair-post-' + i));
          add(group, mesh(0.16, H - 0.4, 0.16, mat.metal, sx * (sW / 2 - 0.1), (H - 0.4) / 2, backZ - 0.16, 'stair-post-in-' + i));
        });

        add(group, instanced(landingList, mat.metal, 'stair-landings'));
        add(group, instanced(flightList, mat.metal, 'stair-flights'));
        add(group, instanced(railList, mat.mullion, 'stair-rails'));
      }

      /* ---- 供布局/调试参考的包围盒信息 ---- */
      group.userData.bounds = {
        size: [W, H, D],
        offset: [0, H / 2, 0],
        floors: floors,
        footprint: { width: W, depth: D, podiumWidth: PW, podiumDepth: PD, entranceZ: frontZ }
      };

      return group;
    } catch (err) {
      throw new Error('Building model failed: ' + (err && err.message ? err.message : String(err)));
    }
  };
})(window);
